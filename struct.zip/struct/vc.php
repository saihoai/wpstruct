<?php
if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'textfield',
      'heading' => __( "Sub text", 'struct' ),
      'param_name' => 'subtext',
  );
vc_add_param( 'vc_custom_heading', $attributes ); // Note: 'vc_message' was used as a base for "Message box" element
}

if( function_exists( 'vc_set_shortcodes_templates_dir' ) )
{
  $dir = plugin_dir_path( __FILE__ ) . '/vc';
  vc_set_shortcodes_templates_dir( $dir );
}

// [wrtag foo="foo-value"]
if( !function_exists( 'wrtag_func' ) )
{
  function wrtag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'text' => '',
        'subtext' => '',
        'extext' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/wrtag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'wrtag', 'wrtag_func' );

if( !function_exists( 'wrtag_integrateWithVC' ) )
{
  function wrtag_integrateWithVC() {
     vc_map( array(
        "name" => __( "wrtag", "struct" ),
        "base" => "wrtag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Text", "struct" ),
              "param_name" => "text",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Sub text", "struct" ),
              "param_name" => "subtext",
          ),
          array(
              "type" => "exploded_textarea",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Exploded text", "struct" ),
              "param_name" => "extext",
          )
        )
     ) );
  }
}
add_action( 'vc_before_init', 'wrtag_integrateWithVC' );

// [countertag foo="foo-value"]
if( !function_exists( 'countertag_func' ) )
{
  function countertag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'link' => '',
        'icon' => '',
        'num' => '',
        'text' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/countertag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'countertag', 'countertag_func' );

if( !function_exists( 'countertag_integrateWithVC' ) )
{
  function countertag_integrateWithVC() {
     vc_map( array(
        "name" => __( "countertag", "struct" ),
        "base" => "countertag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link", "struct" ),
              "param_name" => "link",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Icon", "struct" ),
              "param_name" => "icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Number", "struct" ),
              "param_name" => "num",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Text", "struct" ),
              "param_name" => "text",
          )
        )
     ) );
  }
}
add_action( 'vc_before_init', 'countertag_integrateWithVC' );

// [owltag foo="foo-value"]
if( !function_exists( 'owltag_func' ) )
{
  function owltag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'images' => '',
        'tmpl' => 'style1',
     ), $atts ) );

     require( __DIR__ . '/tmpl/owltag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'owltag', 'owltag_func' );

if( !function_exists( 'owltag_integrateWithVC' ) )
{
  function owltag_integrateWithVC() {
     vc_map( array(
        "name" => __( "owltag", "struct" ),
        "base" => "owltag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "attach_images",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Images", "struct" ),
              "param_name" => "images",
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Template", "struct" ),
              "param_name" => "tmpl",
              "value"=> array(
                  'Style 1' => 'style1', 
                  'Style 2' => 'style2' ,
              )
          ),
        )
     ) );
  }
}
add_action( 'vc_before_init', 'owltag_integrateWithVC' );

// [phototag foo="foo-value"]
if( !function_exists( 'phototag_func' ) )
{
  function phototag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'image' => '',
        'title' => '',
        'subtitle' => '',
        'text' => '',
        'link_url' => '',
        'link_icon' => '',
        'link_title' => '',
        'tmpl' => 'style1',
        'class' => '',
        'style' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/phototag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'phototag', 'phototag_func' );

if( !function_exists( 'phototag_integrateWithVC' ) )
{
  function phototag_integrateWithVC() {
     vc_map( array(
        "name" => __( "phototag", "struct" ),
        "base" => "phototag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "attach_image",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Image", "struct" ),
              "param_name" => "image",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Title", "struct" ),
              "param_name" => "title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Sub title", "struct" ),
              "param_name" => "subtitle",
          ),
          array(
              "type" => "textarea",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Text", "struct" ),
              "param_name" => "text",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link url", "struct" ),
              "param_name" => "link_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link icon", "struct" ),
              "param_name" => "link_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link title", "struct" ),
              "param_name" => "link_title",
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Template", "struct" ),
              "param_name" => "tmpl",
              "value"=> array(
                  'Style 1' => 'style1', 
                  'Style 2' => 'style2' ,
                  'Icon box 1' => 'style3' ,
                  'Icon box 2' => 'iconbox2' ,
                  'Icon box 3' => 'iconbox3' ,
                  'Tooltip' => 'tooltip' ,
                  'Content box' => 'contentbox' ,
                  'Content box 2' => 'contentbox2' ,
                  'Progress 1' => 'progress1' ,
                  'Progress 2' => 'progress2' ,
                  'Progress 3' => 'progress3' ,
                  'Photobox 2' => 'photobox2' ,
                  'Photobox 3' => 'photobox3' ,
                  'Photobox 4' => 'photobox4' ,
                  'Photobox 5' => 'photobox5' ,
              )
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Class", "struct" ),
              "param_name" => "class",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Style", "struct" ),
              "param_name" => "style",
          ),
        )
     ) );
  }
}
add_action( 'vc_before_init', 'phototag_integrateWithVC' );

if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'dropdown',
      'param_name' => 'style',
      'value' => array(
          __( 'Classic', 'js_composer' ) => 'classic',
          __( 'Modern', 'js_composer' ) => 'modern',
          __( 'Flat', 'js_composer' ) => 'flat',
          __( 'Outline', 'js_composer' ) => 'outline',
          __( 'Transparent', 'js_composer' ) => 'transparent',
      ),
      'heading' => __( 'Style', 'js_composer' ),
      'description' => __( 'Select accordion display style.', 'js_composer' ),
  );
  vc_add_param( 'vc_tta_accordion', $attributes ); // Note: 'vc_tta_accordion' was used as a base for "accordion" element
}

if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'dropdown',
      'param_name' => 'style',
      'value' => array(
          __( 'Classic', 'js_composer' ) => 'classic',
          __( 'Modern', 'js_composer' ) => 'modern',
          __( 'Flat', 'js_composer' ) => 'flat',
          __( 'Outline', 'js_composer' ) => 'outline',
          __( 'Transparent', 'js_composer' ) => 'transparent',
      ),
      'heading' => __( 'Style', 'js_composer' ),
      'description' => __( 'Select accordion display style.', 'js_composer' ),
  );
  vc_add_param( 'vc_tta_tabs', $attributes ); // Note: 'vc_tta_accordion' was used as a base for "accordion" element
}

if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'dropdown',
      'param_name' => 'color',
      'value' => array(
          __( 'Blue', 'js_composer' ) => 'blue',
          __( 'Turquoise', 'js_composer' ) => 'turquoise',
          __( 'Pink', 'js_composer' ) => 'pink',
          __( 'Violet', 'js_composer' ) => 'violet',
          __( 'Peacoc', 'js_composer' ) => 'peacoc',
          __( '66aacc', 'js_composer' ) => '66aacc',
          __( 'Chino', 'js_composer' ) => 'chino',
          __( 'Mulled Wine', 'js_composer' ) => 'mulled-wine',
          __( 'Vista Blue', 'js_composer' ) => 'vista-blue',
          __( 'Black', 'js_composer' ) => 'black',
          __( 'Grey', 'js_composer' ) => 'grey',
          __( 'Orange', 'js_composer' ) => 'orange',
          __( 'Sky', 'js_composer' ) => 'sky',
          __( 'Green', 'js_composer' ) => 'green',
          __( 'Juicy pink', 'js_composer' ) => 'juicy-pink',
          __( 'Sandy brown', 'js_composer' ) => 'sandy-brown',
          __( 'Purple', 'js_composer' ) => 'purple',
          __( 'White', 'js_composer' ) => 'white',
      ),
      'heading' => __( 'Style', 'js_composer' ),
      'description' => __( 'Select accordion display style.', 'js_composer' ),
  );
  vc_add_param( 'vc_tta_accordion', $attributes ); // Note: 'vc_tta_accordion' was used as a base for "accordion" element
}

if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'dropdown',
      'heading' => __( "Template", 'struct' ),
      'param_name' => 'tmpl',
      'value' => array(
          'default' => 'Default',
          'Latest Projects' => 'latest-projects',
          'Latest Projects 2' => 'latest-projects2',
          'Latest works' => 'latest-works',
          'Latest works 2' => 'latest-works2',
          'Testimonials' => 'testimonials',
          'Testimonials 2' => 'testimonials2',
          'Accordion' => 'accordion',
          'Accordion 2' => 'accordion2',
          'Tab' => 'tab',
          'Tab 2' => 'tab2',
          'Teams' => 'teams',
          'Owl slider' => 'owl',
      )
  );
  vc_add_param( 'vc_posts_slider', $attributes ); // Note: 'vc_posts_slider' was used as a base for "Posts Slider" element
}

if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'dropdown',
      'heading' => __( "Template", 'struct' ),
      'param_name' => 'tmpl',
      'value' => array(
          'default' => 'Default',
          'Style 1' => 'style1',
      )
  );
  vc_add_param( 'vc_cta', $attributes ); // Note: 'vc_cta' was used as a base for "Call action" element
}

if( function_exists( 'vc_add_param' ) )
{
  $attributes = array(
      'type' => 'dropdown',
      'heading' => __( "Template", 'struct' ),
      'param_name' => 'tmpl',
      'value' => array(
          'default' => 'Default',
          'Style 1' => 'style1',
      )
  );
  vc_add_param( 'vc_progress_bar', $attributes ); // Note: 'vc_progress_bar' was used as a base for "Progress bar" element
}

// [pricetag foo="foo-value"]
if( !function_exists( 'pricetag_func' ) )
{
  function pricetag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'title' => '',
        'unit' => '',
        'price' => '',
        'price_bg' => 'black',
        'amount' => '',
        'text' => '',
        'link_url' => '',
        'link_icon' => '',
        'link_title' => '',
        'link_bg' => 'black',
        'class' => '',
        'delay' => '',
        'effect' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/pricetag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'pricetag', 'pricetag_func' );

if( !function_exists( 'pricetag_integrateWithVC' ) )
{
  function pricetag_integrateWithVC() {
     vc_map( array(
        "name" => __( "pricetag", "struct" ),
        "base" => "pricetag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Titlte", "struct" ),
              "param_name" => "title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Unit", "struct" ),
              "param_name" => "unit",
          ),
           array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Price", "struct" ),
              "param_name" => "price",
          ),
           array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Price background", "struct" ),
              "param_name" => "price_bg",
              "value" => array(
                __( "White", "struct" ) => "white",
                __( "Gray", "struct" ) => "gray",
                __( "Black", "struct" ) => "black",
                __( "Pink", "struct" ) => "pink",
                __( "Purple", "struct" ) => "purple",
                __( "Indigo", "struct" ) => "indigo",
                __( "Blue", "struct" ) => "blue",
                __( "Aqua", "struct" ) => "aqua",
                __( "Emerald", "struct" ) => "emerald",
                __( "Green", "struct" ) => "green",
                __( "Olive", "struct" ) => "olive",
                __( "Yellow", "struct" ) => "yellow",
                __( "Orange", "struct" ) => "orange",
                __( "Red", "struct" ) => "red",
                __( "Theme", "struct" ) => "theme",
              )
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Amount", "struct" ),
              "param_name" => "amount",
          ),
          array(
              "type" => "exploded_textarea",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Text", "struct" ),
              "param_name" => "text",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link url", "struct" ),
              "param_name" => "link_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link icon", "struct" ),
              "param_name" => "link_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link title", "struct" ),
              "param_name" => "link_title",
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link background", "struct" ),
              "param_name" => "link_bg",
              "value" => array(
                __( "White", "struct" ) => "white",
                __( "Gray", "struct" ) => "gray",
                __( "Black", "struct" ) => "black",
                __( "Pink", "struct" ) => "pink",
                __( "Purple", "struct" ) => "purple",
                __( "Indigo", "struct" ) => "indigo",
                __( "Blue", "struct" ) => "blue",
                __( "Aqua", "struct" ) => "aqua",
                __( "Emerald", "struct" ) => "emerald",
                __( "Green", "struct" ) => "green",
                __( "Olive", "struct" ) => "olive",
                __( "Yellow", "struct" ) => "yellow",
                __( "Orange", "struct" ) => "orange",
                __( "Red", "struct" ) => "red",
                __( "Theme", "struct" ) => "theme",
              )
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Badge", "struct" ),
              "param_name" => "class",
              "value" => array(
                __( "Default" ) => "",
                __( "Popular" ) => "badge-popular",
                __( "Sale" ) => "badge-sale",
                __( "Best" ) => "badge-best",
                __( "New" ) => "badge-new",
              )
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Delay", "struct" ),
              "param_name" => "delay",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Effect", "struct" ),
              "param_name" => "effect",
          ),
        )
     ) );
  }
}
add_action( 'vc_before_init', 'pricetag_integrateWithVC' );

// [pricetag foo="foo-value"]
if( !function_exists( 'leadtag_func' ) )
{
  function leadtag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'title' => '',
        'subtitle' => '',
        'text' => '',
        'link1_color' => '',
        'link1_url' => '',
        'link1_icon' => '',
        'link1_title' => '',
        'link2_color' => '',
        'link2_url' => '',
        'link2_icon' => '',
        'link2_title' => '',
        'tmpl' => 'style1',
        'class' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/leadtag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'leadtag', 'leadtag_func' );

if( !function_exists( 'leadtag_integrateWithVC' ) )
{
  function leadtag_integrateWithVC() {
     vc_map( array(
        "name" => __( "leadtag", "struct" ),
        "base" => "leadtag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Titlte", "struct" ),
              "param_name" => "title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Sub titlte", "struct" ),
              "param_name" => "subtitle",
          ),
          array(
              "type" => "textarea",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Text", "struct" ),
              "param_name" => "text",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 color", "struct" ),
              "param_name" => "link1_color",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 url", "struct" ),
              "param_name" => "link1_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 icon", "struct" ),
              "param_name" => "link1_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 title", "struct" ),
              "param_name" => "link1_title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 color", "struct" ),
              "param_name" => "link2_color",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 url", "struct" ),
              "param_name" => "link2_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 icon", "struct" ),
              "param_name" => "link2_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 title", "struct" ),
              "param_name" => "link2_title",
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Template", "struct" ),
              "param_name" => "tmpl",
              "value"=> array(
                  'Style 1' => 'style1', 
                  'Style 2' => 'style2' ,
                  'Style 3' => 'style3' ,
                  'Style 4' => 'style4' ,
              )
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Class", "struct" ),
              "param_name" => "class",
          ),
        )
     ) );
  }
}
add_action( 'vc_before_init', 'leadtag_integrateWithVC' );

// [teamtag foo="foo-value"]
if( !function_exists( 'teamtag_func' ) )
{
  function teamtag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'image' => '',
        'title' => '',
        'subtitle' => '',
        'text' => '',
        'link1_url' => '',
        'link1_icon' => '',
        'link1_title' => '',
        'link2_url' => '',
        'link2_icon' => '',
        'link2_title' => '',
        'link3_url' => '',
        'link3_icon' => '',
        'link3_title' => '',
        'link4_url' => '',
        'link4_icon' => '',
        'link4_title' => '',
        'link5_url' => '',
        'link5_icon' => '',
        'link5_title' => '',
        'link6_url' => '',
        'link6_icon' => '',
        'link6_title' => '',
        'tmpl' => 'style1',
        'class' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/teamtag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'teamtag', 'teamtag_func' );

if( !function_exists( 'teamtag_integrateWithVC' ) )
{
  function teamtag_integrateWithVC() {
     vc_map( array(
        "name" => __( "teamtag", "struct" ),
        "base" => "teamtag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "attach_image",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Image", "struct" ),
              "param_name" => "image",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Titlte", "struct" ),
              "param_name" => "title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Sub titlte", "struct" ),
              "param_name" => "subtitle",
          ),
          array(
              "type" => "textarea",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Text", "struct" ),
              "param_name" => "text",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 url", "struct" ),
              "param_name" => "link1_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 icon", "struct" ),
              "param_name" => "link1_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 1 title", "struct" ),
              "param_name" => "link1_title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 url", "struct" ),
              "param_name" => "link2_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 icon", "struct" ),
              "param_name" => "link2_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 2 title", "struct" ),
              "param_name" => "link2_title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 3 url", "struct" ),
              "param_name" => "link3_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 3 icon", "struct" ),
              "param_name" => "link3_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 3 title", "struct" ),
              "param_name" => "link3_title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 4 url", "struct" ),
              "param_name" => "link4_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 4 icon", "struct" ),
              "param_name" => "link4_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 4 title", "struct" ),
              "param_name" => "link4_title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 5 url", "struct" ),
              "param_name" => "link5_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 5 icon", "struct" ),
              "param_name" => "link5_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 5 title", "struct" ),
              "param_name" => "link5_title",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 6 url", "struct" ),
              "param_name" => "link5_url",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 6 icon", "struct" ),
              "param_name" => "link5_icon",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Link 6 title", "struct" ),
              "param_name" => "link5_title",
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Template", "struct" ),
              "param_name" => "tmpl",
              "value"=> array(
                  'Style 1' => 'style1', 
                  'Style 2' => 'style2' ,
              )
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Class", "struct" ),
              "param_name" => "class",
          ),
        )
     ) );
  }
}
add_action( 'vc_before_init', 'teamtag_integrateWithVC' );

// [contacttag foo="foo-value"]
if( !function_exists( 'contacttag_func' ) )
{
  function contacttag_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        'address' => '',
        'phone' => '',
        'email' => '',
        'menu_id' => '',
        'class' => '',
     ), $atts ) );

     require( __DIR__ . '/tmpl/contacttag.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'contacttag', 'contacttag_func' );

if( !function_exists( 'contacttag_integrateWithVC' ) )
{
  function contacttag_integrateWithVC() {
    // Get menus
      $menus = wp_get_nav_menus();
      $menu_data = array();
      foreach( $menus as $item )
      {
        $menu_data[ $item->term_id ] = $item->name;
      }
     vc_map( array(
        "name" => __( "contacttag", "struct" ),
        "base" => "contacttag",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Address", "struct" ),
              "param_name" => "address",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Phone", "struct" ),
              "param_name" => "phone",
          ),
          array(
              "type" => "textfield",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Email", "struct" ),
              "param_name" => "email",
          ),
          array(
              "type" => "dropdown",
              "holder" => "div",
              "class" => "",
              "heading" => __( "Menu", "struct" ),
              "param_name" => "menu_id",
              "value" => $menu_data
          ),
        )
     ) );
  }
}
add_action( 'vc_before_init', 'contacttag_integrateWithVC' );

if( function_exists( 'vc_add_params' ) )
{
  $colors_vc_basic_grid = array(
    'Blue' => 'blue',
    'Turquoise' => 'turquoise',
    'Pink' => 'pink',
    'Violet' => 'violet',
    'Peacoc' => 'peacoc',
    'Chino' => 'chino',
    'Mulled Wine' => 'mulled_wine',
    'Vista Blue' => 'vista_blue',
    'Black' => 'black',
    'Grey' => 'grey',
    'Orange' => 'orange',
    'Sky' => 'sky',
    'Green' => 'green',
    'Juicy pink' => 'juicy_pink',
    'Sandy brown' => 'sandy_brown',
    'Purple' => 'purple',
    'White' => 'white',
  );
  if( function_exists( 'getVcShared' ) )
  {
    $colors_vc_basic_grid = getVcShared( 'colors' );
    $colors_vc_basic_grid[ '66aacc' ] = '66aacc';
  }
  $attributes = array(
    array(
      'type' => 'checkbox',
      'param_name' => 'stitle',
      'heading' => __( 'Show title', 'js_composer' ),
      'group' => __( 'Item Design', 'js_composer' ),
      'value' => "false"
    ),
    array(
      'type' => 'checkbox',
      'param_name' => 'sexcerpt',
      'heading' => __( 'Show Excerpt', 'js_composer' ),
      'group' => __( 'Item Design', 'js_composer' ),
      'value' => "false"
    ),
    array(
      'type' => 'checkbox',
      'param_name' => 'sreadmore',
      'heading' => __( 'Show read more', 'js_composer' ),
      'group' => __( 'Item Design', 'js_composer' ),
      'value' => "false"
    ),
    array(
      'type' => 'dropdown',
      'heading' => __( 'Color', 'js_composer' ),
      'param_name' => 'filter_color',
      'value' => $colors_vc_basic_grid,
      'std' => 'grey',
      'param_holder_class' => 'vc_colored-dropdown',
      'dependency' => array(
        'element' => 'show_filter',
        'value' => array( 'yes' ),
      ),
      'group' => __( 'Filter', 'js_composer' ),
      'description' => __( 'Select filter color.', 'js_composer' ),
    )
  );
  vc_add_params( 'vc_basic_grid', $attributes ); // Note: 'vc_tta_accordion' was used as a base for "accordion" element
}

// [iconsdemo foo="foo-value"]
if( !function_exists( 'iconsdemo_func' ) )
{
  function iconsdemo_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        
     ), $atts ) );

     require( __DIR__ . '/tmpl/iconsdemo.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'iconsdemo', 'iconsdemo_func' );

if( !function_exists( 'iconsdemo_integrateWithVC' ) )
{
  function iconsdemo_integrateWithVC() {
    vc_map( array(
        "name" => __( "iconsdemo", "struct" ),
        "base" => "iconsdemo",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          
        )
     ) );
  }
}
add_action( 'vc_before_init', 'iconsdemo_integrateWithVC' );


// [typographydemo foo="foo-value"]
if( !function_exists( 'typographydemo_func' ) )
{
  function typographydemo_func( $atts ) 
  {
     ob_start();

     extract( shortcode_atts( array(
        
     ), $atts ) );

     require( __DIR__ . '/tmpl/typographydemo.php' );
    
     return ob_get_clean();
  }
}
add_shortcode( 'typographydemo', 'typographydemo_func' );

if( !function_exists( 'typographydemo_integrateWithVC' ) )
{
  function typographydemo_integrateWithVC() 
  {
    vc_map( array(
        "name" => __( "typographydemo", "struct" ),
        "base" => "typographydemo",
        "class" => "",
        "category" => __( "Content", "struct"),
        "params" => array(
          
        )
     ) );
  }
}
add_action( 'vc_before_init', 'typographydemo_integrateWithVC' );






