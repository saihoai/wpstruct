<?php
if( !function_exists( 'struct_page_title_buddypress_end' ) )
{
	function struct_page_title_buddypress_end()
	{
		if( !function_exists( 'get_body_class' ) )
		{
			return;
		}
		$class = implode( ' ', get_body_class() );
		if( preg_match( '/buddypress/', $class ) )
		{
			echo '<div class="mb-100"></div>';
		}
	}
}
add_action( 'page_title_end', 'struct_page_title_buddypress_end' );
add_action( 'get_footer', 'struct_page_title_buddypress_end' );

if( !function_exists( 'struct_page_title_buddypress_start' ) )
{
	function struct_page_title_buddypress_start()
	{
		if( !function_exists( 'get_body_class' ) )
		{
			return;
		}
		$class = implode( ' ', get_body_class() );
		if( preg_match( '/buddypress/', $class ) && !preg_match( '/page-template-page-title/', $class ) )
		{
			do_action( 'page_title' );
		}
	}
}
add_action( 'get_header_end', 'struct_page_title_buddypress_start' );
/**
 * Filters the HTML markup for the groups search form.
 *
 * @since 1.9.0
 *
 * @param string $search_form_html HTML markup for the search form.
 */
if( !function_exists( 'struct_bp_directory_groups_search_form' ) )
{
	function struct_bp_directory_groups_search_form( $html = '' )
	{
		$query_arg = bp_core_get_component_search_query_arg( 'groups' );

		if ( ! empty( $_REQUEST[ $query_arg ] ) ) {
			$search_value = stripslashes( $_REQUEST[ $query_arg ] );
		} else {
			$search_value = bp_get_search_default_text( 'groups' );
		}

		ob_start();
		require_once( __DIR__ . '/tmpl/bp-group-search-form.php' );
		echo ob_get_clean();
	}
}
add_filter( 'bp_directory_groups_search_form', 'struct_bp_directory_groups_search_form' );
/**
 * Output the Members directory search form.
 *
 * @since 1.0.0
 */
if( !function_exists( 'struct_bp_directory_members_search_form' ) )
{
	function struct_bp_directory_members_search_form( $html = '' )
	{
		$query_arg = bp_core_get_component_search_query_arg( 'members' );

		if ( ! empty( $_REQUEST[ $query_arg ] ) ) {
			$search_value = stripslashes( $_REQUEST[ $query_arg ] );
		} else {
			$search_value = bp_get_search_default_text( 'members' );
		}

		ob_start();
		require_once( __DIR__ . '/tmpl/bp-member-search-form.php' );
		echo ob_get_clean();
	}
}
add_filter( 'bp_directory_members_search_form', 'struct_bp_directory_members_search_form' );
/**
 * Filters the blogs pagination links.
 *
 * @since 1.0.0
 *
 * @param string $pag_links HTML pagination links.
 */
if( !function_exists( 'struct_bp_get_pagination_links' ) )
{
	function struct_bp_get_pagination_links( $html = '' )
	{
		$links = preg_split( '/<\/span>|<\/a>/', $html );
		if( !count( $links ) )
		{
			return $html;
		}
		$rs = '<ul class="pagination">';
		foreach( $links as $item )
		{
			if( preg_match( '/<span/', $item ) )
			{
				$text = preg_replace( '/span/', 'a', "<li class='active'>{$item}</span></li>" );
				$text = preg_replace( '/page-numbers|current/', '', $text );
				$rs .= $text;
			}
			elseif( preg_match( '/<a/', $item ) )
			{
				$text = preg_replace( '/page-numbers|next|previous|prev/', '', "<li>{$item}</a></li>" );
				if( is_rtl() )
				{
					$text = preg_replace( '/&rarr;/', '<i class="fa fa-angle-double-right" aria-hidden="true"></i>', $text );
					$text = preg_replace( '/&larr;/', '<i class="fa fa-angle-double-left" aria-hidden="true"></i>', $text );
				}
				$rs .= $text;
			}
		}
		$rs .= '</ul>';
		return $rs;
	}
}
add_filter( 'bp_get_members_pagination_links', 'struct_bp_get_pagination_links' );
add_filter( 'bp_get_activity_pagination_links', 'struct_bp_get_pagination_links' );
add_filter( 'bp_get_blogs_pagination_links', 'struct_bp_get_pagination_links' );
add_filter( 'bp_get_groups_pagination_links', 'struct_bp_get_pagination_links' );
add_filter( 'bp_get_group_requests_pagination_links', 'struct_bp_get_pagination_links' );
add_filter( 'bp_get_group_invite_pagination_links', 'struct_bp_get_pagination_links' );
add_filter( 'bp_get_notifications_pagination_links', 'struct_bp_get_pagination_links' );


if( !function_exists( 'struct_bp_message_search_form' ) )
{
	function struct_bp_message_search_form()
	{
		ob_start();
		// Get the default search text.
		$default_search_value = bp_get_search_default_text( 'messages' );

		// Setup a few values based on what's being searched for.
		$search_submitted     = ! empty( $_REQUEST['s'] ) ? stripslashes( $_REQUEST['s'] ) : $default_search_value;
		$search_placeholder   = ( $search_submitted === $default_search_value ) ? ' placeholder="' .  esc_attr( $search_submitted ) . '"' : '';
		$search_value         = ( $search_submitted !== $default_search_value ) ? ' value="'       .  esc_attr( $search_submitted ) . '"' : '';
		require_once( __DIR__ . '/tmpl/bp_message_search_form.php' );
		echo ob_get_clean();
	}
}
add_filter( 'bp_message_search_form', 'struct_bp_message_search_form' );








