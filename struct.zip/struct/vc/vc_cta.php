<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Cta
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
$this->buildTemplate( $atts, $content );
$containerClass = trim( 'vc_cta3-container ' . esc_attr( implode( ' ', $this->getTemplateVariable( 'container-class' ) ) ) );
$cssClass = trim( 'vc_general ' . esc_attr( implode( ' ', $this->getTemplateVariable( 'css-class' ) ) ) );
?>

<?php if( isset( $atts['tmpl']) && ( $atts['tmpl'] == 'style1' ) ) : ?>
	<div class="<?php echo $cssClass; ?>">
<div class="row">
  <div class="col-md-9">
    <h3><span class="text-theme"><?php echo $atts['h4']; ?></span> <?php echo $atts['h2']; ?></h3>
    <?php echo $this->getTemplateVariable( 'content' ); ?>
  </div>
  <!-- end .col-md-9 -->
  
  <div class="col-md-3">
    <div class="mb-30"></div>
    <!-- end .mb-30 --> 
    <a href="<?php echo $atts['btn_link']; ?>" class="btn btn-theme"><span><i class="<?php echo $atts['btn_i_icon_fontawesome']; ?>"></i></span><?php echo $atts['btn_title']; ?></a> </div>
  <!-- end .col-md-3 --> 
  
</div>
<!-- end .row --> 
</div>
<?php else : ?>
<section class="<?php echo esc_attr( $containerClass ); ?>">
	<div class="<?php echo esc_attr( $cssClass ); ?>"<?php
	if ( $this->getTemplateVariable( 'inline-css' ) ) {
		echo ' style="' . esc_attr( implode( ' ', $this->getTemplateVariable( 'inline-css' ) ) ) . '"';
	}
	?>>
		<?php echo $this->getTemplateVariable( 'icons-top' ); ?>
		<?php echo $this->getTemplateVariable( 'icons-left' ); ?>
		<div class="vc_cta3_content-container">
			<?php echo $this->getTemplateVariable( 'actions-top' ); ?>
			<?php echo $this->getTemplateVariable( 'actions-left' ); ?>
			<div class="vc_cta3-content">
				<header class="vc_cta3-content-header">
					<?php echo $this->getTemplateVariable( 'heading1' ); ?>
					<?php echo $this->getTemplateVariable( 'heading2' ); ?>
				</header>
				<?php echo $this->getTemplateVariable( 'content' ); ?>
			</div>
			<?php echo $this->getTemplateVariable( 'actions-bottom' ); ?>
			<?php echo $this->getTemplateVariable( 'actions-right' ); ?>
		</div>
		<?php echo $this->getTemplateVariable( 'icons-bottom' ); ?>
		<?php echo $this->getTemplateVariable( 'icons-right' ); ?>
	</div>
</section>
<?php endif ?>
