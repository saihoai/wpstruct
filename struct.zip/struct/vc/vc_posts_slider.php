<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $title
 * @var $type
 * @var $count
 * @var $interval
 * @var $slides_content
 * @var $slides_title
 * @var $link
 * @var $custom_links
 * @var $thumb_size
 * @var $posttypes
 * @var $posts_in
 * @var $categories
 * @var $orderby
 * @var $order
 * @var $el_class
 * @var $css
 * @var $tmpl
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Posts_slider
 */
$title = $type = $count = $interval = $slides_content = $slides_title = $link = $custom_links = $thumb_size = $posttypes = $posts_in = $categories = $order = $orderby = $el_class = $css = $tmpl = '';
$link_image_start = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$gal_images = '';
$link_start = '';
$link_end = '';
$el_start = '';
$el_end = '';
$slides_wrap_start = '';
$slides_wrap_end = '';

if ( 'nivo' === $type ) {
	$type = ' wpb_slider_nivo theme-default';
	wp_enqueue_script( 'nivo-slider' );
	wp_enqueue_style( 'nivo-slider-css' );
	wp_enqueue_style( 'nivo-slider-theme' );

	$slides_wrap_start = '<div class="nivoSlider">';
	$slides_wrap_end = '</div>';
} elseif ( 'flexslider' === $type || 'flexslider_fade' === $type || 'flexslider_slide' === $type || 'fading' === $type ) {
	$el_start = '<li>';
	$el_end = '</li>';
	$slides_wrap_start = '<ul class="slides">';
	$slides_wrap_end = '</ul>';
	wp_enqueue_style( 'flexslider' );
	wp_enqueue_script( 'flexslider' );
}
$flex_fx = '';
if ( 'flexslider' === $type || 'flexslider_fade' === $type || 'fading' === $type ) {
	$type = ' wpb_flexslider flexslider_fade flexslider';
	$flex_fx = ' data-flex_fx="fade"';
} elseif ( 'flexslider_slide' === $type ) {
	$type = ' wpb_flexslider flexslider_slide flexslider';
	$flex_fx = ' data-flex_fx="slide"';
}

if ( 'link_image' === $link ) {
	wp_enqueue_script( 'prettyphoto' );
	wp_enqueue_style( 'prettyphoto' );
}

$query_args = array(
	'post_status' => 'publish',
);

//exclude current post/page from query
if ( '' !== $posts_in ) {
	$query_args['post__in'] = explode( ',', $posts_in );
}
global $vc_posts_grid_exclude_id;
$vc_posts_grid_exclude_id[] = get_the_ID();
$query_args['post__not_in'] = array( get_the_ID() );

// Post teasers count
if ( '' !== $count && ! is_numeric( $count ) ) {
	$count = - 1;
}
if ( '' !== $count && is_numeric( $count ) ) {
	$query_args['posts_per_page'] = $count;
}

// Post types
$pt = array();
if ( '' !== $posttypes ) {
	$posttypes = explode( ',', $posttypes );
	foreach ( $posttypes as $post_type ) {
		array_push( $pt, $post_type );
	}
	$query_args['post_type'] = $pt;
}

// Narrow by categories
if ( '' !== $categories ) {
	$categories = explode( ',', $categories );
	$gc = array();
	foreach ( $categories as $grid_cat ) {
		array_push( $gc, $grid_cat );
	}
	$gc = implode( ',', $gc );
	// http://snipplr.com/view/17434/wordpress-get-category-slug/
	$query_args['category_name'] = $gc;

	$taxonomies = get_taxonomies( '', 'object' );
	$query_args['tax_query'] = array( 'relation' => 'OR' );
	foreach ( $taxonomies as $t ) {
		if ( in_array( $t->object_type[0], $pt ) ) {
			$query_args['tax_query'][] = array(
				'taxonomy' => $t->name,
				'terms' => $categories,
				'field' => 'slug',
			);
		}
	}
}

// Order posts
if ( null !== $orderby ) {
	$query_args['orderby'] = $orderby;
}
$query_args['order'] = $order;

// Run query
$my_query = new WP_Query( $query_args );

$pretty_rel_random = ' data-rel="prettyPhoto[rel-' . get_the_ID() . '-' . rand() . ']"';
if ( 'custom_link' === $link ) {
	$custom_links = explode( ',', $custom_links );
}
$teasers = '';
$i = - 1;

if( isset( $tmpl ) && $tmpl == 'latest-works' )
{
	$items = '';
	$all_tags_arr = array();
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$posttags = get_the_tags();
		$tags_slug = array();
		if ( $posttags && count( $posttags ) > 0 ) 
		{
			foreach($posttags as $tag) 
			{
				$all_tags_arr[$tag->slug] = $tag; //USING JUST $tag MAKING $all_tags_arr A MULTI-DIMENSIONAL ARRAY, WHICH DOES WORK WITH array_unique
				$tags_slug[] = $tag->slug;
			}
		}

		$tags_slug = array_unique($tags_slug); //REMOVES DUPLICATES
		$tags_slug = implode( ' ', $tags_slug);

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$items .= '
		<div class="grid-item '.get_the_excerpt().' '.$tags_slug.'">
            <figure class="effect-phoebe"> <img src="'.$p_img_large.'" alt="">
              <figcaption>
                <p> <a href="' . get_permalink( $post_id ) . '"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="'.$p_img_large.'" title="'.get_the_title().'" data-lightbox-gallery="gallery5"><i class="fa fa-search effect-8"></i></a> </p>
              </figcaption>
            </figure>
          </div>
		';
	}
	wp_reset_query();
	$output = '
	<div class="row">
      <div class="col-md-12">
        <div id="filters" class="button-group">
          <button class="button is-checked" data-filter="*">'.esc_attr__( 'View All', 'js_composer' ).'</button>
          ';
          $tags ='';
          foreach( $all_tags_arr as $tag )
          {
          	$tags .='<button class="button" data-filter=".'.$tag->slug.'">'.$tag->name.'</button>';
          }
          $output .= $tags . '
        </div>
        <!-- end #filters --> 
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <!-- end .row -->
    <div class="row">
      <div class="col-md-12">
        <div class="isotope-masonry">
          	<div class="grid-sizer"></div>
			'.$items.'
        </div>
        <!-- end .isotope-masonry --> 
        
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <!-- end .row --> ';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'latest-works2' )
{
	$items = '';
	$all_tags_arr = array();
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$posttags = get_the_tags();
		$tags_slug = array();
		if ( $posttags && count( $posttags ) > 0) 
		{
			foreach($posttags as $tag) 
			{
				$all_tags_arr[$tag->slug] = $tag; //USING JUST $tag MAKING $all_tags_arr A MULTI-DIMENSIONAL ARRAY, WHICH DOES WORK WITH array_unique
				$tags_slug[] = $tag->slug;
			}
		}

		$tags_slug = array_unique($tags_slug); //REMOVES DUPLICATES
		$tags_slug = implode( ' ', $tags_slug);

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$items .= '
		<div class="grid-item '.get_the_excerpt().' '.$tags_slug.'">
            <figure class="effect-phoebe"> <img src="'.$p_img_large.'" alt="">
              <figcaption>
                <p> <a href="' . get_permalink( $post_id ) . '"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="'.$p_img_large.'" title="'.get_the_title().'" data-lightbox-gallery="gallery5"><i class="fa fa-search effect-8"></i></a> </p>
              </figcaption>
            </figure>
            <div class="clearfix"></div>
            <div class="photo-title3">
              <h5>'.get_the_title().'</h5>
              <p>'.esc_html( get_the_content() ).'</p>
            </div>
            <!-- end .photo-title3 --> 
          </div>
		';
	}
	wp_reset_query();
	$output = '<div class="container"><div class="row">
      <div class="col-md-12">
        <div id="filters" class="button-group">
          <button class="button is-checked" data-filter="*">'.esc_attr__( 'View All', 'js_composer' ).'</button>
          ';

          $tags = '';

          foreach( $all_tags_arr as $tag )
          {
          	$tags .='<button class="button" data-filter=".'.$tag->slug.'">'.$tag->name.'</button>';
          }
          $output .= $tags . '
        </div>
        <!-- end #filters --> 
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <!-- end .row -->
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="isotope-masonry">
        <div class="grid-sizer"></div>
			'.$items.'
        </div>
        <!-- end .isotope --> 
        
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <!-- end .row --> ';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'latest-projects' )
{
	$output = '<div class="owl-image owl-carousel owl-theme">';
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$output .= '
		<div class="item">
	        <figure class="effect-phoebe badge-new"> '.$post_thumbnail['thumbnail'].'
	          <figcaption>
	            <p> <a href="' . get_permalink( $post_id ) . '"><i class="fa fa-link effect-8"></i></a> <a  class="nivo-lightbox" href="'.$p_img_large.'" title="'.get_the_title().'" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-8"></i></a> </p>
	          </figcaption>
	        </figure>
	        <div class="clearfix"></div>
	        <div class="photo-title">
	          <h5>'.get_the_title().'</h5>
	          <p>'.get_the_excerpt().'</p>
	        </div>
	        <!-- end .photo-title --> 
	    </div>
		';
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'latest-projects2' )
{
	$output = '<div class="owl-image owl-carousel owl-theme">';
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$output .= '
		<div class="item">
	        <figure class="effect-phoebe"> '.$post_thumbnail['thumbnail'].'
	          <figcaption>
	            <p> <a href="' . get_permalink( $post_id ) . '"><i class="fa fa-link effect-8"></i></a> <a  class="nivo-lightbox" href="'.$p_img_large.'" title="'.get_the_title().'" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-8"></i></a> </p>
	          </figcaption>
	        </figure>
	    </div>
		';
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'owl' )
{
	$output = '<div class="owl-slider owl-carousel owl-theme">';
	$i = 1;
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];
		
		$thumb = "";

		if( preg_match( "/<!--more-->/", $my_query->post->post_content ) )
		{
			$text = explode("<!--more-->", $my_query->post->post_content );
			if( count( $text ) > 1 )
			{
				$thumb = $text[0];
				$text = $text[1];

				if( preg_match('/wp-image-\d+/', $thumb, $rs ) )
				{
					$thumb = str_replace( 'wp-image-', '', $rs[0] );
					list( $thumb, $w, $h ) = wp_get_attachment_image_src( $thumb, 'full' );
				}
			}
		}
		else
		{
			$text = get_the_content();
		}

		if( $i == 1 )
		{
			$output .= '
			<div class="item item1" style="background-image:url('.$p_img_large.')">
		      <div class="row">
		        <div class="col-sm-6">
		          <div class="owl-slider-left">
		            <div class="owl-caption">
		              <div class="owl-white-medium owl-fadeInUp delay5">'.get_the_title().'</div>
		            </div>
		            <!-- end .owl-caption -->
		            <div class="owl-caption">
		              <div class="owl-white-large owl-fadeInUp delay10">'.get_the_excerpt().'</div>
		            </div>
		            <!-- end .owl-caption -->
		            <div class="owl-caption">
		              <div class="owl-white-small owl-fadeInUp delay15">'.$text.'</div>
		            </div>
		            <!-- end .owl-caption --> 
		            <a href="' . get_permalink( $post_id ) . '" class="btn btn-lg btn-theme owl-fadeInUp delay20"><span><i class="fa fa-chevron-circle-right"></i></span>'.__( 'Read More', 'tour').'</a> </div>
		          <!-- end .owl-slider-left --> 
		        </div>
		        <!-- end .col-sm-6 -->
		        <div class="col-sm-6 hidden-xs"> <img src="'.$thumb.'" class="pull-left owl-fadeInUp delay25" alt="" /> </div>
		        <!-- end .col-sm-6 --> 
		      </div>
		      <!-- end .row --> 
		    </div>
		    <!-- end .item -->
	    	';
	    }
	    elseif( $i == 2 )
		{
			$output .= '
			<div class="item item2" style="background-image:url('.$p_img_large.')">
		      <div class="row">
		        <div class="col-sm-6 hidden-xs"> <img src="'.$thumb.'" class="pull-right owl-fadeInUp delay5" alt="" /> </div>
		        <!-- end .col-sm-6 -->
		        <div class="col-sm-6">
		          <div class="owl-slider-right">
		            <div class="owl-caption">
		              <div class="owl-white-medium owl-fadeInUp delay10">'.get_the_title().'</div>
		            </div>
		            <!-- end .owl-caption -->
		            <div class="owl-caption">
		              <div class="owl-white-large owl-fadeInUp delay15">'.get_the_excerpt().'</div>
		            </div>
		            <!-- end .owl-caption -->
		            <div class="owl-caption">
		              <div class="owl-white-small owl-fadeInUp delay20">'.$text.'</div>
		            </div>
		            <!-- end .owl-caption --> 
		            <a href="' . get_permalink( $post_id ) . '" class="btn btn-lg btn-theme owl-fadeInUp delay25"><span><i class="fa fa-chevron-circle-right"></i></span>'.__( 'Read More', 'tour').'</a> </div>
		          <!-- end .owl-slider-right --> 
		        </div>
		        <!-- end .col-sm-6 --> 
		      </div>
		      <!-- end .row --> 
		    </div>
		    <!-- end .item -->';
	    }
	    elseif( $i == 3 )
		{
			$output .= '
			<div class="item item3" style="background-image:url('.$p_img_large.')">
		      <div class="row">
		        <div class="col-sm-12">
		          <div class="owl-slider-center">
		            <div class="owl-caption">
		              <div class="owl-white-medium owl-fadeInUp delay5">'.get_the_title().'</div>
		            </div>
		            <!-- end .owl-caption -->
		            <div class="owl-caption">
		              <div class="owl-white-large owl-fadeInUp delay10">'.get_the_excerpt().'</div>
		            </div>
		            <!-- end .owl-caption -->
		            <div class="owl-caption">
		              <div class="owl-white-small owl-fadeInUp delay15">'.get_the_content().'</div>
		            </div>
		            <!-- end .owl-caption --> 
		            <a href="#" class="btn btn-lg btn-theme owl-fadeInUp delay20"><span><i class="fa fa-chevron-circle-right"></i></span>'.__( 'Read More', 'tour').'</a> </div>
		          <!-- end .owl-slider-center --> 
		        </div>
		        <!-- end .col-sm-12 --> 
		      </div>
		      <!-- end .row --> 
		    </div>
		    <!-- end .item --> ';
	    }

		if( $i == 3 )
		{
			$i = 0;
		}

		$i ++;
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'testimonials' )
{
	$output = '<div class="owl-testimonial owl-carousel owl-theme">';
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$output .= '
		 <div>
            <div class="testimonial">
              <p class="lead">'.get_the_content().'</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author"> <img class="frame" src="'.$p_img_large.'" alt="" />
              <p>'.get_the_title().'<br>
                <span class="text-blue">'.get_the_excerpt().'</span></p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
		';
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'testimonials2' )
{
	$output = '<div class="owl-testimonial owl-carousel owl-theme">';
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$output .= '
		 <div>
            <div class="testimonial">
              <p class="lead">'.get_the_content().'</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author"> <img class="frame" src="'.$p_img_large.'" alt="" />
              <p>'.get_the_title().'</p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
		';
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'teams' )
{
	$output = '<div class="owl-image owl-carousel owl-theme">';
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size  ) );
		$p_img_large = $post_thumbnail['p_img_large'][0];

		$output .= '
		<div class="item">
	      <div class="team">
	        <figure class="effect-phoebe"> '.$post_thumbnail['thumbnail'].'
	          <figcaption>
	            <p> <a href="#"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="'.$p_img_large.'" title="'.get_the_title().'"><i class="fa fa-search effect-8"></i></a> </p>
	          </figcaption>
	        </figure>
	        <div class="clearfix"></div>
	        <div class="team-content">
	          <h4 data-toggle="tooltip" data-placement="top" title="'.get_the_title().'">'.get_the_title().'<br>
	            <small>'.get_the_excerpt().'</small></h4>
	          '.get_the_content().'
	          <div class="clearfix"></div>
	        </div>
	        <!-- end .team-content --> 
	      </div>
	      <!-- end .team --> 
	    </div>
	    <!-- end .item -->
		';
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'accordion' )
{
	$id = rand(0,1000);
	$output = '<div class="panel-group" id="accordion-'.$id.'">';
	$ii = 0;
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$output .= '
		<div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"><a class="'.( $ii == 0 ? '' : 'collapsed' ).'" data-toggle="collapse" data-parent="#accordion-'.$id.'" href="#collapseOne-'.$post_id.'">'.get_the_title().'</a></h4>
            </div>
            <div id="collapseOne-'.$post_id.'" class="panel-collapse collapse '.( $ii == 0 ? 'in' : '' ).'">
              <div class="panel-body">
                <p>'.get_the_content().'</p>
              </div>
            </div>
          </div>
          <!-- end .panel -->
		';
		$ii++;
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'accordion2' )
{
	$id = rand(0,1000);
	$output = '<div class="toggle-container">';
	$ii = 0;
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$output .= '
			<h4>'.get_the_title().'</h4>
	        <div class="toggle-content">
	            '.get_the_content().'
	          </div>
		';
		$ii++;
	}
	wp_reset_query();
	$output .= '</div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'tab2' )
{
	$id = rand(0,1000);
	$title = '';
	$content = '';
	$output = '<div class="tab-side-container"><ul>';
	$ii = 0;
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$title .= "<li><a href='#side-tab-".$post_id."'>".get_the_title()."</a></li>";
		$content .= '
		<div id="side-tab-'.$post_id.'">
          '.get_the_content().'
        </div>
		';

	}
	wp_reset_query();
	$output .= $title.'</ul>
          <div class="panel-container">'.$content.'</div></div>';
	echo $output;
}
elseif( isset( $tmpl ) && $tmpl == 'tab' )
{
	$id = rand(0,1000);
	$title = '';
	$content = '';
	$output = '<div class="tab-container"><ul class="etabs">';
	$ii = 0;
	while ( $my_query->have_posts() ) {
		$my_query->the_post();
		$post_title = the_title( '', '', false );
		$post_id = $my_query->post->ID;
		if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
			continue;
		}

		$title .= "<li class='tab'><a href='#nested-tab-".$post_id."'>".get_the_title()."</a></li>";
		$content .= '
		<div id="nested-tab-'.$post_id.'">
          '.get_the_content().'
        </div>
		';

	}
	wp_reset_query();
	$output .= $title.'</ul>
          <div class="panel-container">'.$content.'</div></div>';
	echo $output;
}
else 
{

while ( $my_query->have_posts() ) {
	$i ++;
	$my_query->the_post();
	$post_title = the_title( '', '', false );
	$post_id = $my_query->post->ID;
	if ( in_array( get_the_ID(), $vc_posts_grid_exclude_id ) ) {
		continue;
	}
	if ( 'teaser' === $slides_content ) {
		$content = apply_filters( 'the_excerpt', get_the_excerpt() );
	} else {
		$content = '';
	}
	$thumbnail = '';

	// Thumbnail logic
	$post_thumbnail = $p_img_large = '';

	$post_thumbnail = wpb_getImageBySize( array( 'post_id' => $post_id, 'thumb_size' => $thumb_size ) );
	$thumbnail = $post_thumbnail['thumbnail'];
	$p_img_large = $post_thumbnail['p_img_large'];

	// Link logic
	if ( 'link_no' !== $link ) {
		if ( 'link_post' === $link ) {
			$link_image_start = '<a class="link_image" href="' . get_permalink( $post_id ) . '" title="' . sprintf( esc_attr__( 'Permalink to %s', 'js_composer' ), the_title_attribute( 'echo=0' ) ) . '">';
		} elseif ( 'link_image' === $link ) {
			$p_video = get_post_meta( $post_id, '_p_video', true );
			//
			if ( '' !== $p_video ) {
				$p_link = $p_video;
			} else {
				$p_link = $p_img_large[0];
			}
			$link_image_start = '<a class="link_image prettyphoto" href="' . $p_link . '" ' . $pretty_rel_random . ' title="' . the_title_attribute( 'echo=0' ) . '" >';
		} elseif ( 'custom_link' === $link ) {
			if ( isset( $custom_links[ $i ] ) ) {
				$slide_custom_link = $custom_links[ $i ];
			} else {
				$slide_custom_link = $custom_links[0];
			}
			$link_image_start = '<a class="link_image" href="' . $slide_custom_link . '">';
		}

		$link_image_end = '</a>';
	} else {
		$link_image_start = '';
		$link_image_end = '';
	}

	$description = '';
	if ( '' !== $slides_content && '' !== $content && ( ' wpb_flexslider flexslider_fade flexslider' === $type || ' wpb_flexslider flexslider_slide flexslider' === $type ) ) {
		$description = '<div class="flex-caption">';
		if ( $slides_title ) {
			$description .= '<h2 class="post-title">' . $link_image_start . $post_title . $link_image_end . '</h2>';
		}
		$description .= $content;
		$description .= '</div>';
	}

	$teasers .= $el_start . $link_image_start . $thumbnail . $link_image_end . $description . $el_end;
} // endwhile loop
wp_reset_query();

if ( $teasers ) {
	$teasers = $slides_wrap_start . $teasers . $slides_wrap_end;
} else {
	$teasers = __( 'Nothing found.', 'js_composer' );
}

$class_to_filter = 'wpb_gallery wpb_posts_slider wpb_content_element';
$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class );
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );

$output = '
	<div class="' . esc_attr( $css_class ) . '">
		<div class="wpb_wrapper">
			' . wpb_widget_title( array( 'title' => $title, 'extraclass' => 'wpb_posts_slider_heading' ) ) . '
			<div class="wpb_gallery_slides' . $type . '" data-interval="' . $interval . '"' . $flex_fx . '>' . $teasers . '</div>
		</div>
	</div>
';

echo $output;
}