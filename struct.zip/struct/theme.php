<?php
function struct_page_title()
{
	ob_start();
	require_once( __DIR__ . '/l/breadcrumb.php' );
	$breadcrumb = new StructBreadcrumb();
	$breadcrumb->add_crumb( _x( 'Home', 'breadcrumb', 'struct' ), apply_filters( 'struct_breadcrumb_home_url', home_url( '/' ) ) );
	$breadcrumb = $breadcrumb->generate();
	$wrap_before = '<ul class="breadcrumb">';
	$before = '';
	$after = '';
	$delimiter = '';
	$wrap_after = '</ul>';
	$breadcrumb_html = $wrap_before;

	foreach ( $breadcrumb as $key => $crumb ) {

		$breadcrumb_html .=  $before;

		if ( ! empty( $crumb[1] ) && sizeof( $breadcrumb ) !== $key + 1 ) {
			$breadcrumb_html .=  '<li><a href="' . esc_url( $crumb[1] ) . '">' . esc_html( $crumb[0] ) . '</a></li>';
		} else {
			$breadcrumb_html .=  '<li class="active">' . esc_html( $crumb[0] ) . '</li>';
		}

		$breadcrumb_html .=  $after;

		if ( sizeof( $breadcrumb ) !== $key + 1 ) {
			$breadcrumb_html .=  $delimiter;
		}

	}

	$breadcrumb_html .=  $wrap_after;

	require_once( __DIR__ . '/tmpl/page-title.php' );
	echo ob_get_clean();
}
add_action( 'page_title', 'struct_page_title' );

add_filter( 'get_custom_logo', 'struct_custom_logo' );
// Filter the output of logo to fix Googles Error about itemprop logo
function struct_custom_logo() 
{
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    $html = sprintf( '<a href="%1$s" class="navbar-brand">%2$s</a>',
            esc_url( home_url( '/' ) ),
            wp_get_attachment_image( $custom_logo_id, 'full', false, array(
                'class'    => 'img-responsive',
            ) )
        );
    return $html;   
}

add_filter( 'megamenu_nav_menu_args', 'struct_megamenu_nav_menu_args' );
function struct_megamenu_nav_menu_args( $args )
{
	$args['container_class'] .= ' nav navbar-nav navbar-right';
	
	return $args;
}

add_filter( 'widget_nav_menu_args', 'swidget_nav_menu_args', 10, 4 );
function swidget_nav_menu_args( $nav_menu_args, $nav_menu, $args, $instance )
{
	if( preg_match( '/social-icons social-color/', @$nav_menu_args['items_wrap'] ) )
	{
		return $nav_menu_args;
	}

	if( isset( $args ) && preg_match( '/titleline-footer/', @$args[ 'after_title' ] ) )
	{
		$nav_menu_args['items_wrap'] = '<ul id="%1$s" class="footer-list %2$s">%3$s</ul>';
		$nav_menu_args['before'] = '<i class="fa fa-angle-right"></i>';
	}

	if( isset( $args[ 'id' ] ) && $args[ 'id' ] == 'wtop-b' )
	{
		$nav_menu_args['items_wrap'] = '<ul id="%1$s" class="social-icons %2$s">%3$s</ul>';
	}
	
	return $nav_menu_args;
}
/**
105	                 * Filters the CSS class(es) applied to a menu item's list item element.
106	                 *
107	                 * @since 3.0.0
108	                 * @since 4.1.0 The `$depth` parameter was added.
109	                 *
110	                 * @param array  $classes The CSS classes that are applied to the menu item's `<li>` element.
111	                 * @param object $item    The current menu item.
112	                 * @param array  $args    An array of wp_nav_menu() arguments.
113	                 * @param int    $depth   Depth of menu item. Used for padding.
114	                 */
if( !function_exists( 'struct_widget_nav_menu_css_class' ) )
{
	function struct_widget_nav_menu_css_class( $classes = array(), $item, $args = array() )
	{
		if( preg_match( '/social-icons/', @$args->items_wrap ) )
		{
			foreach( $classes as $i => $item )
			{
				if( preg_match( '/fa|fa-/', $item ) )
				{
					unset( $classes[ $i ] );
				}
			}
		}
		return $classes;
	}
}
add_filter( 'nav_menu_css_class', 'struct_widget_nav_menu_css_class', 20, 3 );
/**
172	                 * Filters a menu item's title.
173	                 *
174	                 * @since 4.4.0
175	                 *
176	                 * @param string $title The menu item's title.
177	                 * @param object $item  The current menu item.
178	                 * @param array  $args  An array of wp_nav_menu() arguments.
179	                 * @param int    $depth Depth of menu item. Used for padding.
180	                 */
if( !function_exists( 'struct_widget_nav_menu_item_title' ) )
{
	function struct_widget_nav_menu_item_title( $title = '', $item, $args = array() )
	{
		$icon = array();
		if( preg_match( '/social-icons/', @$args->items_wrap ) )
		{
			if( is_array( $item->classes ) )
			{
				foreach ($item->classes as $i => $c) 
				{
					if( preg_match( '/fa|fa-/', $c ) )
					{
						$icon[] = $c;
					}
				}
				if( count( $icon ) > 0 )
				{
					$title = '<i class="'. implode( ' ', $icon ) . '"></i>';
				}
			}
		}
		return $title;
	}
}
add_filter( 'nav_menu_item_title', 'struct_widget_nav_menu_item_title', 20, 3 );

add_filter( 'the_content_more_link', 'struct_modify_read_more_link' );
if( !function_exists( 'struct_modify_read_more_link' ) )
{
	function struct_modify_read_more_link( $link ) 
	{
	    $link = str_replace( 'more-link', 'btn btn-theme more-link', $link );
		return $link;
	}
}
if( !function_exists( 'struct_plg_list_comments' ) )
{
	function struct_plg_list_comments()
	{
		wp_list_comments( array(
			'style'       => 'ol',
			'short_ping'  => true,
			'avatar_size' => 80,
			'callback' => 'struct_comments_item'
		) );
	}
}
/**
 * Outputs a single comment.
 *
 * @since 3.6.0
 * @access protected
 *
 * @see wp_list_comments()
 *
 * @param WP_Comment $comment Comment to display.
 * @param int        $depth   Depth of the current comment.
 * @param array      $args    An array of arguments.
 */
//add_action( 'struct_comments_item', 'struct_comments_item', 10, 3 );
if( !function_exists( 'struct_comments_item' ) )
{
	function struct_comments_item( $comment, $args, $depth ) 
	{
		ob_start();
	    if ( 'div' == $args['style'] ) {
            $tag = 'div';
            $add_below = 'comment';
        } else {
            $tag = 'li';
            $add_below = 'div-comment';
        }
        require( __DIR__ . '/tmpl/comment.php' );
        echo ob_get_clean();
	}
}
/**
496	         * Filter the returned CSS classes for the current comment.
497	         *
498	         * @since 2.7.0
499	         *
500	         * @param array       $classes    An array of comment classes.
501	         * @param string      $class      A comma-separated list of additional classes added to the list.
502	         * @param int         $comment_id The comment id.
503	         * @param WP_Comment  $comment    The comment object.
504	         * @param int|WP_Post $post_id    The post ID or WP_Post object.
505	         */
add_filter( 'comment_class', 'struct_comment_class', 10, 5 );
if( !function_exists( 'struct_comment_class' ) )
{
	function struct_comment_class( $classes, $class, $comment_id, $comment, $post_id ) 
	{
		foreach ( $classes as $key => $value) {
			if( $value == 'comment' )
			{
				unset( $classes[ $key ] );
			}
		}
	    return $classes;
	}
}
/**
1609	         * Filter the comment reply link.
1610	         *
1611	         * @since 2.7.0
1612	         *
1613	         * @param string  $link    The HTML markup for the comment reply link.
1614	         * @param array   $args    An array of arguments overriding the defaults.
1615	         * @param object  $comment The object of the comment being replied.
1616	         * @param WP_Post $post    The WP_Post object.
1617	         */
add_filter( 'comment_reply_link', 'struct_comment_reply_link', 10, 4 );
if( !function_exists( 'struct_comment_reply_link' ) )
{
	function struct_comment_reply_link( $link, $args, $comment, $post ) 
	{
		return str_replace( 'comment-reply-link', 'btn btn-theme comment-reply-link', $link );
	}
}
/**
 * Filters the given oEmbed HTML.
 *
 * If the `$url` isn't on the trusted providers list,
 * we need to filter the HTML heavily for security.
 *
 * Only filters 'rich' and 'html' response types.
 *
 * @since 4.4.0
 *
 * @param string $result The oEmbed HTML result.
 * @param object $data   A data object result from an oEmbed provider.
 * @param string $url    The URL of the content to be embedded.
 * @return string The filtered and sanitized oEmbed result.
 */
if( !function_exists( 'struct_embed_oembed_html' ) )
{
	function struct_embed_oembed_html( $html, $url, $attr, $post_id )
	{
		if( get_post_type() != 'post' )
		{
			return $html;
		}
		return "";
	}
}
add_filter( 'embed_oembed_html', 'struct_embed_oembed_html', 20, 4 );

if( !function_exists( 'struct_embed_get_html' ) )
{
	function struct_embed_get_html( $echo = false )
	{
		$rs = "";
		$urls = wp_extract_urls( get_the_content() );
		if( count( $urls ) > 0 )
		{
			foreach ( $urls as $url ) 
			{
				if( preg_match( '/#more-/', $url ) )
				{
					continue;
				}
				$embed = wp_kses( 
					wp_oembed_get( $url ),
					array( 'iframe' => array( 'src' => true, 'width' => true, 'height' => true ) )
				);
				$rs .= $embed;
			}
		}
		if( $echo )
		{
			echo $rs;
		}

		return $rs;
	}
}
add_filter( 'struct_embed_get_html', 'struct_embed_get_html' );

add_filter( 'struct_tpl_post', 'struct_tpl_post_item' );
if( !function_exists( 'struct_tpl_post_item' ) )
{
	function struct_tpl_post_item( $post_id )
	{
		$tpl = get_post_meta( $post_id, 'cat_tmpl', true );
		
		if( in_array( $tpl, array( '', '0mid' ) ) )
		{
			return $tpl;
		}

		return '';
	}
}

add_action( 'add_meta_boxes', 'struct_tmpl_post');

//Register Meta Box
function struct_tmpl_post() {
    add_meta_box( 'struct_tmpl_post', esc_html__( 'Template config', 'struct' ), 'struct_tmpl_post_callback', 'post', 'advanced', 'high' );
}
if( !function_exists( 'struct_tpl_post_single_content' ) )
{
	function struct_tpl_post_single_content()
	{
		ob_start();
	    require( __DIR__ . '/tmpl/sp-content.php' );
		echo ob_get_clean();
	}
}
add_action( 'struct_tpl_post_single_content', 'struct_tpl_post_single_content');

if( !function_exists( 'struct_tpl_post_single_related' ) )
{
	function struct_tpl_post_single_related()
	{
		ob_start();
	    require( __DIR__ . '/tmpl/sp-related.php' );
		echo ob_get_clean();
	}
}
add_action( 'struct_tpl_post_single_related', 'struct_tpl_post_single_related');
 
//Add field
function struct_tmpl_post_callback( $post ) 
{
 
 	ob_start();
    $cat_tmpl = get_post_meta( $post->ID, 'cat_tmpl', true );
    $in_post = get_post_meta( $post->ID, 'in_post', true );
    require( __DIR__ . '/tmpl/tmpl-field-cat.php' );
}
/**
 * Save meta box content.
 *
 * @param int $post_id Post ID
 */
function struct_save_meta_box( $post_id ) {
	if( isset( $_POST[ 'cat_tmpl' ] ) )
	{
    	update_post_meta( $post_id, 'cat_tmpl', $_POST[ 'cat_tmpl' ] );
    }
    if( isset( $_POST[ 'in_post' ] ) )
	{
    	update_post_meta( $post_id, 'in_post', $_POST[ 'in_post' ] );
    }
}
add_action( 'save_post', 'struct_save_meta_box' );
if( !function_exists( 'struct_blog_before_main_content' ) )
{
	function struct_blog_before_main_content()
	{
		$tmpl = apply_filters( 'struct_tpl_post_single', get_the_ID() );
		if( function_exists( 'is_single' ) && is_single() && $tmpl == 'sp' )
		{
			return;
		}
		if ( is_active_sidebar( 'sidebar-1' )  )
		{
			echo '<div class="row"><div id="blog" class="col-md-9">';
		}
	}
}
add_action( 'struct_blog_before_main_content', 'struct_blog_before_main_content' );
if( !function_exists( 'struct_blog_after_main_content' ) )
{
	function struct_blog_after_main_content()
	{
		$tmpl = apply_filters( 'struct_tpl_post_single', get_the_ID() );
		if( function_exists( 'is_single' ) && is_single() && $tmpl == 'sp' )
		{
			return;
		}
		if ( is_active_sidebar( 'sidebar-1' )  )
		{
			echo '</div><div class="col-md-3">';
			get_sidebar();
			echo '</div></div>';
		}
	}
}
add_action( 'struct_blog_after_main_content', 'struct_blog_after_main_content' );

if( !function_exists( 'struct_post_navigation' ) )
{
	function struct_post_navigation( $args = array() )
	{
		$args = wp_parse_args( $args, array(
	        'prev_text'          => '%title',
	        'next_text'          => '%title',
	        'in_same_term'       => false,
	        'excluded_terms'     => '',
	        'taxonomy'           => 'category',
	        'screen_reader_text' => __( 'Post navigation' ),
	    ) );
	 
	    $previous = get_previous_post_link(
	        '%link',
	        $args['prev_text'],
	        $args['in_same_term'],
	        $args['excluded_terms'],
	        $args['taxonomy']
	    );
	 
	    $next = get_next_post_link(
	        '%link',
	        $args['next_text'],
	        $args['in_same_term'],
	        $args['excluded_terms'],
	        $args['taxonomy']
	    );
	 
	    // Only add markup if there's somewhere to navigate to.
	    if ( $previous || $next ) {
	        ob_start();
	        require( __DIR__ . '/tmpl/post_nav.php' );
	        echo ob_get_clean();
	    }
	}
}
add_action( 'struct_posts_pagination', 'struct_posts_pagination', 200 );
if( !function_exists( 'struct_posts_pagination' ) )
{
	function struct_posts_pagination( $args = array() )
	{
		
        // Don't print empty markup if there's only one page.
        if ( $GLOBALS['wp_query']->max_num_pages > 1 ) {
            $args = wp_parse_args( $args, array(
                    'mid_size'           => 1,
                    'prev_text'          => __( 'Previous' ),
                    'next_text'          => __( 'Next' ),
                    'screen_reader_text' => __( 'Posts navigation' ),
                    'type'				 => 'array'
            ) );

            
            // Set up paginated links.
            $links = paginate_links( $args );

            if ( count( $links ) > 0 ) {
                ob_start();
		        require( __DIR__ . '/tmpl/posts_nav.php' );
		        echo ob_get_clean();
            }
        }
	}
}
add_action( 'struct_post_navigation', 'struct_post_navigation', 200 );


if( !function_exists( 'struct_woocommerce_widget_cart_is_hidden' ) )
{
	function struct_woocommerce_widget_cart_is_hidden()
	{
		return false;
	}
}
add_filter( 'woocommerce_widget_cart_is_hidden', 'struct_woocommerce_widget_cart_is_hidden' );

if( !function_exists( 'struct_menu_o' ) )
{
	function struct_menu_o()
	{
		wp_enqueue_script( 'struct-smoothScroll', get_template_directory_uri() . '/js/smooth-scroll.js', array( 'jquery' ), '20160816', true );
		wp_add_inline_script( 'struct-smoothScroll', "
			smoothScroll.init({
				speed: 1000,
				easing: 'easeInOutCubic',
				offset: (function($){
					return $('#header').outerHeight(true) + $('#wpadminbar').outerHeight(true)
				})(jQuery),
				updateURL: false
			});
		" );
	}
}
add_action( 'struct_menu_o', 'struct_menu_o' );
/**
 * Filters the HTML list content for navigation menus.
 *
 * @since 3.0.0
 *
 * @see wp_nav_menu()
 *
 * @param string $items The HTML list content for the menu items.
 * @param object $args  An object containing wp_nav_menu() arguments.
 */
if( !function_exists( 'struct_nav_menu_o_items' ) )
{
	function struct_nav_menu_o_items( $items = '', $args = object )
	{
		if( isset( $args->theme_location ) && $args->theme_location == 'primary-o' )
		{
			foreach( array( '/href="#/' => 'href="#', "/href='#/" => "href='#" ) as $reg => $attr )
			{
				$items = preg_replace( $reg, "data-scroll {$attr}", $items );
			}
		}
		return $items;
	}
}
add_filter( 'wp_nav_menu_items', 'struct_nav_menu_o_items', 20, 2 );


if( !function_exists( 'export_struct' ) )
{
	function export_struct()
	{
		$theme = wp_get_theme();

		if( $theme->get( 'Author' ) != 'saihoai' )
		{
			return false;
		}

		$opts = array(
			'widget_categories',
			'widget_search',
			'widget_recent-posts',
			'widget_archives',
			'widget_meta',
			'sidebars_widgets',
			'widget_calendar',
			'widget_tag_cloud',
			'widget_nav_menu',
			'theme_mods_struct',
			'megamenu_settings',
			'widget_icl_lang_sel_widget',
			'megamenu_themes',
			'megamenu_toggle_blocks',
			'widget_flickr',
			'widget_contact',
			'widget_about',
			'widget_phone',
			'widget_dropdown_search',
			'widget_recent-posts2',
			'woocommerce_default_country',
			'woocommerce_allowed_countries',
			'woocommerce_all_except_countries',
			'woocommerce_specific_allowed_countries',
			'woocommerce_ship_to_countries',
			'woocommerce_specific_ship_to_countries',
			'woocommerce_default_customer_address',
			'woocommerce_calc_taxes',
			'woocommerce_demo_store',
			'woocommerce_demo_store_notice',
			'woocommerce_currency',
			'woocommerce_currency_pos',
			'woocommerce_price_thousand_sep',
			'woocommerce_price_decimal_sep',
			'woocommerce_price_num_decimals',
			'woocommerce_weight_unit',
			'woocommerce_dimension_unit',
			'woocommerce_enable_review_rating',
			'woocommerce_review_rating_required',
			'woocommerce_review_rating_verification_label',
			'woocommerce_review_rating_verification_required',
			'woocommerce_shop_page_id',
			'woocommerce_shop_page_display',
			'woocommerce_category_archive_display',
			'woocommerce_default_catalog_orderby',
			'woocommerce_cart_redirect_after_add',
			'woocommerce_enable_ajax_add_to_cart',
			'shop_catalog_image_size',
			'shop_single_image_size',
			'shop_thumbnail_image_size',
			'woocommerce_enable_lightbox',
			'woocommerce_manage_stock',
			'woocommerce_hold_stock_minutes',
			'woocommerce_notify_low_stock',
			'woocommerce_notify_no_stock',
			'woocommerce_stock_email_recipient',
			'woocommerce_notify_low_stock_amount',
			'woocommerce_notify_no_stock_amount',
			'woocommerce_hide_out_of_stock_items',
			'woocommerce_stock_format',
			'woocommerce_file_download_method',
			'woocommerce_downloads_require_login',
			'woocommerce_downloads_grant_access_after_payment',
			'woocommerce_prices_include_tax',
			'woocommerce_tax_based_on',
			'woocommerce_shipping_tax_class',
			'woocommerce_tax_round_at_subtotal',
			'woocommerce_tax_classes',
			'woocommerce_tax_display_shop',
			'woocommerce_tax_display_cart',
			'woocommerce_price_display_suffix',
			'woocommerce_tax_total_display',
			'woocommerce_enable_shipping_calc',
			'woocommerce_shipping_cost_requires_address',
			'woocommerce_ship_to_destination',
			'woocommerce_enable_coupons',
			'woocommerce_calc_discounts_sequentially',
			'woocommerce_enable_guest_checkout',
			'woocommerce_force_ssl_checkout',
			'woocommerce_unforce_ssl_checkout',
			'woocommerce_cart_page_id',
			'woocommerce_checkout_page_id',
			'woocommerce_terms_page_id',
			'woocommerce_checkout_pay_endpoint',
			'woocommerce_checkout_order_received_endpoint',
			'woocommerce_myaccount_add_payment_method_endpoint',
			'woocommerce_myaccount_delete_payment_method_endpoint',
			'woocommerce_myaccount_set_default_payment_method_endpoint',
			'woocommerce_myaccount_page_id',
			'woocommerce_enable_signup_and_login_from_checkout',
			'woocommerce_enable_myaccount_registration',
			'woocommerce_enable_checkout_login_reminder',
			'woocommerce_registration_generate_username',
			'woocommerce_registration_generate_password',
			'woocommerce_myaccount_orders_endpoint',
			'woocommerce_myaccount_view_order_endpoint',
			'woocommerce_myaccount_downloads_endpoint',
			'woocommerce_myaccount_edit_account_endpoint',
			'woocommerce_myaccount_edit_address_endpoint',
			'woocommerce_myaccount_payment_methods_endpoint',
			'woocommerce_myaccount_lost_password_endpoint',
			'woocommerce_logout_endpoint',
			'woocommerce_email_from_name',
			'woocommerce_email_from_address',
			'woocommerce_email_header_image',
			'woocommerce_email_footer_text',
			'woocommerce_email_base_color',
			'woocommerce_email_background_color',
			'woocommerce_email_body_background_color',
			'woocommerce_email_text_color',
			'woocommerce_api_enabled',
			'woocommerce_admin_notices',
			'widget_woocommerce_widget_cart',
			'widget_woocommerce_layered_nav_filters',
			'widget_woocommerce_layered_nav',
			'widget_woocommerce_price_filter',
			'widget_woocommerce_product_categories',
			'widget_woocommerce_product_search',
			'widget_woocommerce_product_tag_cloud',
			'widget_woocommerce_products',
			'widget_woocommerce_rating_filter',
			'widget_woocommerce_recent_reviews',
			'widget_woocommerce_recently_viewed_products',
			'widget_woocommerce_top_rated_products',
			'woocommerce_paypal-braintree_settings',
			'woocommerce_stripe_settings',
			'woocommerce_paypal_settings',
			'woocommerce_cheque_settings',
			'woocommerce_bacs_settings',
			'woocommerce_cod_settings',
			'woocommerce_allow_tracking',
			//'icl_sitepress_settings',
			//'wpml_dependencies:needs_validation',
			//'wpml_dependencies:valid_plugins',
			//'wpml_config_index',
			//'wpml_config_files_arr',
			//'icl_admin_messages',
			//'wpml_dependencies:installed_plugins',
			'widget_icl_lang_sel_widget',
			'megamenu_settings',
			'megamenu_themes',
			'megamenu_toggle_blocks',
			'widget_phone',
			'widget_dropdown_search',
			'wpcf7',
			'widget_recent-posts2',
			'show_on_front',
			'page_on_front',
			'revslider-global-settings'
		);
		$data = array();
		foreach( $opts as $item )
		{
			$data[ $item ] = get_option( $item );
		}
		file_put_contents( __DIR__ . '/d/o.txt', json_encode( $data ) );
	}
}
add_action( 'export_wp', 'export_struct' );

if( !function_exists( 'import_struct' ) )
{
	function import_struct()
	{
		$theme = wp_get_theme();

		if( $theme->get( 'Author' ) != 'saihoai' )
		{
			return false;
		}

		$path = __DIR__ . '/d/o0.txt';

		if( !file_exists( $path ) )
		{
			return false;
		}

		$path_terms = __DIR__ . '/d/terms.txt';
		if( !file_exists( $path_terms ) )
		{
			return false;
		}

		$data_terms = json_decode( file_get_contents( $path_terms ), true );
		if( count( $data_terms ) < 1 )
		{
			return false;
		}

		$data = json_decode( file_get_contents( $path ), true );

		if( count( $data ) <= 0 )
		{
			return false;
		}
		foreach( $data as $k => $v )
		{
			if( $k == 'theme_mods_struct' )
			{
				$menu_location = array(
					'primary' => 'Main menu',
					'primary-o' => 'Menu Optional',
					'footer'  => 'Footer Links',
				);
				$locations = array();
				foreach( $menu_location as $slug => $title )
				{
					if( $menu = get_term_by( 'name', $title, 'nav_menu' ) )
					{
						$locations[ $slug ] = $menu->term_id;
					}
				}
				if( count( $locations ) > 0 )
				{
					set_theme_mod( 'nav_menu_locations', $locations );
				}
				$v = maybe_unserialize( $v );
				foreach( array( 'custom_logo', 'copyright', 'scol', 'sitems' ) as $item )
				{
					if( isset( $v[ $item ] ) && !empty( $v[ $item ] ) )
					{
						set_theme_mod( $item, $v[ $item ] );
					}
				}
			}
			else
			{
				update_option( $k, $v, true );
			}
		}

		foreach( array( 'widget_nav_menu', 'widget_about' ) as $key )
		{
			do_action( 'import_struct_widget_option_menu', $data_terms, $data, $key );
		}

		if( get_option( 'show_on_front' ) == 'page' && ( $page = get_page_by_title( 'Home 1' ) ) )
		{
			update_option( 'page_on_front', $page->ID );
		}

		// import revslider
		$updateAnim = true;
		$updateNav = true;
		$updateStatic = "none";
		$rv_slider_path = plugin_dir_path( __DIR__ ) . '/revslider/includes/slider.class.php';
		if( file_exists( $rv_slider_path ) ) 
		{
			if( !function_exists( 'RevSlider' ) )
			{
				require_once( $rv_slider_path );
			}
			$slider = new RevSlider();
			$files = glob( __DIR__ . '/d/revslider/*.zip' );
			if( count( $files ) > 0 )
			{
				foreach( $files as $file )
				{

					if( $slider->isAliasExistsInDB( basename( $file, '.zip' ) ) )
					{
						continue;
					}
					$slider->importSliderFromPost($updateAnim, $updateStatic, $file, false, false, $updateNav);
				}
			}
		}

		// delete files tmp
		foreach( array( $path, __DIR__ . '/d/cates.txt', __DIR__ . '/d/terms.txt' ) as $p )
		{
			if( file_exists( $p ) )
			{
				unlink( $p );
			}
		}
		
	}
}
add_action( 'import_end', 'import_struct' );

if( !function_exists( 'import_struct_widget_option_menu' ) )
{
	function import_struct_widget_option_menu( $data_terms = array(), $data = array(),  $k = '' )
	{
		$v = $data[ $k ];
		$v = maybe_unserialize( $v );
		if( is_array( $v ) && count( $v ) > 0 )
		{
			foreach( $v as $i => $item )
			{
				$title = '';
				foreach( $data_terms as $term )
				{
					if( $term[ 'term_id' ] == $item[ 'nav_menu' ] )
					{
						$title = $term[ 'term_name' ];
						break;
					}
				}
				if( $menu = get_term_by( 'name', $title, 'nav_menu' ) )
				{
					$v[ $i ][ 'nav_menu' ] = $menu->term_id;
				}
			}
			update_option( $k, $v, true );
		}
	}
}
add_action( 'import_struct_widget_option_menu', 'import_struct_widget_option_menu', 10, 3 );

if( !function_exists( 'struct_cache_wp_import_terms' ) )
{
	function struct_cache_wp_import_terms( $data )
	{
		if( is_array( $data ) && count( $data ) )
		{
			file_put_contents( __DIR__ . '/d/terms.txt', json_encode( $data ) );
		}
		return $data;
	}
}
add_filter( 'wp_import_terms', 'struct_cache_wp_import_terms' );

if( !function_exists( 'struct_cache_wp_import_cates' ) )
{
	function struct_cache_wp_import_cates( $data )
	{
		if( is_array( $data ) && count( $data ) )
		{
			file_put_contents( __DIR__ . '/d/cates.txt', json_encode( $data ) );
		}
		return $data;
	}
}
add_filter( 'wp_import_categories', 'struct_cache_wp_import_cates' );

if( !function_exists( 'struct_wp_import_post_data_raw' ) )
{
	function struct_wp_import_post_data_raw( $item = array() )
	{
		// post_type == nav_menu_item
		if( 'nav_menu_item' == $item['post_type'] && is_array( $item['postmeta'] ) && count( $item['postmeta'] ) > 0 )
		{
			$im = -1;
			$ifn = -1;
			foreach ( $item['postmeta'] as $i => $meta )
			{
				if( $meta[ 'key' ] == '_menu_item_xfn' )
				{
					$ifn = $i;
					continue;
				}
				elseif( $meta[ 'key' ] == '_megamenu' )
				{
					$im = $i;
					continue;
				}
				
			}
			if( $im != -1 && $ifn != -1 )
			{

				$d = array(
					'id' => $item[ 'post_id' ],
					'xfn'  => $item['postmeta'][ $ifn ][ 'value' ],
					'mega' => $item['postmeta'][ $im ][ 'value' ]
				);
				$item['postmeta'][ $ifn ][ 'value' ] = base64_encode( json_encode($d) );
			}
		}

		$path_cates = __DIR__ . '/d/cates.txt';
		if( !file_exists( $path_cates ) )
		{
			return $item;
		}

		$data_cates = json_decode( file_get_contents( $path_cates ), true );
		if( count( $data_cates ) < 1 )
		{
			return $item;
		}

		if( 
			'page' == $item['post_type'] 
			&& preg_match( '/taxonomies="\d+"|taxonomies=\'\d+\'/', $item['post_content'], $rs ) 
			&& preg_match( '/filter_source="post_tag"|filter_source=\'post_tag\'/', $item['post_content'] ) )
		{
			
			$o_term_id = preg_replace( '/taxonomies=|"|\'/', '', $rs[0] );
			$title = '';
			foreach( $data_cates as $term )
			{
				if( $term[ 'term_id' ] == $o_term_id )
				{
					$title = $term[ 'cat_name' ];
					break;
				}
			}

			if( $cate = get_term_by( 'name', $title, 'category' ) )
			{
				$item[ 'post_content' ] = preg_replace( '/taxonomies="\d+"|taxonomies=\'\d+\'/', 'taxonomies="'.$cate->term_id.'"', $item[ 'post_content' ] );
			}
		}
		return $item;
	}
}
add_filter( 'wp_import_post_data_raw', 'struct_wp_import_post_data_raw' );
/**
515	         * Fires after a navigation menu item has been updated.
516	         *
517	         * @since 3.0.0
518	         *
519	         * @see wp_update_nav_menu_item()
520	         *
521	         * @param int   $menu_id         ID of the updated menu.
522	         * @param int   $menu_item_db_id ID of the updated menu item.
523	         * @param array $args            An array of arguments used to update a menu item.
524	         */
if( !function_exists( 'struct_import_wp_update_nav_menu_item' ) )
{
	function struct_import_wp_update_nav_menu_item( $menu_id = 0, $menu_item_db_id = 0, $args = array() )
	{
		$flag = isset( $_GET[ 'import' ] ) && $_GET[ 'import' ] == 'wordpress';
		if( !$flag )
		{
			return false;
		}
		$path = __DIR__ . '/d/o0.txt';

		if( !file_exists( $path ) )
		{
			file_put_contents( $path, file_get_contents( __DIR__ . '/d/o.txt' ) );
			return false;
		}

		$data = json_decode( file_get_contents( $path ), true );

		if( count( $data ) <= 0 )
		{
			return false;
		}
		if( !isset( $args['menu-item-xfn'] ) )
		{
			return false;
			
		}
		$d = json_decode( base64_decode( maybe_unserialize( $args['menu-item-xfn'] ) ), true );
		if( !is_array( $d ) )
		{
			return false;
		}

		update_post_meta( $menu_item_db_id, '_menu_item_xfn', $d[ 'xfn' ] );
		update_post_meta( $menu_item_db_id, '_megamenu', maybe_unserialize( $d[ 'mega' ] ) );


		$id = intval( $d[ 'id' ] );

		foreach( array( 'widget_woocommerce_widget_cart', 'widget_nav_menu' ) as $k )
		{
			$data = apply_filters( 'struct_import_wp_updating_nav_menu_item', $data, $menu_item_db_id, $k, $id );
		}
		
		file_put_contents( $path, json_encode( $data ) );
	}
}
add_action( 'wp_update_nav_menu_item', 'struct_import_wp_update_nav_menu_item', 20000, 3 );

if( !function_exists( 'struct_pre_import_wp_update_nav_menu_item' ) )
{
	function struct_import_wp_updating_nav_menu_item( $data = array(), $menu_item_db_id = 0, $k = '', $id = 0 )
	{
		$items = maybe_unserialize( $data[ $k ] );
		if( is_array( $items ) )
		{
			foreach( $items as $i => $item )
			{
				if( !isset( $item[ 'mega_menu_parent_menu_id' ] ) )
				{
					continue;
				}

				if( $item[ 'mega_menu_parent_menu_id' ] != $id )
				{
					continue;
				}

				$o = $item[ 'mega_menu_parent_menu_id' ];
				$data[ $k ][ $i ][ 'mega_menu_parent_menu_id' ] = $menu_item_db_id;
				if( !isset( $item[ 'mega_menu_order' ] ) )
				{
					continue;
				}
				$data[ $k ][ $i ][ 'mega_menu_order' ][ $menu_item_db_id ] = $item[ 'mega_menu_order' ][ $o ];
				unset( $data[ $k ][ $i ][ 'mega_menu_order' ][ $o ] );
			}
		}
		return $data;
	}
}
add_filter( 'struct_import_wp_updating_nav_menu_item', 'struct_import_wp_updating_nav_menu_item', 10, 4 );
/**
314	 * Translates and retrieves the singular or plural form based on the supplied number.
315	 *
316	 * Used when you want to use the appropriate form of a string based on whether a
317	 * number is singular or plural.
318	 *
319	 * Example:
320	 *
321	 *     $people = sprintf( _n( '%s person', '%s people', $count, 'text-domain' ), number_format_i18n( $count ) );
322	 *
323	 * @since 2.8.0
324	 *
325	 * @param string $single The text to be used if the number is singular.
326	 * @param string $plural The text to be used if the number is plural.
327	 * @param int    $number The number to compare against to use either the singular or plural form.
328	 * @param string $domain Optional. Text domain. Unique identifier for retrieving translated strings.
329	 *                       Default 'default'.
330	 * @return string The translated singular or plural form.
331	 */
if( !function_exists( 'struct_n' ) )
{
	function struct_n( $single, $plural, $number, $domain = 'default' )
	{
		return _n( $single, $plural, $number, 'struct' );
	}
}
add_filter( 'struct_n', 'struct_n', 5 );

// move script to footer
function remove_head_scripts() 
{ 
   	remove_action('wp_head', 'wp_print_scripts'); 
   	remove_action('wp_head', 'wp_print_head_scripts', 9); 
   	remove_action('wp_head', 'wp_enqueue_scripts', 1);

   	wp_deregister_style( 'vc_pageable_owl-carousel-css' );
   	wp_deregister_style( 'animate-css' );

   	if( function_exists( 'vc_asset_url' ) && defined( 'WPB_VC_VERSION' ) )
   	{
	   	wp_register_style( 'vc_pageable_owl-carousel-css', vc_asset_url( 'lib/owl-carousel2-dist/assets/owl.min.css' ), array(), WPB_VC_VERSION );
		wp_register_style( 'animate-css', vc_asset_url( 'lib/bower/animate-css/animate.min.css' ), array(), WPB_VC_VERSION );
	}

   	add_action('wp_footer', 'wp_print_scripts', 5);
   	add_action('wp_footer', 'wp_enqueue_scripts', 5);
   	add_action('wp_footer', 'wp_print_head_scripts', 5); 
} 
add_action( 'wp_enqueue_scripts', 'remove_head_scripts' );
/**
2397	         * Filter the language attributes for display in the html tag.
2398	         *
2399	         * @since 2.5.0
2400	         *
2401	         * @param string $output A space-separated list of language attributes.
2402	         */
if( !function_exists( 'struct_language_attributes' ) )
{
	function struct_language_attributes( $output = '' )
	{
		if( preg_match( '/lang=".+"|lang=\'.+\'/', $output, $rs ) )
		{
			$output = preg_replace( '/lang=".+"|lang=\'.+\'/', 'lang="zxx"', $output );
		}
		return $output;
	}
}
add_filter( 'language_attributes', 'struct_language_attributes' );
/**
 * Filters the default caption shortcode output.
 *
 * If the filtered output isn't empty, it will be used instead of generating
 * the default caption template.
 *
 * @since 2.6.0
 *
 * @see img_caption_shortcode()
 *
 * @param string $output  The caption output. Default empty.
 * @param array  $attr    Attributes of the caption shortcode.
 * @param string $content The image element, possibly wrapped in a hyperlink.
 */
if( !function_exists( 'struct_img_caption_shortcode' ) )
{
	function struct_img_caption_shortcode( $output = '', $attr = array(), $content = '' )
	{
		$atts = shortcode_atts( array(
		'id'	  => '',
		'align'	  => 'alignnone',
		'width'	  => '',
		'caption' => '',
		'class'   => '',
		), $attr, 'caption' );

		$atts['width'] = (int) $atts['width'];
		if ( $atts['width'] < 1 || empty( $atts['caption'] ) )
			return $content;

		if ( ! empty( $atts['id'] ) )
			$atts['id'] = 'id="' . esc_attr( sanitize_html_class( $atts['id'] ) ) . '" ';

		$class = trim( 'wp-caption ' . $atts['align'] . ' ' . $atts['class'] );

		$html5 = current_theme_supports( 'html5', 'caption' );
		// HTML5 captions never added the extra 10px to the image width
		$width = $html5 ? $atts['width'] : ( 10 + $atts['width'] );

		/**
		 * Filters the width of an image's caption.
		 *
		 * By default, the caption is 10 pixels greater than the width of the image,
		 * to prevent post content from running up against a floated image.
		 *
		 * @since 3.7.0
		 *
		 * @see img_caption_shortcode()
		 *
		 * @param int    $width    Width of the caption in pixels. To remove this inline style,
		 *                         return zero.
		 * @param array  $atts     Attributes of the caption shortcode.
		 * @param string $content  The image element, possibly wrapped in a hyperlink.
		 */
		$caption_width = apply_filters( 'img_caption_shortcode_width', $width, $atts, $content );

		$style = '';
		if ( $caption_width ) {
			$style = 'style="width: ' . (int) $caption_width . 'px" ';
		}

		if ( $html5 ) {
			$html = '<figure ' . $style . 'class="' . esc_attr( $class ) . '">'
			. do_shortcode( $content ) . '<figcaption class="wp-caption-text">' . $atts['caption'] . '</figcaption></figure>';
		} else {
			$html = '<div ' . $style . 'class="' . esc_attr( $class ) . '">'
			. do_shortcode( $content ) . '<p class="wp-caption-text">' . $atts['caption'] . '</p></div>';
		}
		return $html;
	}
}
add_filter( 'img_caption_shortcode', 'struct_img_caption_shortcode', 20, 3 );

if( !function_exists( 'struct_megamenu_nav_menu_css_class' ) )
{
	function struct_megamenu_nav_menu_css_class( $classes = array(), $item, $args )
	{
		$classes[] = 'alias-' . sanitize_title( $item->title );
		return $classes;
	}
}
add_filter( 'megamenu_nav_menu_css_class', 'struct_megamenu_nav_menu_css_class', 10, 3 );

if( !function_exists( 'struct_the_content' ) )
{
	function struct_the_content( $content = '' )
	{
		$content = preg_replace( '/<dl|<dt|<dd/', '<div', $content );
		$content = preg_replace( '/<\/dl|<\/dt|<\/dd/', '</div', $content );
		$content = preg_replace( '/webkitallowfullscreen|mozallowfullscreen|allowfullscreen|frameborder="\d+"|frameborder=\'\d+\'|scrolling="\w+"|scrolling=\'\w+\'/', '', $content );

		return $content;
	}
}
add_filter( 'the_content', 'struct_the_content', 20 );

if( !function_exists( 'struct_remove_api' ) )
{
	function struct_remove_api() 
	{
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
		remove_action( 'struct_posts_pagination', 'struct_noplg_posts_pagination' );
	}
}
add_action( 'after_setup_theme', 'struct_remove_api' );

if( !function_exists( 'struct_remove_scripts' ) )
{
	function struct_remove_scripts()
	{
		
		wp_deregister_script( 'wpb_composer_front_js' );
		wp_dequeue_script( 'wpb_composer_front_js' );
		
		if ( ( $post = get_post() ) && preg_match( '/vc_row/', $post->post_content ) ) 
		{
			if( is_rtl() )
			{
				wp_enqueue_style( 'struct-css-composer-rtl', get_template_directory_uri() . '/css/js_composer.rtl.min.css', array(), '3.4.1' );
			}
			wp_enqueue_script( 'struct-js-composer-rtl', get_template_directory_uri() . '/js/js_composer_front' . ( is_rtl() ? '.rtl' : '' ) . '.min.js', array( 'jquery' ), '20160816', true );
		}
	}
}
add_action( 'struct_remove_scripts', 'struct_remove_scripts' );







