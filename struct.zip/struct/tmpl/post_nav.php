<hr>
<div class="mb-20"></div>
<nav>
	<ul class="pager">
		<?php if( $previous ) : ?>
		<li class="previous"><?php echo $previous; ?></li>
		<?php endif ?>
		<?php if( $next ) : ?>
		<li class="next"><?php echo $next; ?></li>
		<?php endif ?>
	</ul>
</nav>