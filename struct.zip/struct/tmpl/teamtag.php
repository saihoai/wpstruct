<div class="team">
  <figure class="effect-phoebe"> 
    <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'large' ); ?>
    <?php if( !empty( $src ) ) :  ?>
    <img src="<?php echo $src; ?>" alt=""/>
    <?php endif ?>
    <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'full' ); ?>
    <figcaption>
      <p> <a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo $title; ?>"><i class="fa fa-search effect-8"></i></a> </p>
    </figcaption>
  </figure>
  <div class="clearfix"></div>
  <div class="team-content">
    <h4 data-toggle="tooltip" data-placement="top" title="<?php echo $title; ?>"><?php echo $title; ?><br>
      <small><?php echo $subtitle; ?></small></h4>
    <p><?php echo $text; ?></p>
    <ul class="social-icons social-color">
      <?php for( $i = 1; $i < 6; $i++ ) : ?>
        <?php $url = ${'link'.$i.'_url'}; ?>
        <?php $icon = ${'link'.$i.'_icon'}; ?>
        <?php $title = ${'link'.$i.'_title'}; ?>
        <?php if( !empty( $url ) && !empty( $icon ) ) : ?>
      <li><a href="<?php echo $url; ?>" title="<?php echo $title; ?>"><i class="<?php echo $icon; ?>"></i></a></li>
    <?php endif ?>
      <?php endfor ?>
    </ul>
    <div class="clearfix"></div>
  </div>
  <!-- end .team-content --> 
</div>
<!-- end .team --> 