<?php 
$has_post_thumbnail = apply_filters( 'struct_embed_get_html', false );

if( has_post_thumbnail() )
{
	$has_post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'post-thumbnail', array( 'alt' => the_title_attribute( 'echo=0' ) ) );
}
?>
<?php if( $has_post_thumbnail ) : ?>
	<div class="row">
		<div class="col-md-6">
			<?php echo $has_post_thumbnail; ?>
		</div>
		<div class="col-md-6">
			<h3><?php the_title(); ?></h3>
			<div class="titleline"></div>
			<?php the_content(); ?>
		</div>
	</div>
<?php else : ?>
	<?php the_content(); ?>
<?php endif ?>