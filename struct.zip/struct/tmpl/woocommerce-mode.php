<div class="btn-group btn-mode pull-right">
	<a href="#list" class="btn btn-theme<?php if( $mode == 'list' ) : ?> active<?php endif ?>"><i class="fa fa-th-list"></i></a>
	<a href="#" class="btn btn-theme<?php if( $mode == '' ) : ?> active<?php endif ?>"><i class="fa fa-th"></i></a>
</div>