<!-- Page Title
================================================== -->
  <div class="pagetitle">
    <div class="pagetitle-overlay">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

          	<?php the_title('<h1>','</h1>'); ?>
          	<?php echo $breadcrumb_html;?>
        </div>
        <!-- end .col-md-12 --> 
      </div>
      <!-- end .row --> 
    </div>
    <!-- end .container --> 
    </div>
    <!-- end .pagetitle-overlay --> 
  </div>
  <!-- end .pagetitle -->
<?php do_action( 'page_title_end' ); ?>