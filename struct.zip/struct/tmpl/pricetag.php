<div <?php if( !empty( $delay ) && !empty( $effect ) ) : ?>class="animated <?php echo esc_attr( $delay ); ?>" data-animation="<?php echo esc_attr( $effect ); ?>"<?php endif ?>>
  <div class="pricing-table <?php echo esc_attr( $class ); ?>">
    <div class="plan"><span><?php echo esc_html( $title ); ?></span></div>
    <!-- end .plan -->
    <div class="price price-<?php echo esc_attr( $price_bg ); ?>"> <span><?php echo esc_html( $unit ); ?></span><strong><?php echo esc_html( $price ); ?><span><?php echo esc_html( $amount ); ?></span></strong> </div>
    <!-- end .price -->
    <?php $text = explode(",", $text); ?>
    <?php if( count( $text ) ) : ?>
    <ul>
      	<?php foreach ($text as $item) : ?>
      	<li><?php echo esc_html( $item ); ?></li>
  		<?php endforeach; ?>
    </ul>
	<?php endif ?>
    <div class="sign-up"> <a href="<?php echo esc_url( $link_url ); ?>" class="btn btn-<?php echo esc_attr( $link_bg ); ?>"><span><i class="<?php echo esc_attr( $link_icon ); ?>"></i></span><?php echo esc_html( $link_title ); ?></a> </div>
    <!-- end .sign-up --> 
  </div>
  <!-- end .pricing-table --> 
</div>
<!-- end .animated -->