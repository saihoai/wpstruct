<ul class="sidebar-info">
	<?php if( !empty( $address ) ) : ?>
	<li><i class="fa fa-map-marker"></i><span><?php _e( 'Address', 'struct' ) ?>:</span><br>
	  <?php echo $address; ?></li>
	<?php endif ?>
	<?php if( !empty( $phone ) ) : ?>
	<li><i class="fa fa-phone"></i><span><?php _e( 'Phone number', 'struct' ) ?>:</span><br>
	  <?php echo $phone; ?></li>
	<?php endif ?>
	<?php if( !empty( $email ) ) : ?>
	<li><i class="fa fa-envelope"></i><span><?php _e( 'E-mail', 'struct' ) ?>:</span><br>
	  <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></li>
	<?php endif ?>
</ul>
<div class="clearfix"></div>
<?php if( !empty( $menu_id ) ) : ?>
	<?php 
	$nav_menu_args = array(
		'fallback_cb' 	=> '',
		'menu'        	=> $menu_id,
		'items_wrap'	=> '<ul id="%1$s" class="social-icons social-color %2$s">%3$s</ul>',
	);
	wp_nav_menu( apply_filters( 'widget_nav_menu_args', $nav_menu_args, $menu_id, array(), array() ) );
	?>
<?php endif ?>
<div class="clearfix"></div>