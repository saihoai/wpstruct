<?php if( $tmpl == 'style1' ) : ?>
    <div class="photo2 mt-120">
    <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'full' ); ?>
  <?php if( !empty( $src ) ) :  ?>
    <figure class="effect-phoebe"> <img src="<?php echo $src; ?>" alt=""/>
        <figcaption>
          <p> <a href="#"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo $link_title; ?>"><i class="fa fa-search effect-8"></i></a> </p>
        </figcaption>
      </figure>
      <div class="clearfix"></div>
  <?php endif ?>
      <div class="photo-title2 text-left2">
        <h5><?php echo $title; ?> <span class="text-theme"><?php echo $subtitle; ?></span></h5>
        <p><?php echo $text; ?></p>
        <p><a href="<?php echo $link_url; ?>" class="btn btn-theme"><span><i class="<?php echo $link_icon; ?>"></i></span><?php echo $link_title; ?></a></p>
      </div>
      <!-- end .photo-title --> 
      </div>
<?php elseif( $tmpl == 'style2' ) : ?>
<div class="photobox1">
  <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'full' ); ?>
  <?php if( !empty( $src ) ) :  ?>
    <?php list( $src_thumb, $w, $h ) = wp_get_attachment_image_src( $image, 'thumbnail' ); ?>
  <figure class="effect-phoebe"> <img src="<?php echo $src_thumb; ?>" alt=""/>
    <figcaption>
      <p> <a href="#"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo $title; ?>"><i class="fa fa-search effect-8"></i></a> </p>
    </figcaption>
  </figure>
  <?php endif ?>
  <div class="photobox1-content">
    <h4><?php echo $title; ?></h4>
    <p><?php echo $text; ?></p>
    <p><a href="<?php echo $link_url; ?>" class="btn btn-theme"><span><i class="<?php echo $link_icon; ?>"></i></span><?php echo $link_title; ?></a></p>
  </div>
  <!-- end .photobox1-content --> 
</div>
<!-- end .photobox1 --> 
<?php elseif( $tmpl == 'style3' ) : ?>
  <div class="iconbox1">
    <div class="iconbox1-icon animated <?php echo $class ?>" data-animation="bounceIn"><a href="<?php echo $link_url ?>"><i class="<?php echo $link_icon ?> effect-8"></i></a></div>
    <h4><?php echo $title ?></h4>
    <p><?php echo $text ?></p>
  </div>
<?php elseif( $tmpl == 'iconbox2' ) : ?>
  <div class="iconbox2">
    <div class="iconbox2-bg"><i class="<?php echo $link_icon; ?>"></i></div>
    <div class="iconbox2-icon animated <?php echo $class; ?>" data-animation="bounceIn"><i class="<?php echo $link_icon; ?> effect-8"></i></div>
    <div class="iconbox2-content">
      <h5><?php echo $title; ?></h5>
          <p><?php echo $text; ?></p>
      <p><a href="<?php echo $link_url; ?>"><?php echo $link_title; ?></a></p>
    </div>
  </div>
  <!-- end .iconbox2 --> 
<?php elseif( $tmpl == 'iconbox3' ) : ?>
  <div class="iconbox1 animated" data-animation="<?php echo esc_attr( $class ) ?>">
    <h4><?php echo esc_html( $title ) ?></h4>
    <div class="iconbox1-icon"><i class="<?php echo esc_attr( $link_icon ) ?> effect-8"></i></div>
    <p><?php echo esc_html( $text ); ?></p>
  </div>
<?php elseif( $tmpl == 'tooltip' ) : ?>
  <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'medium' ); ?>
  <div class="tooltip-course tooltip-effect-4" style="<?php echo $style; ?>">
      <div class="tooltip-point"><i class="fa fa-map-marker"></i></div>
      <div class="tooltip-content clearfix"> <img src="<?php echo $src; ?>" alt="" />
        <div class="tooltip-text">
          <h5><?php echo $title; ?></h5>
          <p><?php echo $text; ?></p>
          <p><a href="<?php echo $link_url; ?>"><?php echo $link_title; ?></a></p>
        </div>
        <!-- end .tooltip-text --> 
      </div>
      <!-- end .tooltip-content --> 
    </div>
    <!-- end .tooltip-course -->
<?php elseif( $tmpl == 'contentbox' ) : ?>
  <?php if( !empty( $class ) ) : ?>
  <div class="<?php echo $class; ?>"></div>
  <!-- end .triangle-right -->
  <?php endif ?>
  <h4><?php echo $title; ?></h4>
  <p><?php echo $text; ?></p>
  <p><a href="<?php echo $link_url; ?>" class="btn btn-black"><span><i class="<?php echo $link_icon; ?>"></i></span><?php echo $link_title; ?></a></p>
<?php elseif( $tmpl == 'contentbox2' ) : ?>
  <?php if( !empty( $class ) ) : ?>
  <div class="<?php echo $class; ?>"></div>
  <!-- end .triangle-right -->
  <?php endif ?>
  <h4><?php echo $title; ?></h4>
  <p><?php echo $text; ?></p>
  <p><a href="<?php echo $link_url; ?>" class="btn btn-theme"><span><i class="<?php echo $link_icon; ?>"></i></span><?php echo $link_title; ?></a></p>
<?php elseif( $tmpl == 'progress1' ) : ?>
  <div class="process animated <?php echo $class; ?>" data-animation="fadeInUp">
    <div class="process-1">
      <div class="step"><span class="effect-8"><i class="<?php echo $link_icon; ?>"></i></span></div>
      <!-- end .step -->
      <h3><?php echo $subtitle; ?></h3>
      <div class="triangle-right"></div>
    </div>
    <!-- end .process-1 -->
    <div class="clearfix"></div>
    <div class="process-content">
      <h4><?php echo $title; ?></h4>
      <p><?php echo $text; ?></p>
      <p><a href="<?php echo $link_url; ?>"><?php echo $link_title; ?></a></p>
    </div>
  </div>
  <!-- end .process --> 
  <?php elseif( $tmpl == 'progress2' ) : ?>
  <div class="process animated <?php echo $class; ?>" data-animation="fadeInUp">
    <div class="process-2">
      <div class="step"><span class="effect-8"><i class="<?php echo $link_icon; ?>"></i></span></div>
      <!-- end .step -->
      <h3><?php echo $subtitle; ?></h3>
      <div class="triangle-right"></div>
      <div class="triangle-left"></div>
    </div>
    <!-- end .process-2 -->
    <div class="clearfix"></div>
    <div class="process-content">
      <h4><?php echo $title; ?></h4>
      <p><?php echo $text; ?></p>
      <p><a href="<?php echo $link_url; ?>"><?php echo $link_title; ?></a></p>
    </div>
  </div>
  <!-- end .process --> 
<?php elseif( $tmpl == 'progress3' ) : ?>
  <div class="process animated <?php echo $class; ?>" data-animation="fadeInUp">
    <div class="process-3">
      <div class="step"><span class="effect-8"><i class="<?php echo $link_icon; ?>"></i></span></div>
      <!-- end .step -->
      <h3><?php echo $subtitle; ?></h3>
      <div class="triangle-left"></div>
    </div>
    <!-- end .process-3 -->
    <div class="clearfix"></div>
    <div class="process-content">
      <h4><?php echo $title; ?></h4>
      <p><?php echo $text; ?></p>
      <p><a href="<?php echo $link_url; ?>"><?php echo $link_title; ?></a></p>
    </div>
  </div>
  <!-- end .process --> 
  <?php elseif( $tmpl == 'photobox2' ) : ?>
    <div class="photobox2"> 
    <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'medium' ); ?>
    <img class="frame" src="<?php echo $src; ?>" alt="" />
      <div class="photobox2-content">
        <h4><?php echo $title; ?></h4>
        <p><?php echo $text; ?></p>
      </div>
      <!-- end .photobox2-content --> 
    </div>
    <!-- end .photobox2 --> 
    <?php elseif( $tmpl == 'photobox3' ) : ?>
      <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'full' ); ?>
      <figure class="effect-phoebe"> <img src="<?php echo $src; ?>" alt=""/>
        <figcaption>
          <p> <a href="#"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo $title; ?>"><i class="fa fa-search effect-8"></i></a> </p>
        </figcaption>
      </figure>
      <div class="clearfix"></div>
      <div class="photo-title">
        <h5><?php echo $title; ?></h5>
        <p><?php echo $text; ?></p>
      </div>
      <!-- end .photo-title -->
    <?php elseif( $tmpl == 'photobox4' ) : ?>
      <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'full' ); ?>
      <figure class="effect-phoebe frame2"> <img src="<?php echo $src; ?>" alt=""/>
        <figcaption>
          <p> <a href="#"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo $title; ?>"><i class="fa fa-search effect-8"></i></a> </p>
        </figcaption>
      </figure>
      <div class="clearfix"></div>
      <div class="photo-title2">
        <h5><?php echo $title; ?></h5>
        <p><?php echo $text; ?></p>
      </div>
      <!-- end .photo-title -->
    <?php elseif( $tmpl == 'photobox5' ) : ?>
      <?php list( $src, $w, $h ) = wp_get_attachment_image_src( $image, 'full' ); ?>
      <figure class="effect-phoebe"> <img src="<?php echo $src; ?>" alt=""/>
        <figcaption>
          <p> <a href="#"><i class="fa fa-link effect-8"></i></a> <a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo $title; ?>"><i class="fa fa-search effect-8"></i></a> </p>
        </figcaption>
      </figure>
      <div class="clearfix"></div>
      <div class="photo-title3">
        <h5><?php echo $title; ?></h5>
        <p><?php echo $text; ?></p>
      </div>
      <!-- end .photo-title -->
<?php endif; ?>