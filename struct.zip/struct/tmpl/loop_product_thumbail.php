<?php global $product; ?>
<?php if( $mode == 'list' && !is_single() && preg_match_all( '/woocommerce/', implode( ' ', get_body_class() ) ) ) : ?>
<div class="blog-post-middle">
	<div class="row">
		<div class="col-md-4">
			<div class="blog-photo">
				<figure class="effect-phoebe frame2<?php if ( $product->is_on_sale() ) : ?> badge-sale<?php elseif( $product->is_featured() ) : ?> badge-best<?php endif ?>"> 
					<?php echo woocommerce_get_product_thumbnail() ?>
					<figcaption>
						<p>
							<?php list( $src ) = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); ?>
							<a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo get_the_title(); ?>"><i class="fa fa-search effect-8"></i></a> 
						</p>
					</figcaption>
				</figure>
			</div>
		</div>
		<div class="col-md-8">
<?php else : ?>
<figure class="effect-phoebe frame2<?php if ( $product->is_on_sale() ) : ?> badge-sale<?php elseif( $product->is_featured() ) : ?> badge-best<?php endif ?>"> 
	<?php echo woocommerce_get_product_thumbnail() ?>
	<figcaption>
		<p>
			<?php list( $src ) = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); ?>
			<a class="nivo-lightbox" href="<?php echo $src; ?>" title="<?php echo get_the_title(); ?>"><i class="fa fa-search effect-8"></i></a> 
			<?php
			$defaults = array(
				'quantity' => 1,
				'class'    => implode( ' ', array_filter( array(
						'',
						'product_type_' . $product->product_type,
						$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
						$product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : ''
				) ) )
			);
			$args = apply_filters( 'woocommerce_loop_add_to_cart_args', wp_parse_args( array(), $defaults ), $product );
			echo apply_filters( 'woocommerce_loop_add_to_cart_link',
				sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="%s">%s</a>',
					esc_url( $product->add_to_cart_url() ),
					esc_attr( isset( $quantity ) ? $quantity : 1 ),
					esc_attr( $product->id ),
					esc_attr( $product->get_sku() ),
					esc_attr( $args[ 'class' ] ),
					'<i class="fa fa-link effect-8"></i>'
				),
			$product );
			?>
		</p>
	</figcaption>
</figure>
<div class="photo-title2">
<?php endif ?>