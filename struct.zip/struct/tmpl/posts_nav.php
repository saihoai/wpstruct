<ul class="pagination">
<?php foreach( $links as $item ) : ?>
	<?php $citem = $item; ?>
	<?php $citem = preg_replace( '/current|prev|page-numbers|next/', '', $citem ); ?>
	<?php if( preg_match( '/current/', $item ) ) : ?>
		<li class="active"><a href="javascript:void(0)"><?php echo $citem; ?></a></li>
	<?php else : ?>
		<li><?php echo $citem; ?></li>
	<?php endif ?>
<?php endforeach; ?>
</ul>