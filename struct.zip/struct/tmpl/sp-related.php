<?php $post_id = get_the_ID(); ?>
<?php $tags = wp_get_post_tags( $post_id ); ?>
<?php if( $tags ) : ?>
  <?php
    $tag_ids = array();
    foreach($tags as $individual_tag) 
    {
      $tag_ids[] = $individual_tag->term_id;
    }
    $args=array(
      'tag__in' => $tag_ids,
      'post__not_in' => array( $post_id ),
      'posts_per_page'=>10, // Number of related posts to display.
    );
    $my_query = new wp_query( $args );
  ?>

  <?php if( $my_query->have_posts() ) : ?>
    <div class="mb-100"></div>
    <div class="related-posts text-center">
      <h3><?php _e( 'Related Works', 'struct' ); ?></h3>
      <div class="titleline-center"></div>
      <div class="owl-image owl-carousel owl-theme">
        <?php while( $my_query->have_posts() ) : ?>
          <?php $my_query->the_post(); ?>
          <?php if ( has_post_thumbnail() ) : ?>
          <div class="item">
            <figure class="effect-phoebe"> 
              <?php the_post_thumbnail( 'post-thumbnail', array( 'alt' => the_title_attribute( 'echo=0' ) ) ); ?>
              <figcaption>
                <p> 
                  <a href="<?php the_permalink(); ?>"><i class="fa fa-link effect-8"></i></a> 
                  <a  class="nivo-lightbox" href="<?php the_post_thumbnail_url( 'full' ); ?>" title="<?php the_title(); ?>" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-8"></i></a> 
                </p>
              </figcaption>
            </figure>
          </div>
          <!-- end .item -->
          <?php else : ?>
            <div class="item">
              <figure class="effect-phoebe"> 
                <?php echo get_avatar( '', 500 ); ?>
                <figcaption>
                  <p> <a href="<?php the_permalink(); ?>"><i class="fa fa-link effect-8"></i></a></p>
                </figcaption>
              </figure>
            </div>
            <!-- end .item -->
          <?php endif ?>
         
        <?php endwhile ?>
        <?php wp_reset_query(); ?>
      </div>
    </div>
  <?php endif ?>
<?php endif ?>