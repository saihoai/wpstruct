<form action="" method="get" id="search-members-form" class="input-group input-group-lg form-group">
	<input type="text" name="<?php echo esc_attr( $query_arg ); ?>" id="members_search" placeholder="<?php echo esc_attr( $search_value ); ?>" class="form-control" />
	<div class="input-group-btn">
		<button type="submit" id="members_search_submit" class="btn btn-theme" name="members_search_submit">
			<?php echo __( 'Search', 'buddypress' ); ?>
		</button>
	</div>
</form>