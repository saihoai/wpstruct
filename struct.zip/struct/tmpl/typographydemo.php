<div class="row">
  <div class="col-md-12">
    <h3>Grid System</h3>
    <div class="titleline"></div>
    <!-- end .titleline -->
    <h4>col-md-12</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-12 -->
  
  <div class="col-md-6">
    <h4>col-md-6</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-6 -->
  <div class="col-md-6">
    <h4>col-md-6</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-6 -->
  
  <div class="col-md-4">
    <h4>col-md-4</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-4 -->
  <div class="col-md-4">
    <h4>col-md-4</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-4 -->
  <div class="col-md-4">
    <h4>col-md-4</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-4 -->
  
  <div class="col-md-3">
    <h4>col-md-3</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-3 -->
  <div class="col-md-3">
    <h4>col-md-3</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-3 -->
  <div class="col-md-3">
    <h4>col-md-3</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-3 -->
  <div class="col-md-3">
    <h4>col-md-3</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-3 -->
  
  <div class="col-md-8">
    <h4>col-md-8</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-8 -->
  <div class="col-md-4">
    <h4>col-md-4</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-4 -->
  
  <div class="col-md-9">
    <h4>col-md-9</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-9 -->
  <div class="col-md-3">
    <h4>col-md-3</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
  </div>
  <!-- end .col-md-3 --> 
</div>
<div class="mb-100"></div>
<div class="row">
      <div class="col-md-6">
        <h3>Heading</h3>
        <div class="titleline"></div>
        <!-- end .titleline -->
        <div class="h1">h1. Bootstrap heading</div>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <h2>h2. Bootstrap heading</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <h3>h3. Bootstrap heading</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <h4>h4. Bootstrap heading</h4>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <h5>h5. Bootstrap heading</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <h6>h6. Bootstrap heading</h6>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <div class="mb-50"></div>
        <!-- end .mb-50 --> 
        
        <!-- Blockquotes
================================================== -->
        <h3>Blockquotes</h3>
        <div class="titleline"></div>
        <!-- end .titleline -->
        
        <blockquote>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
        </blockquote>
        <blockquote>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
          <small>Someone famous in <cite title="Source Title">Source Title</cite></small> </blockquote>
        <div class="mb-50"></div>
        <!-- end .mb-50 --> 
        
        <!-- Dropcap
================================================== -->
        <h3>Dropcap</h3>
        <div class="titleline"></div>
        <!-- end .titleline -->
        
        <p><span class="dropcap">A</span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit.</p>
        <p><span class="dropcap-theme">A</span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit.</p>
        <div class="mb-50 clearfix"></div>
        <!-- end .mb-50 --> 
        
      </div>
      <!-- end .col-md-6 -->
      <div class="col-md-6"> 
        
        <!-- Highlight
================================================== -->
        <h3>Highlight</h3>
        <div class="titleline"></div>
        <!-- end .titleline --> 
        
        Lorem ipsum <span class="highlight-white">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-gray">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-black">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-rose">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-pink">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-purple">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-indigo">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-blue">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-aqua">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-emerald">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-green">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-olive">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-yellow">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-orange">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-red">dolor sit amet,</span> consectetur adipisicing elit.<br>
        Lorem ipsum <span class="highlight-theme">dolor sit amet,</span> consectetur adipisicing elit (theme).<br>
        <div class="mb-50"></div>
        <!-- end .mb-50 --> 
        
        <!-- Text Color
================================================== -->
        
        <h3>Text Color</h3>
        <div class="titleline"></div>
        <!-- end .titleline --> 
        <span class="text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-gray">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-black">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-rose">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span><br>
        <span class="text-pink">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-purple">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-indigo">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-blue">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-aqua">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-emerald">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-green">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-olive">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-yellow">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-orange">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-red">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</span> <br>
        <span class="text-theme">Lorem ipsum dolor sit amet, consectetur adipisicing elit (theme).</span><br>
        <div class="mb-50"></div>
        <!-- end .mb-50 --> 
        
        <!-- Tooltip and Popover
================================================== -->
        <h3>Tooltip and Popover</h3>
        <div class="titleline"></div>
        <!-- end .titleline -->
        
        <h5>Tooltip</h5>
        <button type="button" class="btn btn-white" data-toggle="tooltip" data-placement="left" title="" data-original-title="Tooltip on left">Tooltip on left</button>
        <button type="button" class="btn btn-white" data-toggle="tooltip" data-placement="top" title="" data-original-title="Tooltip on top">Tooltip on top</button>
        <button type="button" class="btn btn-white" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Tooltip on bottom">Tooltip on bottom</button>
        <button type="button" class="btn btn-white" data-toggle="tooltip" data-placement="right" title="" data-original-title="Tooltip on right">Tooltip on right</button>
        <div class="mb-20"></div>
        <!-- end .mb-20 -->
        
        <h5>Popover</h5>
        <button type="button" class="btn btn-white" data-container="body" data-toggle="popover" data-placement="left" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus." data-original-title="" title=""> Popover on left </button>
        <button type="button" class="btn btn-white" data-container="body" data-toggle="popover" data-placement="top" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus." data-original-title="" title=""> Popover on top </button>
        <button type="button" class="btn btn-white" data-container="body" data-toggle="popover" data-placement="bottom" data-content="Vivamus
sagittis lacus vel augue laoreet rutrum faucibus." data-original-title="" title=""> Popover on bottom </button>
        <button type="button" class="btn btn-white" data-container="body" data-toggle="popover" data-placement="right" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus." data-original-title="" title=""> Popover on right </button>
      </div>
      <!-- end .col-md-6 --> 
    </div>
    <div class="mb-100"></div>
    <div class="row">
      <div class="col-md-12">
        <h3>List Styles</h3>
        <div class="titleline"></div>
        <!-- end .titleline --> 
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <div class="row">
      <div class="col-md-3">
        <h4>Unstyled</h4>
        <ul class="list-unstyled">
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.
            <ul>
              <li>Lorem ipsum dolor sit amet.</li>
              <li>Lorem ipsum dolor sit amet.</li>
              <li>Lorem ipsum dolor sit amet.</li>
            </ul>
          </li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
        </ul>
      </div>
      <!-- end .col-md-3 -->
      
      <div class="col-md-3">
        <h4>Unordered</h4>
        <ul class="list-unordered">
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.
            <ul>
              <li>Lorem ipsum dolor.</li>
              <li>Lorem ipsum dolor.</li>
              <li>Lorem ipsum dolor.</li>
              <li>Lorem ipsum dolor.</li>
            </ul>
          </li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
        </ul>
      </div>
      <!-- end .col-md-3 -->
      
      <div class="col-md-3">
        <h4>Ordered</h4>
        <ol class="list-ordered">
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
          <li>Lorem ipsum dolor sit amet.</li>
        </ol>
      </div>
      <!-- end .col-md-3 -->
      
      <div class="col-md-3">
        <h4>Icon-arrow-list</h4>
        <ul class="icon-arrow-list">
          <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
          <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
          <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.
            <ul>
              <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
              <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
              <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
              <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
            </ul>
          </li>
          <li><i class="fa fa-angle-right"></i>Lorem ipsum dolor sit amet.</li>
        </ul>
      </div>
      <!-- end .col-md-3 --> 
      
    </div>
    <div class="mb-100"></div>
    <div class="row">
      <div class="col-md-12">
        <h3>Table</h3>
        <div class="titleline"></div>
        <!-- end .titleline -->
        <h4>Striped rows</h4>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Username</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
          </tbody>
        </table>
        <h4>Striped rows + Bordered table</h4>
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Username</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <td>3</td>
              <td colspan="2">Larry the Bird</td>
              <td>@twitter</td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <div class="mb-100"></div>
    <div class="row">
      <div class="col-md-12">
        <h3>Testimonial</h3>
        <div class="titleline"></div>
        <!-- end .titleline --> 
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="owl-testimonial owl-carousel owl-theme">
          <div>
            <div class="testimonial">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author"> <img class="frame" src="https://placeholdit.imgix.net/~text?txtsize=33&txt=350%C3%97150&w=150&h=150" alt="" />
              <p>John Doe</p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
          <div>
            <div class="testimonial">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author"> <img class="frame" src="https://placeholdit.imgix.net/~text?txtsize=33&txt=350%C3%97150&w=150&h=150" alt="" />
              <p>John Doe</p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
          <div>
            <div class="testimonial">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author"> <img class="frame" src="https://placeholdit.imgix.net/~text?txtsize=33&txt=350%C3%97150&w=150&h=150" alt="" />
              <p>John Doe</p>
            </div>
            <!-- end .testimonial-author --> 
        <!-- end #owl-testimonial --> 
        </div>
        </div>
        
      </div>
      <!-- end .col-md-6 -->
      
      <div class="col-md-6">
        <div class="owl-testimonial owl-carousel owl-theme">
          <div>
            <div class="testimonial">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author">
              <p>John Doe</p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
          <div>
            <div class="testimonial">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author">
              <p>John Doe</p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
          <div>
            <div class="testimonial">
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- end .testimonial -->
            <div class="testimonial-author">
              <p>John Doe</p>
            </div>
            <!-- end .testimonial-author --> 
          </div>
        </div>
        <!-- end #owl-testimonial -->  
        
      </div>
      <!-- end .col-md-6 --> 
      
    </div>
    <div class="mb-100"></div>
    <div class="row">
      <div class="col-md-12">
        <h3>Divider</h3>
        <div class="titleline"></div>
        <!-- end .titleline --> 
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <div class="row">
      <div class="col-md-12">
        <h5>hr</h5>
        <hr>
        <h5>divider-singleline</h5>
        <div class="divider-singleline"></div>
        <h5>divider-doubleline</h5>
        <div class="divider-doubleline"></div>
        <h5>divider-singledotted</h5>
        <div class="divider-singledotted"></div>
        <h5>divider-doubledotted</h5>
        <div class="divider-doubledotted"></div>
        <h5>divider-icon</h5>
        <div class="divider-icon"><i class="fa fa-leaf"></i></div>
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <div class="mb-100"></div>