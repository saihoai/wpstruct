<?php $text = ''; ?>
<?php global $product; ?>
<?php $url = $product->get_permalink(); ?>
<?php $title = $product->get_title(); ?>
<?php $excerpt = $product->post->post_excerpt; ?>
<?php $media = wc_placeholder_img_src(); ?>
<?php if ( has_post_thumbnail() ) : ?>
	<?php $media = get_the_post_thumbnail_url( $product->ID ); ?>
<?php endif ?>
<?php $socials = array( 
	'fb' => array(
		'icon' => 'fa fa-facebook',
		'link' => esc_url( "https://www.facebook.com/sharer/sharer.php?u={$url}" )
	), 
	'twitter' => array(
		'icon' => 'fa fa-twitter',
		'link' => esc_url( "https://twitter.com/home?status={$url}" )
	), 
	'google' => array(
		'icon' => 'fa fa-google-plus',
		'link' => esc_url( "https://plus.google.com/share?url={$url}" )
	), 
	'linkedin' => array(
		'icon' => 'fa fa-linkedin',
		'link' => esc_url( "https://www.linkedin.com/shareArticle?mini=true&url={$url}&title={$title}&summary={$excerpt}&source=" )
	), 
	'pinterest'  => array(
		'icon' => 'fa fa-pinterest',
		'link' => esc_url( "https://pinterest.com/pin/create/button/?url={$url}&media={$media}&description={$excerpt}" )
	)
); 
?>
<?php foreach( $socials as $k => $item ) : ?>
	<?php $k = get_theme_mod( $k, false ); ?>
	<?php if( boolval( $k ) ) : ?>
		<?php $text .= sprintf( "<li><a href='%1\$s' target='_blank'><i class='%2\$s'></i></a></li>\n", $item[ 'link' ], $item[ 'icon' ] ); ?>
	<?php endif ?>
<?php endforeach; ?>
<?php if( !empty(  $text ) ) : ?>
<div class="mb-10"></div>
<ul class="social-icons social-color">
	<?php echo trim( $text, "\n" ); ?>
</ul>
<?php endif ?>
<div class="mb-10 clearfix"></div>