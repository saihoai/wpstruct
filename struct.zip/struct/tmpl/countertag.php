<div class="chartbox">
  <div class="chartbox-icon"><a href="<?php echo $link; ?>"><i class="<?php echo $icon; ?>"></i></a></div>
  <p><span class="chart" data-percent="<?php echo $num; ?>"><span class="percent"></span></span></p>
  <p><?php echo $text; ?></p>
</div>
<!-- end .chartbox --> 