<?php if( $tmpl == 'style1' ) : ?>
	<?php if( !empty( $images ) ): ?>
		<?php $images = explode( ",", $images ); ?>
		<?php if( count( $images ) ) : ?>
			<div class="owl-single owl-carousel owl-theme">
			<?php foreach( $images as $item ) : ?>
				<?php list( $src, $w, $h ) = wp_get_attachment_image_src( $item, 'full' ); ?>
				<?php if( !empty( $src ) ) :  ?>
					<div class="item"><img src="<?php echo $src; ?>" alt="" /></div>
				<?php endif ?>
			<?php endforeach ?>
			</div>
		<?php endif ?>
	<?php endif ?>
<?php elseif( $tmpl == 'style2' ) : ?>
	<?php if( !empty( $images ) ): ?>
		<?php $images = explode( ",", $images ); ?>
		<?php if( count( $images ) ) : ?>
			<div class="owl-client owl-carousel owl-theme">
			<?php foreach( $images as $item ) : ?>
				<?php list( $src, $w, $h ) = wp_get_attachment_image_src( $item, 'full' ); ?>
				<?php if( !empty( $src ) ) :  ?>
					<div class="item"><img src="<?php echo $src; ?>" alt="" /></div>
				<?php endif ?>
			<?php endforeach ?>
			</div>
		<?php endif ?>
	<?php endif ?>
<?php endif ?>