<form action="" method="get" id="search-groups-form" class="input-group input-group-lg form-group">
	<input type="text" class="form-control" name="<?php echo esc_attr( $query_arg ); ?>" id="groups_search" placeholder="<?php echo esc_attr( $search_value ); ?>" />
	<div class="input-group-btn">
		<button type="submit" id="groups_search_submit" class="btn btn-theme" name="groups_search_submit"><?php echo __( 'Search', 'buddypress' ); ?></button>
	</div>
</form>