<h3>
	<?php if( !empty( $text ) ) : ?>
	<span class="text-theme"><?php echo $text; ?></span>
	<?php endif ?>
	<?php echo $subtext; ?>
	<?php $extext = explode( ",", $extext ); ?>
	<?php if( count( $extext ) > 0 ) : ?>
	<span class="rw-words rw-words-1"><?php foreach( $extext as $item ) : ?><span><?php echo $item; ?></span><?php endforeach ?></span> 
    <!-- end .rw-words --> 
	<?php endif ?>
  </h3>