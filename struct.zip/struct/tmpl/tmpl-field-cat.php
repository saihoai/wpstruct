<p>
	<label for="cat_tmpl"><?php _e( 'In post', 'struct' ); ?></label>
	<?php 
	$data = array( '' => __( 'Large', 'struct' ), '0mid' => __( 'Middle', 'struct' ) );
	?>
	<select name="cat_tmpl" id="cat_tmpl" value="<?php echo $cat_tmpl ?>">
	<?php foreach( $data as $k => $v ) : ?>
		<option value="<?php echo $k; ?>" <?php selected( $k, $cat_tmpl ); ?>><?php echo $v; ?></option>
	<?php endforeach ?>
	</select>
</p>

<p>
	<label for="in_post"><?php _e( 'In single', 'struct' ); ?></label>
	<?php 
	$data = array( 'single' => __( 'Default', 'struct' ), 'sp' => __( 'Portfolio', 'struct' ) );
	?>
	<select name="in_post" id="in_post" value="<?php echo $in_post ?>">
	<?php foreach( $data as $k => $v ) : ?>
		<option value="<?php echo $k; ?>" <?php selected( $k, $in_post ); ?>><?php echo $v; ?></option>
	<?php endforeach ?>
	</select>
</p>