<?php if( $tmpl == 'style1' ) : ?>
<div class="lead">
  <h3><?php echo $title; ?></h3>
  <p><?php echo $text; ?></p>
  <?php if( !empty( $link1_title ) || !empty( $link2_title ) ) : ?>
  <div class="mb-20"></div>
  <p>
  	<a href="<?php echo $link1_url; ?>" class="btn btn-<?php echo $link1_color; ?>"><span><i class="<?php echo $link1_icon; ?>"></i></span><?php echo $link1_title; ?></a> 
  	<a href="<?php echo $link2_url; ?>" class="btn btn-<?php echo $link2_color; ?>"><span><i class="<?php echo $link2_icon; ?>"></i></span><?php echo $link2_title; ?></a>
  	</p>
  <?php endif ?>
</div>
<!-- end .lead --> 
<?php elseif( $tmpl == 'style2' ) : ?>
	<div class="<?php echo $class; ?>">
		<div class="subtitle"><?php echo $title; ?></div>
	    <!-- end .subtitle -->
	    <h3><?php echo $subtitle; ?></h3>
	    <div class="titleline-icon"></div>
	    <!-- end .titleline-icon -->
	    
	    <p class="lead"><?php echo $text; ?></p>
	</div>
<?php elseif( $tmpl == 'style3' ) : ?>
	<h3><?php echo $title; ?></h3>
  	<div class="titleline"></div>
  	<!-- end .titleline -->
    <?php if( !empty( $text ) ) : ?>
  	<p><?php echo $text; ?></p>
  <?php endif ?>
<?php elseif( $tmpl == 'style4' ) : ?>
  <div class="<?php echo $class; ?>">
    <div class="subtitle"><?php echo $title; ?></div>
      <!-- end .subtitle -->
      <h3><?php echo $subtitle; ?></h3>
      <div class="titleline-center"></div>
      <!-- end .titleline-icon -->
      
      <p class="lead"><?php echo $text; ?></p>
  </div>
<?php endif ?>