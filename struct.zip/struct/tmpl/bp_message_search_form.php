<form action="" method="get" id="search-message-form" class="input-group input-group-lg">
	<input type="text" name="s" class="form-control" id="messages_search"<?php echo $search_placeholder . $search_value; ?> />
	<div class="input-group-btn">
		<button class="btn btn-theme" id="messages_search_submit" name="messages_search_submit"><?php esc_html_e( 'Search', 'buddypress' ); ?></button>
	</div>
</form>