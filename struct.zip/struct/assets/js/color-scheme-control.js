/* global colorScheme, Color */
/**
 * Add a listener to the Color Scheme control to update other color controls to new values/defaults.
 * Also trigger an update of the Color Scheme CSS when a color is changed.
 */

( function( api, $ ) {
	"use strict";

	var 
		cssColorTemplate = wp.template( 'struct-color-scheme' )
		,cssBoxedLayoutsTemplate = wp.template( 'struct-boxed-layouts' )
		,cssTopbarTemplate = wp.template( 'struct-topbar' )
		,cssHeaderBgTemplate = wp.template( 'struct-header-bg' )
		,cssFooterColorTemplate = wp.template( 'struct-footer-color' )
		,cssBloginfoTemplate = wp.template( 'struct-blog-info' )
		,cssBlogformatTemplate = wp.template( 'struct-blog-format' )
		,cssBlogframeTemplate = wp.template( 'struct-blog-frame' )
		,cssBlogoverlayTemplate = wp.template( 'struct-blog-overlay' )
	;

	api( 'color_scheme', function( value ) {
        value.bind( function( color ) {
            var 
				colors = {
					color: color,
					hex2rgb: Color( color ).toCSS( 'rgba', 0.7 )
				}
				,css = cssColorTemplate( colors )
			;

			api.previewer.refresh();

        } );
    });

    api( 'background_image', function( value ) {
        value.bind( function( img_url ) {
            var 
				c = api.control.instance( 'background_image' )
				,data = {
					img_url: c.params.attachment.sizes ? c.params.attachment.sizes.full.url : ''
				}
				,css = data.img_url ? cssBoxedLayoutsTemplate( data ) : ''
			;

			api.previewer.send( 'update-boxed-layouts-css', css );
        } );
    });


    function topbar() {
	    var 
			bg = api( 'topbar_bg' )()
			,color = api( 'topbar_color' )()
			,data = {
				bg: bg
				,color: color
			}
			,css = cssTopbarTemplate( data )
		;

		api.previewer.send( 'update-topbar-css', css );
	}

    _.each( [ 'topbar_bg', 'topbar_color' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( topbar );
		} );
	} );

    api( 'header_image', function( value ) {
        value.bind( function( img_url ) {
            var 
				c = api( 'header_image' )()
				,data = {
					bg: c
				}
				,css = data.bg ? cssHeaderBgTemplate( data ) : ''
			;

			api.previewer.send( 'update-header-bg-css', css );
        } );
    });
    
    _.each( [ 'footer_c1', 'footer_c2', 'footer_c3' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
			    api.previewer.save().done( function() {
		        	api.previewer.refresh();
		        } );
			} );
		} );
	} );
	
    api( 'rtl_enable', function( value ) {
        value.bind( function() {
            api.previewer.save().done( function() {
            	api.previewer.refresh();
            } );
        } );
    });

    function loader() {
	    var 
			style = api( 'loader_style' )()
			,color = api( 'color_scheme' )()
			,visibility = api( 'loader_visibility' )()
			,data = {
				color: color,
				visibility: visibility,
			}
			,css = wp.template( 'struct-loader-skin-' + style )
		;

		style && api.previewer.send( 'update-loader-css', css( data ) );
	}

    _.each( [ 'loader_style', 'loader_visibility' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( loader );
		} );
	} );
	
    _.each( [ 'scol', 'sitems', 'smode' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
			    api.previewer.refresh();
			} );
		} );
	} );

    function bloginfo() {
	    var 
			pos = api( 'bloginfo_pos' )()
			,corner = api( 'bloginfo_corner' )()
			,bg = api( 'bloginfo_bg' )()
			,data = {
				corner: corner,
				bg: bg,
			}
		;

		api.previewer.send( 'update-blog-info-css', { css: cssBloginfoTemplate( data ), pos: pos } );
	}

    _.each( [ 'bloginfo_pos', 'bloginfo_corner', 'bloginfo_bg' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( bloginfo );
		} );
	} );

    function blogformat() {
	    var 
			corner = api( 'blogformat_corner' )()
			,corner_color = api( 'blogformat_corner_color' )()
			,bg = api( 'blogformat_bg' )()
			,color = api( 'blogformat_color' )()
			,data = {
				corner: corner,
				corner_color: corner_color,
				bg: bg,
				color: color,
			}
		;

		api.previewer.send( 'update-blog-format-css', cssBlogformatTemplate( data ) );
	}

    _.each( [ 'blogformat_corner', 'blogformat_corner_color', 'blogformat_bg', 'blogformat_color' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( blogformat );
		} );
	} );

    function blogframe() {
	    var 
			corner = api( 'blogframe_corner' )()
			,corner_width = api( 'blogframe_corner_width' )()
			,corner_style = api( 'blogframe_corner_style' )()
			,corner_color = api( 'blogframe_corner_color' )()
			,padding = api( 'blogframe_padding' )()
			,bg = api( 'blogframe_bg' )()
			,shadow_color = api( 'blogframe_shadow_color' )()
			,data = {
				corner: corner,
				corner_width: corner_width,
				corner_style: corner_style,
				corner_color: corner_color,
				padding: padding,
				bg: bg,
				shadow_color: shadow_color,
			}
		;

		api.previewer.send( 'update-blog-frame-css', cssBlogframeTemplate( data ) );
	}

    _.each( [ 'blogframe_corner', 'blogframe_corner_width', 'blogframe_corner_style', 'blogframe_corner_color', 'blogframe_padding', 'blogframe_bg', 'blogframe_shadow_color' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( blogframe );
		} );
	} );
	
	function blogoverlay() {
	    var 
			style = api( 'blogoverlay_style' )()
		;

		api.previewer.send( 'update-blog-overlay-css', { css: cssBlogoverlayTemplate( style ), style: style } );
	}

    _.each( [ 'blogoverlay_style' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( blogoverlay );
		} );
	} );

	 _.each( [ 'shop_thumbnails_pos', 'shop_thumbnails_items' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
			    api.previewer.refresh();
			} );
		} );
	} );

	_.each( [ 'fb', 'twitter', 'google', 'linkedin', 'pinterest' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
			    api.previewer.refresh();
			} );
		} );
	} );

	_.each( [ 'blogmeta_author', 'blogmeta_cate', 'blogmeta_comment', 'blogmeta_edit' ], function( setting ) {
		api( setting, function( setting ) {
			setting.bind( function() {
			    api.previewer.refresh();
			} );
		} );
	} );

} )( wp.customize, jQuery );
