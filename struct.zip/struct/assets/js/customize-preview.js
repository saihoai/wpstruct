/**
 * Live-update changed settings in real time in the Customizer preview.
 */

( function( $ ) {
	"use strict";

	var 
		style = $( '#struct-color-scheme-css' )
		,style_boxed_layouts = $( '#struct-boxed-layouts-css' )
		,style_topbar = $( '#struct-topbar-css' )
		,style_header_bg = $( '#struct-header-bg-css' )
		,style_footer_color = $( '#struct-footer-color-css' )
		,style_loader = $( '#struct-loader-css' )
		,style_bloginfo = $( '#struct-bloginfo-css' )
		,style_blogformat = $( '#struct-blogformat-css' )
		,style_blogframe = $( '#struct-blogframe-css' )
		,style_blogoverlay = $( '#struct-blogoverlay-css' )
		,api = wp.customize
	;

	if ( ! style_boxed_layouts.length ) {
		style_boxed_layouts = $( 'head' ).append( '<style type="text/css" id="struct-boxed-layouts-css" />' )
		                    .find( '#struct-boxed-layouts-css' );
	}

	if ( ! style_topbar.length ) {
		style_topbar = $( 'head' ).append( '<style type="text/css" id="struct-topbar-css" />' )
		                    .find( '#struct-topbar-css' );
	}

	if ( ! style_header_bg.length ) {
		style_header_bg = $( 'head' ).append( '<style type="text/css" id="struct-header-bg-css" />' )
		                    .find( '#struct-header-bg-css' );
	}

	if ( ! style_footer_color.length ) {
		style_footer_color = $( 'head' ).append( '<style type="text/css" id="struct-footer-color-css" />' )
		                    .find( '#struct-footer-color-css' );
	}

	if ( ! style_loader.length ) {
		style_loader = $( 'head' ).append( '<style type="text/css" id="struct-loader-css" />' )
		                    .find( '#struct-loader-css' );
	}

	if ( ! style_bloginfo.length ) {
		style_bloginfo = $( 'head' ).append( '<style type="text/css" id="struct-bloginfo-css" />' )
		                    .find( '#struct-bloginfo-css' );
	}

	if ( ! style_blogformat.length ) {
		style_blogformat = $( 'head' ).append( '<style type="text/css" id="struct-blogformat-css" />' )
		                    .find( '#struct-blogformat-css' );
	}

	if ( ! style_blogframe.length ) {
		style_blogframe = $( 'head' ).append( '<style type="text/css" id="struct-blogframe-css" />' )
		                    .find( '#struct-blogframe-css' );
	}

	if ( ! style_blogoverlay.length ) {
		style_blogoverlay = $( 'head' ).append( '<style type="text/css" id="struct-blogoverlay-css" />' )
		                    .find( '#struct-blogoverlay-css' );
	}

	// Site title.
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );

	// Site tagline.
	api( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// Add custom-background-image body class when background image is added.
	api( 'background_image', function( value ) {
		value.bind( function( to ) {
			$( 'body' ).toggleClass( 'custom-background-image', '' !== to );
		} );
	} );


	// Boxed layouts CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-boxed-layouts-css', function( css ) {
			style_boxed_layouts.html( css );
		} );
	} );

	// topbar CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-topbar-css', function( css ) {
			style_topbar.html( css );
		} );
	} );

	// header background CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-header-bg-css', function( css ) {
			style_header_bg.html( css );
		} );
	} );

	// footer color CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-footer-color-css', function( css ) {
			style_footer_color.html( css );
		} );
	} );

	// loader color CSS
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-loader-css', function( css ) {
			style_loader.html( css );
			Pace.restart();
		} );
	} );

	// blog info CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-blog-info-css', function( d ) {
			if( d )
			{
				style_bloginfo.html( d.css );
				$( '.blog-info' ).removeClass( 'tl tc tr rt rc rb br bc bl lb lc lt' ).addClass( d.pos );
			}
		} );
	} );

	// Blog format CSS
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-blog-format-css', function( css ) {
			style_blogformat.html( css );
		} );
	} );

	// Blog frame CSS
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-blog-frame-css', function( css ) {
			style_blogframe.html( css );
		} );
	} );

	// Blog overlay CSS
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'update-blog-overlay-css', function( d ) {
			if( !d )
			{
				return;
			}
			style_blogoverlay.html( d.css );
			$( '.effect-phoebe' ).removeClass( 'style1 style2  style3 style4 style5 style6 style7 style8 styl9 styl10' ).addClass( d.style );
		} );
	} );

} )( jQuery );
