<?php

/**
 * Core class used to implement the About widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class About_Widget extends WP_Widget {

	/**
	 * Sets up a new About widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a about to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'about', __('About'), $widget_ops );
	}

	/**
	 * Outputs the content for the current About widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {
		// Get menu
		$img = ! empty( $instance['img'] ) ? $instance['img'] : false;
		$desc = ! empty( $instance['desc'] ) ? $instance['desc'] : false;
		$nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];

		if ( !empty($instance['title']) )
			echo $args['before_title'] . $instance['title'] . $args['after_title'];

		$nav_menu_args = array(
			'fallback_cb' 	=> '',
			'menu'        	=> $nav_menu,
			'items_wrap'	=> '<ul id="%1$s" class="social-icons social-color %2$s">%3$s</ul>',
			'echo'			=> false
		);

		/**
		 * Filters the arguments for the Custom Menu widget.
		 *
		 * @since 4.2.0
		 * @since 4.4.0 Added the `$instance` parameter.
		 *
		 * @param array    $nav_menu_args {
		 *     An array of arguments passed to wp_nav_menu() to retrieve a custom menu.
		 *
		 *     @type callable|bool $fallback_cb Callback to fire if the menu doesn't exist. Default empty.
		 *     @type mixed         $menu        Menu ID, slug, or name.
		 * }
		 * @param stdClass $nav_menu      Nav menu object for the current menu.
		 * @param array    $args          Display arguments for the current widget.
		 * @param array    $instance      Array of settings for the current widget.
		 */
		$icons = wp_nav_menu( apply_filters( 'widget_nav_menu_args', $nav_menu_args, $nav_menu, $args, $instance ) );


		echo '
		<div class="footer-about">'. ( $img ? '<a href="'.home_url( '/' ).'"><img src="'.$img.'" alt="" /></a>' : '' ) . '
            '. ( $desc ? '<p>'.esc_html($desc).'</p>' : '' ) . '
            <div class="mb-20"></div>
            <!-- end .mb-20 -->
            '.( $icons ? $icons : '' ).'
            <div class="clearfix"></div>
          </div>
          <!-- end .footer-about --> 
		';

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['img'] ) ) {
			$instance['img'] = $new_instance['img'];
		}
		if ( ! empty( $new_instance['desc'] ) ) {
			$instance['desc'] = $new_instance['desc'];
		}
		if ( ! empty( $new_instance['nav_menu'] ) ) {
			$instance['nav_menu'] = (int) $new_instance['nav_menu'];
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		global $wp_customize;
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$img = isset( $instance['img'] ) ? $instance['img'] : '';
		$desc = isset( $instance['desc'] ) ? $instance['desc'] : '';
		$nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

		// Get menus
		$menus = wp_get_nav_menus();

		wp_enqueue_media();

		?>
		<div class="flickr-widget-form-controls">
			<p class="nav-menu-widget-no-menus-message" <?php if ( ! empty( $menus ) ) { echo ' style="display:none" '; } ?>>
				<?php
				if ( $wp_customize instanceof WP_Customize_Manager ) {
					$url = 'javascript: wp.customize.panel( "nav_menus" ).focus();';
				} else {
					$url = admin_url( 'nav-menus.php' );
				}
				?>
				<?php echo sprintf( __( 'No menus have been created yet. <a href="%s">Create some</a>.' ), esc_attr( $url ) ); ?>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<p class="wrap-img">
				<a href="javascript:void(0);" onclick="mediaControl.frame().open()" class="button blazersix-media-control-choose"><?php _e( 'Choose an Image', 'struct' ); ?></a>
			</p>
			<p class="wrap-img">
				<img src="<?php echo esc_attr( $img ); ?>" alt="" />
				<input type="hidden" class="widefat" id="<?php echo $this->get_field_id( 'img' ); ?>" name="<?php echo $this->get_field_name( 'img' ); ?>" value="<?php echo esc_attr( $img ); ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'desc' ); ?>"><?php _e( 'Description:' ) ?></label>
				<textarea class="widefat" id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name( 'desc' ); ?>"><?php echo esc_attr( $desc ); ?></textarea>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'nav_menu' ); ?>"><?php _e( 'Select Menu:' ); ?></label>
				<select id="<?php echo $this->get_field_id( 'nav_menu' ); ?>" name="<?php echo $this->get_field_name( 'nav_menu' ); ?>">
					<option value="0"><?php _e( '&mdash; Select &mdash;' ); ?></option>
					<?php foreach ( $menus as $menu ) : ?>
						<option value="<?php echo esc_attr( $menu->term_id ); ?>" <?php selected( $nav_menu, $menu->term_id ); ?>>
							<?php echo esc_html( $menu->name ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</p>
			<?php if ( $wp_customize instanceof WP_Customize_Manager ) : ?>
				<p class="edit-selected-nav-menu" style="<?php if ( ! $nav_menu ) { echo 'display: none;'; } ?>">
					<button type="button" class="button"><?php _e( 'Edit Menu' ) ?></button>
				</p>
			<?php endif; ?>
		</div>
		<script>
			jQuery(function($) {
				mediaControl = {
					// Initializes a new media manager or returns an existing frame.
					// @see wp.media.featuredImage.frame()
					frame: function() {
						if ( this._frame )
							return this._frame;

						this._frame = wp.media({
							title: '<?php _e( 'Dialog image', 'struct' ); ?>',
							library: {
								type: 'image'
							},
							button: {
								text: '<?php _e( 'Choose image', 'struct' ); ?>'
							},
							multiple: false
						});
						
						this._frame.on( 'open', this.updateFrame ).state('library').on( 'select', this.select );
						
						return this._frame;
					},
					
					select: function() {
						attachment = mediaControl.frame().state().get('selection').first().toJSON();
						$( '.wrap-img img' ).attr( 'src', attachment.url );
						$( '.wrap-img [type="hidden"]' ).val( attachment.url ).change();
					},
					
					updateFrame: function() {
						// Do something when the media frame is opened.
					},
					
					init: function() {
						window.mediaControl = mediaControl;		
					}
				};

				
				
				mediaControl.init();
			});
		</script>
		<?php
	}
}

function about_load_widget() {
	register_widget( 'About_Widget' );
}
add_action( 'widgets_init', 'about_load_widget' );

