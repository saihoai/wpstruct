<?php

/**
 * Core class used to implement the Font widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class Font_Widget extends WP_Widget {

	private $fields = array( 'title', 'cate', 'style', 'subsets', 'fx', 'size', 'fontstyle', 'fontweight', 'selector' );
	private $fxes = array(
		'default' 					=> array(
			'label' => 'None',
			'css'	=> array()
		),
		'anaglyph' 			=> array(
			'label' => 'anaglyph',
			'css' => array(
				'text-shadow: -0.06em 0 red, 0.06em 0 cyan!important;'
			)
		),
		'brick-sign' 		=> array(
			'label' => 'brick-sign',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/brick-sign.png)!important;',
				//'color: #600!important;',
			)
		),
		'canvas-print' 		=> array(
			'label' => 'canvas-print',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/canvas-print.png)!important;',
				//'color: #776d63!important;',
			)
		),
		'crackle' 			=> array(
			'label' => 'crackle',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/crackle.png)!important;',
				//'color: #963!important;',
			)
		),
		'decaying' 			=> array(
			'label' => 'decaying',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/decaying.png)!important;',
				//'color: #958e75!important;',
			)
		),
		'destruction' 		=> array(
			'label' => 'destruction',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/destruction.png)!important;',
				//'color: #000!important;',
			)
		),
		'distressed' 		=> array(
			'label' => 'distressed',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/distress-light.png)!important;',
				//'color: #306!important;',
			)
		),
		'distressed-wood' 	=> array(
			'label' => 'distressed-wood',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/distressed-wood.png)!important;',
				//'color: #4d2e0d!important;',
			)
		),
		'emboss' 			=> array(
			'label' => 'emboss',
			'css' => array(
				'text-shadow: 0px 1px 1px #fff, 0 -1px 1px #000!important;',
				//'color: #ddd!important;',
			)
		),
		'fire' 				=> array(
			'label' => 'fire',
			'css' => array(
				'text-shadow: 0 -0.05em 0.2em #FFF, 0.01em -0.02em 0.15em #FE0, 0.01em -0.05em 0.15em #FC0, 0.02em -0.15em 0.2em #F90, 0.04em -0.20em 0.3em #F70, 0.05em -0.25em 0.4em #F70, 0.06em -0.2em 0.9em #F50, 0.1em -0.1em 1.0em #F40!important;',
				//'color: #ffe!important;',
			)
		),
		'fire-animation' 	=> array(
			'label' => 'fire-animation',
			'css' => array(
				'-webkit-animation-duration:0.8s!important;',
				'-webkit-animation-name:font-effect-fire-animation-keyframes!important;',
				'-webkit-animation-iteration-count:infinite!important;',
				'-webkit-animation-direction:alternate!important;',
				//'color: #ffe!important;',
			),
			'keyframe' => array(
				'@-webkit-keyframes font-effect-fire-animation-keyframes {
				  0% {
				    text-shadow: 0 -0.05em 0.2em #FFF, 0.01em -0.02em 0.15em #FE0, 0.01em -0.05em 0.15em #FC0, 0.02em -0.15em 0.2em #F90, 0.04em -0.20em 0.3em #F70,0.05em -0.25em 0.4em #F70, 0.06em -0.2em 0.9em #F50, 0.1em -0.1em 1.0em #F40;
				  }
				  25% {
				    text-shadow: 0 -0.05em 0.2em #FFF, 0 -0.05em 0.17em #FE0, 0.04em -0.12em 0.22em #FC0, 0.04em -0.13em 0.27em #F90, 0.05em -0.23em 0.33em #F70, 0.07em -0.28em 0.47em #F70, 0.1em -0.3em 0.8em #F50, 0.1em -0.3em 0.9em #F40;
				  }
				  50% {    text-shadow: 0 -0.05em 0.2em #FFF, 0.01em -0.02em 0.15em #FE0, 0.01em -0.05em 0.15em #FC0, 0.02em -0.15em 0.2em #F90, 0.04em -0.20em 0.3em #F70,0.05em -0.25em 0.4em #F70, 0.06em -0.2em 0.9em #F50, 0.1em -0.1em 1.0em #F40;
				  }
				  75% {
				    text-shadow: 0 -0.05em 0.2em #FFF, 0 -0.06em 0.18em #FE0, 0.05em -0.15em 0.23em #FC0, 0.05em -0.15em 0.3em #F90, 0.07em -0.25em 0.4em #F70, 0.09em -0.3em 0.5em #F70, 0.1em -0.3em 0.9em #F50, 0.1em -0.3em 1.0em #F40;
				  }
				  100% {
				    text-shadow: 0 -0.05em 0.2em #FFF, 0.01em -0.02em 0.15em #FE0, 0.01em -0.05em 0.15em #FC0, 0.02em -0.15em 0.2em #F90, 0.04em -0.20em 0.3em #F70,0.05em -0.25em 0.4em #F70, 0.06em -0.2em 0.9em #F50, 0.1em -0.1em 1.0em #F40;
				  }
				}'
			)
		),
		'fragile' 			=> array(
			'label' => 'fragile',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/fragile.png)!important;',
				//'color: #663!important;',
			)
		),
		'grass' 			=> array(
			'label' => 'grass',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/grass.png)!important;',
				//'color: #390!important;',
			)
		),
		'ice' 				=> array(
			'label' => 'ice',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/ice.png)!important;',
				//'color: #0cf!important;',
			)
		),
		'mitosis' 			=> array(
			'label' => 'mitosis',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/mitosis.png)!important;',
				//'color: #600!important;'
			)
		),
		'neon' 				=> array(
			'label' => 'neon',
			'css' => array(
				'text-shadow: 0 0 0.1em #fff, 0 0 0.2em #fff, 0 0 0.3em #fff, 0 0 0.4em #f7f,0 0 0.6em #f0f, 0 0 0.8em #f0f, 0 0 1.0em #f0f, 0 0 1.2em #f0f!important;',
				//'color: #fff!important;',
			)
		),
		'outline' 			=> array(
			'label' => 'outline',
			'css' => array(
				'text-shadow:0 1px 1px #000, 0 -1px 1px #000, 1px 0 1px #000, -1px 0 1px #000!important;',
				//'color: #fff!important;',
			)
		),
		'putting-green' 	=> array(
			'label' => 'putting-green',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/putting-green.png)!important;',
				//'color: #390!important;',
			)
		),
		'scuffed-steel' 	=> array(
			'label' => 'scuffed-steel',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/scuffed-steel.png)!important;',
				//'color: #acacac!important;',
			)
		),
		'shadow-multiple' 	=> array(
			'label' => 'shadow-multiple',
			'css' => array(
				'text-shadow: .04em .04em 0 #fff,.08em .08em 0 #aaa!important;',
				'-webkit-text-shadow: .04em .04em 0 #fff, .08em .08em 0 #aaa!important;',
			)
		),
		'splintered' 		=> array(
			'label' => 'splintered',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/splintered.png)!important;',
				//'color: #5a3723!important;',
			)
		),
		'static' 			=> array(
			'label' => 'static',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/static.png)!important;',
				'text-shadow: 0 0 2px #fff, 0 0 4px #fff, 0 0 6px #fff, 0 0 8px #999999, 0 0 10px #000000!important;',
				//'color: #343956!important;',
			)
		),
		'stonewash' 		=> array(
			'label' => 'stonewash',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/stonewash.png)!important;',
				//'color: #343956!important;',
			)
		),
		'3d' 				=> array(
			'label' => '3d',
			'css' => array(
				'text-shadow: 0px 1px 0px #c7c8ca, 0px 2px 0px #b1b3b6, 0px 3px 0px #9d9fa2, 0px 4px 0px #8a8c8e, 0px 5px 0px #77787b, 0px 6px 0px #636466, 0px 7px 0px #4d4d4f, 0px 8px 7px #001135!important;',
				//'color: #fff!important;',
			)
		),
		'3d-float' 			=> array(
			'label' => '3d-float',
			'css' => array(
				'text-shadow: 0 0.032em 0 #b0b0b0, 0px 0.15em 0.11em rgba(0,0,0,0.15), 0px 0.25em 0.021em rgba(0,0,0,0.1), 0px 0.32em 0.32em rgba(0,0,0,0.1)!important;',
				//'color: #fff!important;',
			)
		),
		'vintage' 			=> array(
			'label' => 'vintage',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/distress-medium.png)!important;',
				//'color: #db8!important;',
			)
		),
		'wallpaper' 		=> array(
			'label' => 'wallpaper',
			'css' => array(
				'-webkit-mask-image: url(//themes.googleusercontent.com/static/patterns/wallpaper.png)!important;',
				//'color: #9c7!important;',
			)
		),
	);
	/**
	 * Sets up a new Font widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a Font to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'Font', __('Font'), $widget_ops );
	}

	function getFX( $fx = '' )
	{
		return ( isset( $this->fxes[ $fx ] ) ? $this->fxes[ $fx ] : false );
	}

	function getFields()
	{
		return $this->fields;
	}

	/**
	 * Outputs the content for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {

	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		foreach( $this->fields as $field )
		{
			if ( ! empty( $new_instance[ $field ] ) ) 
			{
				$instance[ $field ] = $new_instance[ $field ];
			}
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		foreach( $this->fields as $field )
		{
			${$field} = isset( $instance[ $field ] ) ? $instance[ $field ] : '';
		}
		$fontweight_args = array( 
			'normal',
			'100', 
			'200', 
			'300', 
			'400', 
			'500',
			'600',
			'700',
			'800',
			'900',
			'bold',
			'lighter',
		);
		?>
		<div class="font-widget-form-controls">
			<p>
				<label><?php esc_html_e( 'Title:', 'struct' ) ?></label>
				<?php $title_id = 'title' . rand(); ?>
				<input type="text" class="widefat form-control-font" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
				<input type="hidden" class="f-cate widefat" id="<?php echo $this->get_field_id( 'cate' ); ?>" name="<?php echo $this->get_field_name( 'cate' ); ?>" value="<?php echo esc_attr( $cate ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'style' ); ?>"><?php esc_html_e( 'Style:', 'struct' ) ?></label>
				<input type="hidden" class="widefat f-style" id="<?php echo $this->get_field_id( 'style' ); ?>" value="<?php echo esc_attr( is_array( $style ) ? implode( ',', $style ) : $style ); ?>"/>
				<div class="controls-style"></div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'subsets' ); ?>"><?php esc_html_e( 'Subsets:', 'struct' ) ?></label>
				<input type="hidden" class="widefat f-subsets" id="<?php echo $this->get_field_id( 'subsets' ); ?>" value="<?php echo esc_attr( is_array( $subsets ) ? implode( ',', $subsets ) : $subsets ); ?>"/>
				<div class="controls-subsets"></div>
			</p>
			<hr>
			<p>
				<label for="<?php echo $this->get_field_id( 'fx' ); ?>"><?php esc_html_e( 'Effect:', 'struct' ) ?></label>
				<select class="widefat" id="<?php echo $this->get_field_id( 'fx' ); ?>" name="<?php echo $this->get_field_name( 'fx' ); ?>">
				<?php foreach( $this->fxes as $k => $item ) : ?>
					<option <?php selected( $fx, $k ); ?> value="<?php echo esc_attr( $k ); ?>"><?php echo esc_attr( $item['label'] ); ?></option>
				<?php endforeach ?>
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'size' ); ?>"><?php esc_html_e( 'Font Size:', 'struct' ) ?></label>
				<input type="text" class="widefat f-size" id="<?php echo $this->get_field_id( 'size' ); ?>" name="<?php echo $this->get_field_name( 'size' ); ?>" value="<?php echo esc_attr( $size ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'fontstyle' ); ?>"><?php esc_html_e( 'Font Style:', 'struct' ) ?></label>
				<select class="widefat f-fontstyle" id="<?php echo $this->get_field_id( 'fontstyle' ); ?>" name="<?php echo $this->get_field_name( 'fontstyle' ); ?>">
				<?php foreach( array( 'normal', 'italic', 'oblique') as $k ) : ?>
					<option <?php selected( $fontstyle, $k ); ?> value="<?php echo esc_attr( $k ); ?>"><?php echo esc_attr( $k ); ?></option>
				<?php endforeach ?>
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'fontweight' ); ?>"><?php esc_html_e( 'Font Weight:', 'struct' ) ?></label>
				<select class="widefat f-fontweight" id="<?php echo $this->get_field_id( 'fontweight' ); ?>" name="<?php echo $this->get_field_name( 'fontweight' ); ?>">
				<?php foreach( $fontweight_args as $k ) : ?>
					<option <?php selected( $fontweight, $k ); ?> value="<?php echo esc_attr( $k ); ?>"><?php echo esc_attr( $k ); ?></option>
				<?php endforeach ?>
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'selector' ); ?>"><?php esc_html_e( 'Selector:', 'struct' ) ?></label>
				<input type="text" class="widefat f-selector" id="<?php echo $this->get_field_id( 'selector' ); ?>" name="<?php echo $this->get_field_name( 'selector' ); ?>" value="<?php echo esc_attr( $selector ); ?>"/>
			</p>
		</div>
        <script>
			jQuery( function( $ ) {
				function s()
				{
					var rs = this;

					if( rs && rs.items )
					{
						$( '.form-control-font' ).each( function( a ) {
							var e = $( this )
								,ec = $( '<datalist>', { id: 'list' + $.now() } )
							;
							if( !e.parent().find( 'datalist').length )
							{
								e.data( 'fonts', rs );
								$.each( rs.items, function( i, item ) {
									ec.append( $( '<option>', { value: item.family,  text: item.family } ) );
								} );
								ec.insertAfter( e );
							}
							e.trigger( 'change' );
						} );
					}
				}
				if( !window.gfonts )
				{
					$.getJSON( 'https://www.googleapis.com/webfonts/v1/webfonts?key=AIzaSyAJXWUoZGGH0Y5Rmn1HoNW8cj2pYogX2lg', function( rs ) {
						s.call( rs );
						window.gfonts = rs;
					} );	
				}
				else
				{
					s.call( window.gfonts );
				}	

				$( document ).delegate( '.form-control-font', 'change', function() {
					var 
						e = $( this )
						,db = e.next( 'datalist' )
						,w = e.closest( '.font-widget-form-controls' )
						,d = window.gfonts
						,cv = e.val()
						,cstyle = w.find( '.controls-style' ).empty()
						,cstylev = w.find( '.f-style' ).val().split( ',' )
						,csubsets = w.find( '.controls-subsets' ).empty()
						,csubsetsv = w.find( '.f-subsets' ).val().split( ',' )
					;

					e.attr( 'list', db.attr( 'id' ) );

					if( !d )
					{
						return;
					}
					var i = db.find( 'option[value="' + cv + '"]' ).index();
					if( i == -1 )
					{
						return;
					}

					if( $.isArray( cstylev ) && !cstylev.length)
					{
						cstylev.push( 'regular' );
					}
					if( $.isArray( csubsetsv ) && !csubsetsv.length)
					{
						csubsetsv.push( 'latin' );
					}

					d = d.items[ i ];

					w.find( '.f-cate' ).val( d.category );

					d.variants && $.each( d.variants, function( a, item ) {
						var f = '<p><label><input type="checkbox" name="<?php echo $this->get_field_name( 'style' ); ?>[]" value="{{value}}" {{checked}}>{{value}}</label></p>';
						$.each( { '{{value}}': item, '{{checked}}': ( $.inArray(item, cstylev ) > -1  ? 'checked' : '' ) }, function( k, v ) {
							f = f.replace( new RegExp( k, 'g' ), v );
						} );
						cstyle.append( f );
					} );

					d.subsets && $.each( d.subsets, function( a, item ) {
						var f = '<p><label><input type="checkbox" name="<?php echo $this->get_field_name( 'subsets' ); ?>[]" value="{{value}}" {{checked}}>{{value}}</label></p>';
						$.each( { '{{value}}': item, '{{checked}}': ( $.inArray(item, csubsetsv ) > -1 ? 'checked' : '' ) }, function( k, v ) {
							f = f.replace( new RegExp( k, 'g' ), v );
						} );
						csubsets.append( f );
					} );

				} );
			} );
		</script>
		<?php
	}
}

if( !function_exists( 'Font_load_widget' ) )
{
	function Font_load_widget() 
	{
		register_widget( 'Font_Widget' );
	}
}
add_action( 'widgets_init', 'Font_load_widget' );

if( !function_exists( 'font_enqueue_scripts' ) )
{
	function font_enqueue_scripts()
	{
		$sb = get_option( 'sidebars_widgets' );
		$widgets = get_option( 'widget_font' );
		if( !$sb )
		{
			return;
		}
		if( !$widgets )
		{
			return;
		}
		if( !isset( $sb[ 'afterbody' ] ) )
		{
			return;
		}
		$font = new Font_Widget();
		$fields = $font->getFields();
		foreach( $sb[ 'afterbody' ] as $id )
		{
			$id = trim( str_replace( 'font-', '', $id ) );
			if( !isset( $widgets[ $id ] ) )
			{
				continue;
			}
			$instance 	= $widgets[ $id ];
			foreach( $fields as $field )
			{
				${$field} = isset( $instance[ $field ] ) ? $instance[ $field ] : '';
			}

			if( empty( $title ) )
			{
				continue;
			}

			if( empty( $selector ) )
			{
				continue;
			}

			$font_args = array(
				'family' => urlencode( $title . ( is_array( $style ) && count( $style ) > 0 ? ( ':' . implode( ',', $style ) ) : '' ) ),
			);
			if( is_array( $subsets ) && count( $subsets ) > 0 )
			{
				$font_args[ 'subsets' ] = implode( ',', $subsets );
			}

			$src = add_query_arg( $font_args, 'https://fonts.googleapis.com/css' );
			$handle = sanitize_title( implode( '-', array( 'font', $title, $selector ) ) );

			wp_enqueue_style( $handle, $src, array(), null );
			$css = array(
				$selector,
				'{',
			);
			$keyframe = '';
			if( $fx = $font->getFX( $fx ) )
			{
				if( isset( $fx[ 'css' ] ) )
				{
					$css = array_merge( $css, $fx[ 'css' ] );
				}
				if( isset( $fx[ 'keyframe' ] ) )
				{
					$keyframe = $fx[ 'keyframe' ];
				}
			}
			$css_ex = array(
				'title' => sprintf( 'font-family:"%1$s"%2$s!important;', $title, ( !empty( $cate ) ? ",{$cate}" : "" ) ),
				'size' => sprintf( 'font-size: %1$s!important;', $size ),
				'fontstyle' => sprintf( 'font-style: %1$s!important;', $fontstyle ),
				'fontweight' => sprintf( 'font-weight: %1$s!important;', $fontweight ),
			);
			foreach( $css_ex as $k => $v )
			{
				if( empty( ${$k} ) )
				{
					continue;
				}
				$css[] = $v;
			}

			$css[] = '}';
			wp_add_inline_style( $handle, implode( "\n", $css ) . $keyframe );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'font_enqueue_scripts' );




