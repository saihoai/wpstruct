<?php

/**
 * Core class used to implement the Phone widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class Phone_Widget extends WP_Widget {

	/**
	 * Sets up a new Phone widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a phone to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'phone', __('Phone'), $widget_ops );
	}

	/**
	 * Outputs the content for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {
		// Get Icon
		$icon = ! empty( $instance['icon'] ) ? $instance['icon'] : false;
		$phone = ! empty( $instance['phone'] ) ? $instance['phone'] : false;

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];

		if ( !empty($instance['title']) )
			echo $args['before_title'] . $instance['title'] . $args['after_title'];

		if( $icon )
		{
			echo "<i class='fa {$icon}'></i>";
		}

		if( $phone )
		{
			echo $phone;
		}

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['icon'] ) ) {
			$instance['icon'] = $new_instance['icon'];
		}
		if ( ! empty( $new_instance['phone'] ) ) {
			$instance['phone'] = $new_instance['phone'];
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$icon = isset( $instance['icon'] ) ? $instance['icon'] : '';
		$phone = isset( $instance['phone'] ) ? $instance['phone'] : '';
		?>
		<div class="phone-widget-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'struct' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<?php $icon_id = $this->get_field_id( 'icon' ); ?>
			<p>
				<label for="<?php echo $this->get_field_id( 'icon' ); ?>"><?php _e( 'Icon:', 'struct' ) ?></label>
				<input type="text" class="f-icon widefat" id="<?php echo $icon_id; ?>" name="<?php echo $this->get_field_name( 'icon' ); ?>" value="<?php echo esc_attr( $icon ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'phone' ); ?>"><?php _e( 'Phone:', 'struct' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" value="<?php echo esc_attr( $phone ); ?>"/>
			</p>
		</div>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
		<link rel="stylesheet" href="<?php echo plugins_url( 'colorpicker/fontawesome-iconpicker.css', __FILE__ ); ?>">
		<script src="<?php echo plugins_url( 'colorpicker/fontawesome-iconpicker.js', __FILE__ ); ?>"></script>
		<script>
			jQuery( function($) {
				$('.f-icon').iconpicker();
			})
		</script>
		<?php
	}
}

function phone_load_widget() {
	register_widget( 'Phone_Widget' );
}
add_action( 'widgets_init', 'phone_load_widget' );

