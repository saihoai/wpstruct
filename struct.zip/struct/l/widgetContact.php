<?php

/**
 * Core class used to implement the Contact widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class Contact_Widget extends WP_Widget {

	/**
	 * Sets up a new Contact widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a contact to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'contact', __('Contact'), $widget_ops );
	}

	/**
	 * Outputs the content for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {
		// Get menu
		$address = ! empty( $instance['address'] ) ? $instance['address'] : false;
		$tel = ! empty( $instance['tel'] ) ? $instance['tel'] : false;
		$email = ! empty( $instance['email'] ) ? $instance['email'] : false;

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];

		if ( !empty($instance['title']) )
			echo $args['before_title'] . $instance['title'] . $args['after_title'];

		echo "<ul class='footer-list'>";
		echo "<li><i class='fa fa-map-marker'></i><span>".__( 'Address', 'struct' ).":</span><br>
          {$address}</li>
        <li><i class='fa fa-phone'></i><span>".__( 'Phone number', 'struct' ).":</span><br>
          {$tel}</li>
        <li><i class='fa fa-envelope'></i><span>".__( 'E-mail', 'struct' ).":</span><br>
          <a href='mailto:{$email}'>{$email}</a></li>";
		echo "</ul>";

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['address'] ) ) {
			$instance['address'] = $new_instance['address'];
		}
		if ( ! empty( $new_instance['tel'] ) ) {
			$instance['tel'] = $new_instance['tel'];
		}
		if ( ! empty( $new_instance['email'] ) ) {
			$instance['email'] = $new_instance['email'];
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$address = isset( $instance['address'] ) ? $instance['address'] : '';
		$tel = isset( $instance['tel'] ) ? $instance['tel'] : '';
		$email = isset( $instance['email'] ) ? $instance['email'] : '';
		?>
		<div class="flickr-widget-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'address' ); ?>"><?php _e( 'Address:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" value="<?php echo esc_attr( $address ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'tel' ); ?>"><?php _e( 'Tel:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'tel' ); ?>" name="<?php echo $this->get_field_name( 'tel' ); ?>" value="<?php echo esc_attr( $tel ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php _e( 'Email:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" value="<?php echo esc_attr( $email ); ?>"/>
			</p>
		</div>
		<?php
	}
}

function contact_load_widget() {
	register_widget( 'Contact_Widget' );
}
add_action( 'widgets_init', 'contact_load_widget' );

