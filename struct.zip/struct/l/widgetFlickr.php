<?php

/**
 * Core class used to implement the Flickr widget.
 *
 * @since 3.0.0
 *
 * @see WP_Widget
 */
class Flickr_Widget extends WP_Widget {

	/**
	 * Sets up a new Flickr widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => __( 'Add a flickr to your sidebar.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'flickr', __('Flickr'), $widget_ops );
	}

	/**
	 * Outputs the content for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Custom Menu widget instance.
	 */
	public function widget( $args, $instance ) {
		// Get menu
		$id = ! empty( $instance['id'] ) ? $instance['id'] : false;

		if ( !$id )
			return;

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];

		if ( !empty($instance['title']) )
			echo $args['before_title'] . $instance['title'] . $args['after_title'];

		echo "<ul class='flickr-cbox flickr-thumbs' data-id='{$instance['id']}' data-effect='{$instance['effect']}'></ul>";
		if( is_customize_preview() )
		{
			echo "<script>window.jQuery && jQuery( function($) { $( '[data-id=\"{$instance['id']}\"]' ).trigger( 'init-widget-flickr' ); } );</script>";
		}
		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Custom Menu widget instance.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['id'] ) ) {
			$instance['id'] = $new_instance['id'];
		}
		if ( ! empty( $new_instance['effect'] ) ) {
			$instance['effect'] = $new_instance['effect'];
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the Custom Menu widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 * @global WP_Customize_Manager $wp_customize
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$id = isset( $instance['id'] ) ? $instance['id'] : '52617155@N08';
		$effect = isset( $instance['effect'] ) ? $instance['effect'] : 'fadeScale';
		$effects = array(
			'fade' => 'Fade',
			'fadeScale' => 'Fade Scale',
			'slideLeft' => 'Slide Left',
			'slideRight' => 'Slide Right',
			'slideUp' => 'Slide Up',
			'slideDown' => 'Slide Down',
			'fall' => 'Fall',
		);
		?>
		<div class="flickr-widget-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'id' ); ?>"><?php _e( 'Flick ID:' ) ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'id' ); ?>" name="<?php echo $this->get_field_name( 'id' ); ?>" value="<?php echo esc_attr( $id ); ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'effect' ); ?>"><?php _e( 'Select effect:' ); ?></label>
				<select id="<?php echo $this->get_field_id( 'effect' ); ?>" name="<?php echo $this->get_field_name( 'effect' ); ?>">
					<?php foreach ( $effects as $k=>$v ) : ?>
						<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $effect, $k ); ?>>
							<?php echo esc_html( $v ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</p>
		</div>
		<?php
	}
}

function flickr_load_widget() {
	register_widget( 'Flickr_Widget' );
}
add_action( 'widgets_init', 'flickr_load_widget' );
if( !function_exists( 'flickr_enqueue_scripts' ) )
{
	function flickr_enqueue_scripts()
	{
		wp_enqueue_script( 'flick-script', plugins_url( '/assets/js/flickr.js' , __DIR__ ), array( 'jquery' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'flickr_enqueue_scripts' );

