<?php
/* remove single product sidebar */
function woocommerce_remove_sidebar_shop() 
{
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
    remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open' );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail' );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash' );
	remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash' );
	remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title' );
	remove_filter( 'struct_noplg_list_comments', 'struct_noplg_list_comments' );

	global $shortcode_tags;
	if( isset( $shortcode_tags[ 'yith_compare_button' ] ) )
	{
		$YITH_Woocompare_Frontend = $shortcode_tags[ 'yith_compare_button' ][0];
		remove_action( 'woocommerce_single_product_summary', array( $YITH_Woocompare_Frontend, 'add_compare_link' ), 35 );
		remove_action( 'woocommerce_after_shop_loop_item', array( $YITH_Woocompare_Frontend, 'add_compare_link' ), 20 );
	}

	add_filter( 'struct_noplg_list_comments', 'struct_plg_list_comments' );
}
add_action( 'template_redirect', 'woocommerce_remove_sidebar_shop', 10000 );


add_filter( 'woocommerce_show_page_title', 'custom_woocommerce_show_page_title');
function custom_woocommerce_show_page_title() 
{
  return false;
}

add_action( 'woocommerce_before_shop_loop_item', 'struct_woocommerce_template_loop_product_thumbnail', 20 );
if ( ! function_exists( 'struct_woocommerce_template_loop_product_thumbnail' ) ) 
{

	/**
	 * Get the product thumbnail for the loop.
	 *
	 * @subpackage	Loop
	 */
	function struct_woocommerce_template_loop_product_thumbnail() {
		ob_start();
		$mode = get_theme_mod( 'smode', '' );
		require( __DIR__ . '/tmpl/loop_product_thumbail.php' );
		echo ob_get_clean();
	}
}


add_action( 'woocommerce_after_shop_loop_item', 'struct_woocommerce_template_loop_product_link_close', 20 );
if ( ! function_exists( 'struct_woocommerce_template_loop_product_link_close' ) ) 
{

	/**
	 * Get the product thumbnail for the loop.
	 *
	 * @subpackage	Loop
	 */
	function struct_woocommerce_template_loop_product_link_close() 
	{
		$mode = get_theme_mod( 'smode', '' );
		if( $mode == 'list' && !is_single() && preg_match_all( '/woocommerce/', implode( ' ', get_body_class() ) ) ) 
		{
			global $product;
			echo apply_filters( 'woocommerce_short_description', $product->post->post_excerpt );
			$defaults = array(
				'quantity' => 1,
				'class'    => implode( ' ', array_filter( array(
						'',
						'product_type_' . $product->product_type,
						$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
						$product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : ''
				) ) )
			);
			$args = apply_filters( 'woocommerce_loop_add_to_cart_args', wp_parse_args( array(), $defaults ), $product );
			
			do_action( 'woocommerce_after_add_to_cart_button' );
			
			echo apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="btn btn-theme %s">%s</a>',
									esc_url( $product->add_to_cart_url() ),
									esc_attr( isset( $quantity ) ? $quantity : 1 ),
									esc_attr( $product->id ),
									esc_attr( $product->get_sku() ),
									esc_attr( $args[ 'class' ] ),
									'<span><i class="fa fa-chevron-circle-right"></i></span>' . $product->add_to_cart_text()
								),
							$product );
				echo '</div>
			</div>
		</div>';
		}
		else 
		{
				echo '<div class="btn-group btn-group-justified">';
					do_action( 'woocommerce_after_add_to_cart_button' );
				echo '</div>';
			echo '</div>';
		}
	}
}

add_action( 'woocommerce_shop_loop_item_title', 'struct_woocommerce_template_loop_product_title', 10 );
if (  ! function_exists( 'struct_woocommerce_template_loop_product_title' ) ) {

	/**
	 * Show the product title in the product loop. By default this is an H3.
	 */
	function struct_woocommerce_template_loop_product_title() {
		echo '<h3><a href="' . get_the_permalink() . '">'  . get_the_title() . '</a></h3>';
	}
}

add_action( 'woocommerce_before_main_content', 'struct_woocommerce_before_main_content', 20 );
if( !function_exists( 'struct_woocommerce_before_main_content' ) )
{
	function struct_woocommerce_before_main_content()
	{
		if( is_single() )
		{
			return;
		}
		if ( is_active_sidebar( 'sidebar-shop' )  )
		{
			echo '<div class="row"><div class="col-md-9">';
		}
		echo '<div class="woocommerce '. implode( ' ', array( get_theme_mod( 'scol' ), get_theme_mod( 'smode' ) ) ) .'">';
	}
}

add_action( 'woocommerce_after_main_content', 'struct_woocommerce_after_main_content', 9 );
if( !function_exists( 'struct_woocommerce_after_main_content' ) )
{
	function struct_woocommerce_after_main_content()
	{
		if( is_single() )
		{
			return;
		}
		if ( is_active_sidebar( 'sidebar-shop' )  )
		{
			echo '</div></div><div class="col-md-3 sb-shop">';
			get_sidebar( 'shop' );
			echo '</div></div>';
		}
		else
		{
			echo '</div>';
		}
	}
}

add_filter('loop_shop_columns', 'struct_loop_shop_columns', 20);
if( !function_exists( 'struct_loop_shop_columns' ) )
{
	function struct_loop_shop_columns() 
	{
		return intval( str_replace( 'columns-', '', get_theme_mod( 'scol', 4 ) ) );
	}
}

add_filter( 'loop_shop_per_page', 'struct_loop_shop_per_page' , 20 );
if( !function_exists( 'struct_loop_shop_per_page' ) )
{
	function struct_loop_shop_per_page( $posts_per_page )
	{
		$items = get_theme_mod( 'sitems', $posts_per_page );

		if( intval( $items ) > 0 )
		{
			$posts_per_page = $items;
		}
		return $posts_per_page;
	}
}
/**
* Retrieve or display nonce hidden field for forms.
*
* The nonce field is used to validate that the contents of the form came from
* the location on the current site and not somewhere else. The nonce does not
* offer absolute protection, but should protect against most cases. It is very
* important to use nonce field in forms.
*
* The $action and $name are optional, but if you want to have better security,
* it is strongly suggested to set those two parameters. It is easier to just
* call the function without any parameters, because validation of the nonce
* doesn't require any parameters, but since crackers know what the default is
* it won't be difficult for them to find a way around your nonce and cause
* damage.
*
* The input name will be whatever $name value you gave. The input value will be
* the nonce creation value.
*
* @since 2.0.4
*
* @param int|string $action  Optional. Action name. Default -1.
* @param string     $name    Optional. Nonce name. Default '_wpnonce'.
* @param bool       $referer Optional. Whether to set the referer field for validation. Default true.
* @param bool       $echo    Optional. Whether to display or return hidden form field. Default true.
* @return string Nonce field HTML markup.
*/
if( !function_exists( 'wp_nonce_field_woo_cart' ) )
{
	function wp_nonce_field_woo_cart( $action = -1 )
	{
		ob_start();
		wp_nonce_field( $action );
		$output = ob_get_clean();
		$output = preg_replace( '/id="(.[^"])+"|id=\'(.[^\'])+\'/', '', $output );
		echo $output;
	}
}
add_action( 'wp_nonce_field_woo_cart', 'wp_nonce_field_woo_cart' );
/**
 * Outputs a checkout/address form field.
 *
 * @subpackage  Forms
 * @param string $key
 * @param mixed $args
 * @param string $value (default: null)
 * @todo This function needs to be broken up in smaller pieces
 */
if( !function_exists( 'struct_woocommerce_form_field' ) )
{
	function struct_woocommerce_form_field( $key = '', $args, $value = null )
	{
		ob_start();
		woocommerce_form_field( $key, $args, $value );
		$output = ob_get_clean();
		if( preg_match( '/<input type=("|\')hidden(.[^\/])+/', $output, $rs ) )
		{
			$new = preg_replace( '/placeholder=("|\')(.[^("|\')])*("|\')/', '', $rs[ 0 ] );
			$output = str_replace( $rs[ 0 ], $new, $output );
			$output = preg_replace( '/for=("|\')([^("|\')])*("|\')/', '', $output );
		}
		echo $output;
	}
}
add_action( 'struct_woocommerce_form_field', 'struct_woocommerce_form_field', 10, 3 );

if( !function_exists( 'struct_woo_adon_plugin_template' ) )
{
   function struct_woo_adon_plugin_template( $template, $template_name, $template_path ) 
   {
	     global $woocommerce;
	     $_template = $template;
	     if ( ! $template_path ) 
	        $template_path = $woocommerce->template_url;
	 
	     $plugin_path  = untrailingslashit( plugin_dir_path( __FILE__ ) )  . '/tmpl/woocommerce/';
	 
	    // Look within passed path within the theme - this is priority
	    $template = locate_template(
	    array(
	      $template_path . $template_name,
	      $template_name
	    )
	   );
	 
	   if( ! $template && file_exists( $plugin_path . $template_name ) )
	    $template = $plugin_path . $template_name;
	 
	   if ( ! $template )
	    $template = $_template;

	   return $template;
	}
}
add_filter( 'woocommerce_locate_template', 'struct_woo_adon_plugin_template', 1, 3 );

if( !function_exists( 'struct_woocommerce_pagination' ) )
{
	function struct_woocommerce_pagination( $html = '' )
	{
		if( !preg_match( '/<ul([^>]+)/', $html, $rs ) )
		{
			return $html;
		}
		$html = str_replace( $rs[0], str_replace( 'page-numbers', 'pagination', $rs[0] ), $html );
		$text = preg_replace( '/(<ul([^>]+))|(<\/ul>)/', '', $html );
		$rs = preg_split( '/<\/li>/', $text );
		if( count( $rs ) > 0 )
		{
			foreach( $rs as $item )
			{
				$search = $item . '</li>';
				$item = preg_replace( '/span/', 'a', $item );
				$item = preg_replace( '/dots|page-numbers|prev|next/', '', $item );
				if( preg_match( '/current/', $item ) )
				{
					$item = preg_replace( '/class=("|\')([^("|\')]*)("|\')/', '', $item );
					$item = str_replace( '<li', '<li class="active" ', $item );
				}
				$html = str_replace( $search, $item, $html );
			}
		}
		return $html;
	}
}
add_filter( 'struct_woocommerce_pagination', 'struct_woocommerce_pagination' );

if( !function_exists( 'struct_woocommerce_mode' ) )
{
	function struct_woocommerce_mode()
	{
		ob_start();
		$mode = get_theme_mod( 'smode', '' );
		require_once( __DIR__ . '/tmpl/woocommerce-mode.php');
		echo ob_get_clean();
	}
}
add_action( 'woocommerce_before_shop_loop', 'struct_woocommerce_mode', 10 );
/**
 * Save the currently chosen direction on a per-user basis.
 *
 * @global WP_Locale $wp_locale Locale object.
 * @global WP_Styles $wp_styles Styles object.
 */
if( !function_exists( 'struct_set_woo_mode' ) )
{
	function struct_set_woo_mode()
	{
		if( isset( $_GET[ 'woo-mode' ] ) )
		{
			set_theme_mod( 'smode', $_GET[ 'woo-mode' ] );	
		}
	}
}
add_action( 'init', 'struct_set_woo_mode' );


if( !function_exists( 'struct_yith_wcwl_locate_template' ) ) 
{
    /**
     * Locate the templates and return the path of the file found
     *
     * @param string $path
     * @param array $var
     * @return void
     * @since 1.0.0
     */
    function struct_yith_wcwl_locate_template( $path, $var = NULL )
    {
        
        $new  = untrailingslashit( plugin_dir_path( __FILE__ ) )  . '/tmpl/yith-woocommerce-wishlist/' . basename( $path );
	 
	    if( !file_exists( $new ) )
	    {
	    	return $path;
	    }

	   return $new;
    }
}
add_filter( 'yith_wcwl_locate_template', 'struct_yith_wcwl_locate_template', 20, 2 );
if( !function_exists( 'struct_yith_wcwl_wishlist_title' ) )
{
	function struct_yith_wcwl_wishlist_title( $page_title = '' )
	{
		return '';
	}
}
add_filter( 'yith_wcwl_wishlist_title', 'struct_yith_wcwl_wishlist_title' );

if( !function_exists( 'struct_yith_wcwl_positions' ) )
{
	function struct_yith_wcwl_positions( $positions = array() )
	{
		return array(
			'add-to-cart' => array( 'hook' => 'struct-yith-woocommerce_single_product_summary', 'priority' => 31 ),
			'thumbnails'  => array( 'hook' => 'struct-yith-woocommerce_product_thumbnails', 'priority' => 21 ),
			'summary'     => array( 'hook' => 'struct-yith-woocommerce_after_single_product_summary', 'priority' => 11 )
		);
	}
}
add_filter( 'yith_wcwl_positions', 'struct_yith_wcwl_positions' );

if( !function_exists( 'struct_woocommerce_after_add_to_cart_button' ) )
{
	function struct_woocommerce_after_add_to_cart_button()
	{
		if( get_option( 'yith_wcwl_enabled' ) == 'yes' )
		{
			$text = do_shortcode( "[yith_wcwl_add_to_wishlist]" );
			if( !preg_match_all( '/\[yith_wcwl_add_to_wishlist\]/', $text ) )
			{
				echo $text;
			}
		}
		
		global $shortcode_tags;
		if( isset( $shortcode_tags[ 'yith_compare_button' ] ) )
		{
			ob_start();
			$shortcode_tags[ 'yith_compare_button' ][0]->add_compare_link();
			$text = ob_get_clean();
			if( preg_match( '/class=("|\')/', $text, $rs ) )
			{
				$text = str_replace( $rs[ 0 ], $rs[ 0 ] . 'btn btn-theme ', $text );
			}
			if( preg_match( '/>([^<]+)/', $text, $rs ) )
			{
				$text = str_replace( $rs[ 0 ], '><i class="fa fa-exchange"></i>', $text );
			}
			echo $text;
		}
	}
}
add_action( 'woocommerce_after_add_to_cart_button', 'struct_woocommerce_after_add_to_cart_button' );

if( !function_exists( 'struct_woocommerce_product_thumbnails_columns' ) )
{
	function struct_woocommerce_product_thumbnails_columns( $col = 4 )
	{
		$rtl 		= is_rtl();
		$col 		= get_theme_mod( 'shop_thumbnails_items', '4' );
		$vertical 	= in_array( get_theme_mod( 'shop_thumbnails_pos', 'bottom' ), array( 'left', 'right' ) ) ? '1' : '0';
		$prev 		= '<button type=\"button\" class=\"slick-prev\"><i class=\"fa fa-angle-left\"></i></button>';
		$next 		= '<button type=\"button\" class=\"slick-next\"><i class=\"fa fa-angle-right\"></i></button>';
		if( $vertical )
		{
			$prev= '<button type=\"button\" class=\"slick-prev\"><i class=\"fa fa-angle-up\"></i></button>';
			$next= '<button type=\"button\" class=\"slick-next\"><i class=\"fa fa-angle-down\"></i></button>';
		}
		wp_enqueue_style( 'struct-sclick', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.css' );
		wp_enqueue_script( 'struct-sclick', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js', array( 'jquery' ), '20160816', true );
		wp_add_inline_script( 'struct-sclick', "
			window.jQuery && jQuery( function( $ ) {
				$( '.single-product .product-thumbnails' ).slick( {
					rtl: (function( v ){ return v == 1; })( {$rtl} ),
					vertical: (function( v ){ return v == 1; })( {$vertical} ),
					verticalSwiping: (function( v ){ return v == 1; })( {$vertical} ),
					slidesToShow: (function( v ){ return v || 3; })( {$col} ),
					prevArrow: '{$prev}',
					nextArrow: '{$next}'
				} );
			} );
		" );
		return $col;
	}
}
add_filter( 'woocommerce_product_thumbnails_columns', 'struct_woocommerce_product_thumbnails_columns' );

if( !function_exists( 'struct_woocommerce_share' ) )
{
	function struct_woocommerce_share()
	{
		ob_start();
		require_once( 'tmpl/woo_share.php' );
	}
}
add_action( 'woocommerce_share', 'struct_woocommerce_share' );











