<?php
/**
 * Struct Customizer functionality
 *
 * @package WordPress
 * @subpackage Struct
 * @since Struct 1.0
 */

if( !function_exists( 'struct_customizer_url' ) )
{
	function struct_customizer_url()
	{
		return plugins_url( '/struct/assets/css/customizer.css' );
	}
}
if( !function_exists( 'struct_customizer_get_asset' ) )
{
	function struct_customizer_get_asset( $k = '' )
	{
		$data = array(
			'header-bg' 		=> __DIR__ . '/assets/css/header-bg.css',
			'color-topbar' 		=> __DIR__ . '/assets/css/color-topbar.css',
			'boxed-layouts' 	=> __DIR__ . '/assets/css/boxed-layouts.css',
			'color-general' 	=> __DIR__ . '/assets/css/color-general.css',
			'blog-info' 		=> __DIR__ . '/assets/css/blog-info.css',
			'blog-format' 		=> __DIR__ . '/assets/css/blog-format.css',
			'blog-frame' 		=> __DIR__ . '/assets/css/blog-frame.css',
			'blog-overlay' 		=> __DIR__ . '/assets/css/blog-overlay.css',
		);
		return isset( $data[ $k ] ) ? $data[ $k ] : '';
	}
}

if( !function_exists( 'struct_get_loader_skin' ) )
{
	function struct_get_loader_skin()
	{
		return array(
			'barber-shop' 		=> array( 
				'name' => 'barber-shop', 
				'label' => 'Barber shop', 
				'path' => __DIR__ . '/assets/css/pace-theme-barber-shop.css' 
			),
	 		'big-counter' 		=> array( 
	 			'name' => 'big-counter', 
	 			'label' => 'Big counter', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-big-counter.css' 
	 		),
	 		'bounce' 			=> array( 
	 			'name' => 'bounce', 
	 			'label' => 'Bounce', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-bounce.css' 
	 		),
	 		'center-atom' 		=> array( 
	 			'name' => 'center-atom', 
	 			'label' => 'Center atom', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-center-atom.css' 
	 		),
	 		'center-circle' 	=> array( 
	 			'name' => 'center-circle', 
	 			'label' => 'Center circle', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-center-circle.css' 
	 		),
	 		'center-radar' 		=> array( 
	 			'name' => 'center-radar', 
	 			'label' => 'Center radar', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-center-radar.css' 
	 		),
	 		'center-simple' 	=> array( 
	 			'name' => 'center-simple', 
	 			'label' => 'Center simple', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-center-simple.css' 
	 		),
	 		'corner-indicator' 	=> array( 
	 			'name' => 'corner-indicator', 
	 			'label' => 'Corner indicator', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-corner-indicator.css' 
	 		),
	 		'fill-left' 		=> array( 
	 			'name' => 'fill-left', 
	 			'label' => 'Fill left', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-fill-left.css' 
	 		),
	 		'flash' 			=> array( 
	 			'name' => 'flash', 
	 			'label' => 'Flash', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-flash.css' 
	 		),
	 		'flat-top' 			=> array( 
	 			'name' => 'flat-top', 
	 			'label' => 'Flat top', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-flat-top.css' 
	 		),
	 		'loading-bar' 		=> array( 
	 			'name' => 'loading-bar', 
	 			'label' => 'Loading bar', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-loading-bar.css' 
	 		),
	 		'mac-osx' 			=> array( 
	 			'name' => 'mac-osx', 
	 			'label' => 'Mac osx', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-mac-osx.css' 
	 		),
	 		'minimal' 			=> array( 
	 			'name' => 'minimal', 
	 			'label' => 'Minimal', 
	 			'path' => __DIR__ . '/assets/css/pace-theme-minimal.css'
	 		),
		);
	}
}

if( !function_exists( 'struct_get_content' ) )
{
	function struct_get_content( $path = '', $data = array() )
	{
		if( !file_exists( $path ) )
		{
			return '';
		}
		ob_start();
		extract( $data );
		include( $path );
		return ob_get_clean();
	}
}
/**
 * Adds postMessage support for site title and description for the Customizer.
 *
 * @since Struct 1.0
 *
 * @param WP_Customize_Manager $wp_customize The Customizer object.
 */
if( !function_exists( 'struct_sanitize_no_change' ) )
{
	function struct_sanitize_no_change( $value ) 
	{
		return $value;
	}
}
function struct_customize_register( $wp_customize ) {
	
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector' => '.site-title a',
			'container_inclusive' => false,
			'render_callback' => 'struct_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector' => '.site-description',
			'container_inclusive' => false,
			'render_callback' => 'struct_customize_partial_blogdescription',
		) );
	}
	$wp_customize->remove_section( 'colors' );
	$wp_customize->remove_section( 'header_image' );
	$wp_customize->remove_section( 'background_image' );

	$wp_customize->add_panel( 'style_switcher', array(
	  'title' 		=> __( 'Style switcher', 'struct' ),
	  'priority' 	=> 21
	) );
	$wp_customize->add_section( 'base' , array(
	  'title' => __( 'Base', 'struct' ),
	  'panel' => 'style_switcher',
	) );
	$wp_customize->add_section( 'header_image' , array(
	  'title' => __( 'Header Image', 'struct' ),
	  'panel' => 'style_switcher',
	) );
	$wp_customize->add_section( 'background_image' , array(
	  'title' => __( 'Background image', 'struct' ),
	  'panel' => 'style_switcher',
	) );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-5' , array(
	  'title' => __( 'sidebar-widgets-sidebar-5', 'struct' ),
	  'panel' => 'style_switcher',
	) );
	$wp_customize->add_section( 'loader' , array(
	  'title' => __( 'Loader', 'struct' ),
	  'panel' => 'style_switcher',
	) );
	$wp_customize->add_panel( 'blog',  array(
	  'title' 		=> __( 'Blog', 'struct' ),
	) );
	$wp_customize->add_section( 'bloginfo' , array(
	  'title' => __( 'Date', 'struct' ),
	  'panel' => 'blog',
	) );
	$wp_customize->add_section( 'blogformat' , array(
	  'title' => __( 'Format', 'struct' ),
	  'panel' => 'blog',
	) );
	$wp_customize->add_section( 'blogframe' , array(
	  'title' => __( 'Frame', 'struct' ),
	  'panel' => 'blog',
	) );
	$wp_customize->add_section( 'blogoverlay' , array(
	  'title' => __( 'Overlay', 'struct' ),
	  'panel' => 'blog',
	) );
	$wp_customize->add_section( 'blogmeta' , array(
	  'title' => __( 'Meta', 'struct' ),
	  'panel' => 'blog',
	) );
	$wp_customize->add_section( 'shop_thumbnails' , array(
	  'title' => __( 'Thumbnails', 'struct' ),
	  'panel' => 'shop',
	) );
	$wp_customize->add_section( 'shop_social' , array(
	  'title' => __( 'Social', 'struct' ),
	  'panel' => 'shop',
	) );

	// Add color scheme setting and control.
	$wp_customize->add_setting( 'color_scheme', array(
		'default'           => '#66aacc',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'color_scheme', array(
		'label'       => __( 'Base Color Scheme', 'struct' ),
		'section'     => 'base',
	) ) );

	// Add RTL setting and control.
	$wp_customize->add_setting( 'rtl_enable', array(
		'default'           => 'ltr',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( 'rtl_enable', array(
	 	'label'   => esc_html__( 'RTL Enable', 'struct' ),
	  	'section' => 'base',
	 	'type'    => 'radio',
	 	'choices'  => array(
	 		'ltr' => esc_html__( 'False', 'struct' ),
	 		'rtl' => esc_html__( 'True', 'struct' ),
	 	),
	) );

	// Add loader setting and control.
	$wp_customize->add_setting( 'loader_style', array(
		'default'           => 'loading-bar',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$loader_style = array( '' => esc_html__( 'None', 'struct' ) );
	foreach ( struct_get_loader_skin() as $key => $item ) 
	{
		$loader_style[ $key ] = $item[ 'label' ];
	}
	$wp_customize->add_control( 'loader_style', array(
	 	'label'   => esc_html__( 'Style', 'struct' ),
	  	'section' => 'loader',
	 	'type'    => 'select',
	 	'choices'  => $loader_style,
	) );
	$wp_customize->add_setting( 'loader_visibility', array(
		'default'           => 'visible',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( 'loader_visibility', array(
	 	'label'   => esc_html__( 'Hide Everything', 'struct' ),
	  	'section' => 'loader',
	 	'type'    => 'radio',
	 	'choices'  => array(
	 		'0' => esc_html__( 'True', 'struct' ),
	 		'1' => esc_html__( 'False', 'struct' ),
	 	),
	) );

	// blog info
	$wp_customize->add_setting( 'bloginfo_pos', array(
		'default'           => 'tl',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'bloginfo_pos', array(
	 	'label'   => esc_html__( 'Position', 'struct' ),
	  	'section' => 'bloginfo',
	 	'type'    => 'select',
	 	'choices'  => array(
	 		'tl' => esc_html__( 'top left', 'struct' ),
	 		'tc' => esc_html__( 'top center', 'struct' ),
	 		'tr' => esc_html__( 'top right', 'struct' ),
	 		'rt' => esc_html__( 'right top', 'struct' ),
	 		'rc' => esc_html__( 'right center', 'struct' ),
	 		'rb' => esc_html__( 'right bottom', 'struct' ),
	 		'br' => esc_html__( 'bottom right', 'struct' ),
	 		'bc' => esc_html__( 'bottom center', 'struct' ),
	 		'bl' => esc_html__( 'bottom left', 'struct' ),
	 		'lb' => esc_html__( 'left bottom', 'struct' ),
	 		'lc' => esc_html__( 'left center', 'struct' ),
	 		'lt' => esc_html__( 'left top', 'struct' ),
	 	),
	) );

	$wp_customize->add_setting( 'bloginfo_corner', array(
		'default'           => '0',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'bloginfo_corner', array(
	 	'label'   => esc_html__( 'Corner', 'struct' ),
	  	'section' => 'bloginfo',
	 	'type'    => 'text',
	 	'description' => esc_html__( 'Unit: px', '' )
	) );

	$wp_customize->add_setting( 'bloginfo_bg', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bloginfo_bg', array(
		'label'       => __( 'Background', 'struct' ),
		'section'     => 'bloginfo',
	) ) );

	// blog format
	$wp_customize->add_setting( 'blogformat_corner', array(
		'default'           => '0',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'blogformat_corner', array(
	 	'label'   => esc_html__( 'Corner', 'struct' ),
	  	'section' => 'blogformat',
	 	'type'    => 'text',
	 	'description' => esc_html__( 'Unit: %', '' )
	) );

	$wp_customize->add_setting( 'blogformat_bg', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'blogformat_bg', array(
		'label'       => __( 'Background', 'struct' ),
		'section'     => 'blogformat',
	) ) );

	$wp_customize->add_setting( 'blogformat_corner_color', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'blogformat_corner_color', array(
		'label'       => __( 'Corner color', 'struct' ),
		'section'     => 'blogformat',
	) ) );

	$wp_customize->add_setting( 'blogformat_color', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'blogformat_color', array(
		'label'       => __( 'Color', 'struct' ),
		'section'     => 'blogformat',
	) ) );

	// blog frame
	$wp_customize->add_setting( 'blogframe_corner', array(
		'default'           => '0',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'blogframe_corner', array(
	 	'label'   => esc_html__( 'Corner', 'struct' ),
	  	'section' => 'blogframe',
	 	'type'    => 'text',
	 	'description' => esc_html__( 'Unit: px', 'struct' )
	) );
	$wp_customize->add_setting( 'blogframe_corner_width', array(
		'default'           => '0',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'blogframe_corner_width', array(
	 	'label'   => esc_html__( 'Border width', 'struct' ),
	  	'section' => 'blogframe',
	 	'type'    => 'text',
	 	'description' => esc_html__( 'Unit: px', 'struct' )
	) );
	
	$wp_customize->add_setting( 'blogframe_corner_color', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'blogframe_corner_color', array(
		'label'       => __( 'Border color', 'struct' ),
		'section'     => 'blogframe',
	) ) );
	$wp_customize->add_setting( 'blogframe_corner_style', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'blogframe_corner_style', array(
		'label'     => __( 'Border style', 'struct' ),
		'section'	=> 'blogframe',
		'type'		=> 'select',
		'choices'	=> array(
			'' 			=> esc_html__( 'default', 'struct' ),
			'dotted' 	=> esc_html__( 'dotted', 'struct' ),
			'dashed' 	=> esc_html__( 'dashed', 'struct' ),
			'solid' 	=> esc_html__( 'solid', 'struct' ),
			'double' 	=> esc_html__( 'double', 'struct' ),
			'groove' 	=> esc_html__( 'groove', 'struct' ),
			'ridge' 	=> esc_html__( 'ridge', 'struct' ),
			'inset' 	=> esc_html__( 'inset', 'struct' ),
			'outset' 	=> esc_html__( 'outset', 'struct' ),
		)	
	) );
	$wp_customize->add_setting( 'blogframe_padding', array(
		'default'           => '0',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'blogframe_padding', array(
	 	'label'   => esc_html__( 'Padding', 'struct' ),
	  	'section' => 'blogframe',
	 	'type'    => 'text',
	 	'description' => esc_html__( 'Unit: px', 'struct' )
	) );

	$wp_customize->add_setting( 'blogframe_bg', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'blogframe_bg', array(
		'label'       => __( 'Background', 'struct' ),
		'section'     => 'blogframe',
	) ) );

	$wp_customize->add_setting( 'blogframe_shadow_color', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'blogframe_shadow_color', array(
		'label'       => __( 'Shadow color', 'struct' ),
		'section'     => 'blogframe',
	) ) );

	// blog overlay
	$wp_customize->add_setting( 'blogoverlay_style', array(
		'default'           => '',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'blogoverlay_style', array(
	 	'label'   => esc_html__( 'Style', 'struct' ),
	  	'section' => 'blogoverlay',
	 	'type'    => 'select',
	 	'choices'  => array(
	 		'' 			=> esc_html__( 'default', 'struct' ),
	 		'style1' 	=> esc_html__( '1', 'struct' ),
	 		'style2' 	=> esc_html__( '2', 'struct' ),
	 		'style3' 	=> esc_html__( '3', 'struct' ),
	 		'style4' 	=> esc_html__( '4', 'struct' ),
	 		'style5' 	=> esc_html__( '5', 'struct' ),
	 		'style6' 	=> esc_html__( '6', 'struct' ),
	 		'style7' 	=> esc_html__( '7', 'struct' ),
	 		'style8' 	=> esc_html__( '8', 'struct' ),
	 		'style9' 	=> esc_html__( '9', 'struct' ),
	 		'style10' 	=> esc_html__( '10', 'struct' ),
	 	),
	) );

	// shop social
	$wp_customize->add_setting('blogmeta_author', array(
	 	'default'        => true,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'blogmeta_author', array(
		'label'     => __( 'Author', 'struct' ),
		'section'	=> 'blogmeta',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('blogmeta_cate', array(
	 	'default'        => true,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'blogmeta_cate', array(
		'label'     => __( 'Category', 'struct' ),
		'section'	=> 'blogmeta',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('blogmeta_comment', array(
	 	'default'        => true,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'blogmeta_comment', array(
		'label'     => __( 'Comment', 'struct' ),
		'section'	=> 'blogmeta',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('blogmeta_edit', array(
	 	'default'        => true,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'blogmeta_edit', array(
		'label'     => __( 'Button edit', 'struct' ),
		'section'	=> 'blogmeta',
		'type'		=> 'checkbox',	
	) );



	$wp_customize->add_section( 'topbar' , array(
	    'title'      => __('Top bar','struct'),
	  	'panel' => 'style_switcher',
	) );

	// Add top bar background setting and control.
	$wp_customize->add_setting( 'topbar_bg', array(
		'default'           => '#2d3640',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'topbar_bg', array(
		'label'       => __( 'Background', 'struct' ),
		'section'     => 'topbar',
	) ) );

	// Add top bar element color setting and control.
	$wp_customize->add_setting( 'topbar_color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'topbar_color', array(
		'label'       => __( 'Main Text Color', 'struct' ),
		'section'     => 'topbar',
	) ) );

	// Add footer color setting and control.
	$wp_customize->add_section( 'footer_color', array(
		'title'           => __( 'Footer', 'struct' ),
		'panel'           => 'style_switcher',
	) );
	
	$wp_customize->add_setting( 'footer_c1', array(
		'default'         => '#2d3640',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_c1', array(
		'label'       => __( 'Background color', 'struct' ),
		'section'     => 'footer_color',
	) ) );
	
	$wp_customize->add_setting( 'footer_c2', array(
		'default'         => '#242b33',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_c2', array(
		'label'       => __( 'Bar color', 'struct' ),
		'section'     => 'footer_color',
	) ) );
	
	$wp_customize->add_setting( 'footer_c3', array(
		'default'         => '#ffffff',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_c3', array(
		'label'       => __( 'Main text', 'struct' ),
		'section'     => 'footer_color',
	) ) );

	// Add a switcher After body setting and control.
	$wp_customize->remove_section( 'sidebar-widgets-afterbody' );
	$wp_customize->add_section( 'sidebar-widgets-afterbody' , array(
	  'title' => __( 'After body', 'struct' ),
	  'panel' => 'style_switcher',
	) );

	// Add blog setting and control.
	$wp_customize->add_panel( 'topbar',  array(
	  'title' 		=> __( 'Top bar', 'struct' ),
	) );
	$wp_customize->remove_section( 'sidebar-widgets-wtop-a' );
	$wp_customize->remove_section( 'sidebar-widgets-wtop-b' );
	$wp_customize->add_section( 'sidebar-widgets-wtop-a', array(
		'title'           	=> __( 'Top bar 1', 'struct' ),
		'panel'				=> 'topbar'
	) );
	$wp_customize->add_section( 'sidebar-widgets-wtop-b', array(
		'title'           	=> __( 'Top bar 2', 'struct' ),
		'panel'				=> 'topbar'
	) );

	// Add blog setting and control.
	$wp_customize->remove_section( 'sidebar-widgets-sidebar-1' );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-1', array(
		'title'           	=> __( 'Sidebar', 'struct' ),
		'panel'				=> 'blog'
	) );

	// Add shop setting and control.
	$wp_customize->add_panel( 'shop',  array(
	  'title' 		=> __( 'Shop', 'struct' ),
	) );
	$wp_customize->add_section( 'shop_display', array(
		'title'           	=> __( 'Display', 'struct' ),
		'panel'				=> 'shop'
	) );
	//adding setting for Shop
	$wp_customize->add_setting('scol', array(
	 	'default'        => 'columns-4',
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control('scol', array(
	 	'label'   => 'Columns',
	  	'section' => 'shop_display',
	 	'type'    => 'select',
	 	'choices'  => array(
	 		'columns-1' => '1',
	 		'columns-2' => '2',
	 		'columns-3' => '3',
	 		'columns-4' => '4',
	 		'columns-5' => '5',
	 		'columns-6' => '6',
	 	),
	) );
	$wp_customize->add_setting('sitems', array(
	 	'default'        => get_option( 'posts_per_page' ),
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control('sitems', array(
	 	'label'   => 'Posts per page',
	  	'section' => 'shop_display',
	 	'type'    => 'text',
	));
	$wp_customize->add_setting('smode', array(
	 	'default'        => '',
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control('smode', array(
	 	'label'   => esc_html__( 'Mode', 'struct' ),
	  	'section' => 'shop_display',
	 	'type'    => 'select',
	 	'choices'  => array(
	 		'' => esc_html__( 'Grid', 'struct' ),
	 		'list' => esc_html__( 'List', 'struct' ),
	 	),
	) );
	$wp_customize->remove_section( 'sidebar-widgets-sidebar-shop' );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-shop', array(
		'title'           	=> __( 'Sidebar', 'struct' ),
		'panel'				=> 'shop'
	) );

	// Thumbnails
	$wp_customize->add_setting( 'shop_thumbnails_pos', array(
		'default'           => 'bottom',
		'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'shop_thumbnails_pos', array(
	 	'label'   => esc_html__( 'Position', 'struct' ),
	  	'section' => 'shop_thumbnails',
	 	'type'    => 'select',
	 	'choices'  => array(
	 		'top' 		=> esc_html__( 'Top', 'struct' ),
	 		'right' 	=> esc_html__( 'Right', 'struct' ),
	 		'bottom' 	=> esc_html__( 'Botom', 'struct' ),
	 		'left' 		=> esc_html__( 'Left', 'struct' ),
	 	),
	) );
	$wp_customize->add_setting('shop_thumbnails_items', array(
	 	'default'        => '4',
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control('shop_thumbnails_items', array(
	 	'label'   => esc_html__( 'Slides to show at a time' ),
	  	'section' => 'shop_thumbnails',
	 	'type'    => 'select',
	 	'choices'  => array(
	 		'1' => '1',
	 		'2' => '2',
	 		'3' => '3',
	 		'4' => '4',
	 		'5' => '5',
	 		'6' => '6',
	 	),
	) );

	// shop social
	$wp_customize->add_setting('fb', array(
	 	'default'        => false,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'fb', array(
		'label'     => __( 'Facebook', 'struct' ),
		'section'	=> 'shop_social',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('twitter', array(
	 	'default'        => false,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'twitter', array(
		'label'     => __( 'Twitter', 'struct' ),
		'section'	=> 'shop_social',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('google', array(
	 	'default'        => false,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'google', array(
		'label'     => __( 'Google', 'struct' ),
		'section'	=> 'shop_social',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('linkedin', array(
	 	'default'        => false,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'linkedin', array(
		'label'     => __( 'Linkedin', 'struct' ),
		'section'	=> 'shop_social',
		'type'		=> 'checkbox',	
	) );

	$wp_customize->add_setting('pinterest', array(
	 	'default'        => false,
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control( 'pinterest', array(
		'label'     => __( 'Pinterest', 'struct' ),
		'section'	=> 'shop_social',
		'type'		=> 'checkbox',	
	) );




	$wp_customize->add_panel( 'footer', array(
	  'title' 		=> __( 'Footer', 'struct' ),
	) );
	$wp_customize->remove_section( 'sidebar-widgets-sidebar-2' );
	$wp_customize->remove_section( 'sidebar-widgets-sidebar-3' );
	$wp_customize->remove_section( 'sidebar-widgets-sidebar-4' );
	$wp_customize->remove_section( 'sidebar-widgets-sidebar-5' );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-2', array(
		'title'           => __( 'Content Bottom 1', 'struct' ),
		'panel'			  => 'footer'
	) );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-3', array(
		'title'           => __( 'Content Bottom 2', 'struct' ),
		'panel'			  => 'footer'
	) );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-4', array(
		'title'           => __( 'Content Bottom 3', 'struct' ),
		'panel'			  => 'footer'
	) );
	$wp_customize->add_section( 'sidebar-widgets-sidebar-5', array(
		'title'           => __( 'Content Bottom 4', 'struct' ),
		'panel'			  => 'footer'
	) );

	$wp_customize->add_section( 'footer_b', array(
		'title'           => __( 'Content Bottom 5', 'struct' ),
		'panel'			  => 'footer'
	) );
	//adding setting for footer text area
	$wp_customize->add_setting('copyright', array(
	 	'default'        => '&copy; 2016 STRUCT. All Rights Reserved.',
	 	'sanitize_callback' => 'struct_sanitize_no_change',
		'transport'         => 'postMessage',
	 ));
	$wp_customize->add_control('copyright', array(
	 	'label'   => 'Copyright',
	  	'section' => 'footer_b',
	 	'type'    => 'textarea',
	));
}
add_action( 'customize_register', 'struct_customize_register', 11 );

/**
 * Render the site title for the selective refresh partial.
 *
 * @since Struct 1.2
 * @see struct_customize_register()
 *
 * @return void
 */
function struct_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @since Struct 1.2
 * @see struct_customize_register()
 *
 * @return void
 */
function struct_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Converts a HEX value to RGB.
 *
 * @since Struct 1.0
 *
 * @param string $color The original color, in 3- or 6-digit hexadecimal form.
 * @return array Array containing RGB (red, green, and blue) values for the given
 *               HEX code, empty array otherwise.
 */
if( !function_exists( 'struct_hex2rgb' ) )
{
	function struct_hex2rgb( $color ) 
	{
		$color = trim( $color, '#' );

		if ( strlen( $color ) === 3 ) {
			$r = hexdec( substr( $color, 0, 1 ).substr( $color, 0, 1 ) );
			$g = hexdec( substr( $color, 1, 1 ).substr( $color, 1, 1 ) );
			$b = hexdec( substr( $color, 2, 1 ).substr( $color, 2, 1 ) );
		} else if ( strlen( $color ) === 6 ) {
			$r = hexdec( substr( $color, 0, 2 ) );
			$g = hexdec( substr( $color, 2, 2 ) );
			$b = hexdec( substr( $color, 4, 2 ) );
		} else {
			return array();
		}

		return array( 'r' => $r, 'g' => $g, 'b' => $b );
	}
}

/**
 * Enqueues front-end CSS for color scheme.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_color_scheme_css() {
	$color_scheme_option = get_theme_mod( 'color_scheme', '#66aacc' );

	// Don't do anything if the default color scheme is selected.
	if ( '#66aacc' === $color_scheme_option ) {
		return;
	}

	$rgb 		= struct_hex2rgb( $color_scheme_option );
	$colors 	= array(
		'color' 	=> $color_scheme_option,
		'hex2rgb' 	=> count( $rgb ) > 0 ? "rgba({$rgb['r']},{$rgb['g']},{$rgb['b']},0.7)" : '',
	);

	$color_scheme_css = struct_get_content( struct_customizer_get_asset( 'color-general' ), $colors );
	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $color_scheme_css );
}
add_action( 'wp_enqueue_scripts', 'struct_color_scheme_css', 201 );

/**
 * Enqueues front-end CSS for boxed layouts.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_boxed_layouts_css() {
	$boxed_layouts_option = get_theme_mod( 'background_image', '' );

	// Don't do anything if the default color scheme is selected.
	if ( '' === $boxed_layouts_option ) {
		return;
	}

	$data 	= array(
		'img_url' => $boxed_layouts_option,
	);
	$css 	= struct_get_content( struct_customizer_get_asset( 'boxed-layouts' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_boxed_layouts_css', 201 );

/**
 * Enqueues front-end CSS for topbar.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_topbar_css() {
	$topbar_bg 		= get_theme_mod( 'topbar_bg', '#2d3640' );
	$topbar_color 	= get_theme_mod( 'topbar_color', '#ffffff' );

	// Don't do anything if the default color scheme is selected.
	if ( '#2d3640' === $topbar_bg ) {
		return;
	}

	$data 	= array(
		'bg' 	=> $topbar_bg,
		'color' => $topbar_color,
	);
	$css 	= struct_get_content( struct_customizer_get_asset( 'color-topbar' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_topbar_css', 201 );

/**
 * Enqueues front-end CSS for header background.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_header_bg_css() {
	$header_bg = get_theme_mod( 'header_image', '' );

	// Don't do anything if the default color scheme is selected.
	if ( '' === $header_bg ) {
		return;
	}

	$data 	= array(
		'bg' => $header_bg,
	);
	$css 	= struct_get_content( struct_customizer_get_asset( 'header-bg' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_header_bg_css', 201 );

/**
 * Enqueues front-end CSS for footer color.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_footer_color_css() {
	$c1 = get_theme_mod( 'footer_c1', '' );
	$c2 = get_theme_mod( 'footer_c2', '' );
	$c3 = get_theme_mod( 'footer_c3', '' );

	// Don't do anything if the default color scheme is selected.
	if ( empty( $c1 ) && empty( $c2 ) && empty( $c2 ) ) {
		return;
	}

	$data = array(
		'c1' => $c1,
		'c2' => $c2,
		'c3' => $c3,
	);
	$css = struct_get_content( struct_customizer_get_asset( 'color-footer' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_footer_color_css', 201 );
/**
 * Enqueues front-end CSS for blog info.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_bloginfo_css() {
	$corner = get_theme_mod( 'bloginfo_corner', '' );
	$bg 	= get_theme_mod( 'bloginfo_bg', '' );

	// Don't do anything if the default color scheme is selected.
	if ( empty( $corner ) ) {
		return;
	}

	$data = array(
		'corner' 	=> $corner,
		'bg' 		=> $bg,
	);
	$css = struct_get_content( struct_customizer_get_asset( 'blog-info' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_bloginfo_css', 201 );
/**
 * Enqueues front-end CSS for blog format.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_blogformat_css() {
	$corner 		= get_theme_mod( 'blogformat_corner', '' );
	$corner_color 	= get_theme_mod( 'blogformat_corner_color', '' );
	$bg 			= get_theme_mod( 'blogformat_bg', '' );
	$color 			= get_theme_mod( 'blogformat_color', '' );

	// Don't do anything if the default color scheme is selected.
	if ( empty( $corner ) && empty( $corner_color ) && empty( $bg ) && empty( $color ) ) {
		return;
	}

	$data = array(
		'corner' 		=> $corner,
		'corner_color' 	=> $corner_color,
		'bg' 			=> $bg,
		'color' 		=> $color,
	);
	$css = struct_get_content( struct_customizer_get_asset( 'blog-format' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_blogformat_css', 201 );
/**
 * Enqueues front-end CSS for blog frame.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_blogframe_css() {
	$corner 		= get_theme_mod( 'blogframe_corner', '' );
	$corner_style 	= get_theme_mod( 'blogframe_corner_style', '' );
	$corner_width 	= get_theme_mod( 'blogframe_corner_width', '' );
	$corner_color 	= get_theme_mod( 'blogframe_corner_color', '' );
	$padding 		= get_theme_mod( 'blogframe_padding', '' );
	$bg 			= get_theme_mod( 'blogframe_bg', '' );
	$shadow_color 	= get_theme_mod( 'blogframe_shadow_color', '' );

	// Don't do anything if the default color scheme is selected.
	if ( empty( $corner ) ) {
		return;
	}

	$data = array(
		'corner' 		=> $corner,
		'corner_style' 	=> $corner_style,
		'corner_width' 	=> $corner_width,
		'corner_color' 	=> $corner_color,
		'padding' 		=> $padding,
		'bg' 			=> $bg,
		'shadow_color' 	=> $shadow_color,
	);
	$css = struct_get_content( struct_customizer_get_asset( 'blog-frame' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_blogframe_css', 201 );
/**
 * Enqueues front-end CSS for blog overlay.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
function struct_blogoverlay_css() {
	$style 		= get_theme_mod( 'blogoverlay_style', '' );

	// Don't do anything if the default color scheme is selected.
	if ( empty( $style ) ) {
		return;
	}

	$data = array(
		'style'	=> $style,
	);
	$css = struct_get_content( struct_customizer_get_asset( 'blog-overlay' ), $data );

	wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
	wp_add_inline_style( 'struct-customizer', $css );
}
add_action( 'wp_enqueue_scripts', 'struct_blogoverlay_css', 201 );
/**
 * Enqueues front-end CSS for loader color.
 *
 * @since Struct 1.0
 *
 * @see wp_add_inline_style()
 */
if( !function_exists( 'struct_fetch_loader_css' ) )
{
	function struct_fetch_loader_css()
	{
		$style 		= get_theme_mod( 'loader_style', '' );
		$color 		= get_theme_mod( 'color_scheme', '#66aacc' );
		$visibility = get_theme_mod( 'loader_visibility', '0' );

		// Don't do anything if the default color scheme is selected.
		if ( empty( $style ) ) {
			return;
		}

		$skins 	= struct_get_loader_skin();
		$data 	= array(
			'color' 		=> $color,
			'visibility' 	=> $visibility,
		);
		if( !isset( $skins[ $style ] ) )
		{
			return '';
		}

		return struct_get_loader_css( $skins[ $style ][ 'path' ], $data );
	} 
}
function struct_loader_css() {
	
	wp_enqueue_script( 'struct-pace', plugins_url( '/assets/js/pace.js', __FILE__ ), array(), '20160816', true );

	if( is_customize_preview() )
	{
		return;
	}
	
	if( $css = struct_fetch_loader_css() )
	{
		wp_enqueue_style( 'struct-customizer', struct_customizer_url() );
		wp_add_inline_style( 'struct-customizer', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'struct_loader_css', 201 );

if( !function_exists( 'struct_loader_style' ) )
{
	function struct_loader_style() 
	{
		if( !is_customize_preview() )
		{
			return;
		}
		if( $css = struct_fetch_loader_css() )
		{
			echo '<style type="text/css" id="struct-loader-css">' . $css . '</style>';
		}
	}
}
add_action( 'get_footer', 'struct_loader_style', 201 );
/**
 * Save the currently chosen direction on a per-user basis.
 *
 * @global WP_Locale $wp_locale Locale object.
 * @global WP_Styles $wp_styles Styles object.
 */
if( !function_exists( 'struct_set_direction' ) )
{
	function struct_set_direction()
	{
		global $wp_locale, $wp_styles;
		$direction = get_theme_mod( 'rtl_enable', 'ltr' );
		if( isset( $_GET[ 'd' ] ) && in_array( $_GET[ 'd' ], array( 'ltr', 'rtl' ) ) )
		{
			setcookie( 'rtl_demo', $_GET[ 'd' ] );	
			$direction = $_GET[ 'd' ];
		}
		elseif( isset( $_COOKIE[ 'rtl_demo' ] ) && in_array( $_COOKIE[ 'rtl_demo' ], array( 'ltr', 'rtl' ) ) )
		{
			$direction = $_COOKIE[ 'rtl_demo' ];
		}
		
		if ( empty( $direction ) ) 
		{
			$direction = isset( $wp_locale->text_direction ) ? $wp_locale->text_direction : 'ltr';
		}

		$wp_locale->text_direction = $direction;
		if ( ! is_a( $wp_styles, 'WP_Styles' ) ) 
		{
			$wp_styles = new WP_Styles();
		}
		$wp_styles->text_direction = $direction;
	}
}
add_action( 'init', 'struct_set_direction' );

/**
 * Binds the JS listener to make Customizer color_scheme control.
 *
 * Passes color scheme data as colorScheme global.
 *
 * @since Struct 1.0
 */
function struct_customize_control_js() 
{
	wp_enqueue_script( 'color-scheme-control', plugins_url( '/assets/js/color-scheme-control.js', __FILE__ ), array( 'customize-controls', 'iris', 'underscore', 'wp-util' ), '20160816', true );
}
add_action( 'customize_controls_enqueue_scripts', 'struct_customize_control_js' );

/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 *
 * @since Struct 1.0
 */
function struct_customize_preview_js() 
{
	wp_enqueue_script( 'struct-customize-preview', plugins_url( '/assets/js/customize-preview.js', __FILE__ ), array( 'customize-preview' ), '20160816', true );
}
add_action( 'customize_preview_init', 'struct_customize_preview_js' );



/**
 * Outputs an Underscore template for generating CSS for the color scheme.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_color_scheme_css_template() 
{
	$data = array(
		'color' 	=> '{{ data.color }}',
		'hex2rgb' 	=> '{{ data.hex2rgb }}',
	);
	echo '<script type="text/html" id="tmpl-struct-color-scheme">';
		echo struct_get_content( struct_customizer_get_asset( 'color-general' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_color_scheme_css_template' );


/**
 * Outputs an Underscore template for generating CSS for the boxed layouts.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_boxed_layouts_css_template() 
{
	$data = array(
		'img_url' => '{{ data.img_url }}',
	);
	echo '<script type="text/html" id="tmpl-struct-boxed-layouts">';
		echo struct_get_content( struct_customizer_get_asset( 'boxed-layouts' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_boxed_layouts_css_template' );


/**
 * Outputs an Underscore template for generating CSS for the topbar.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_topbar_css_template() 
{
	$data = array(
		'bg' 	=> '{{ data.bg }}',
		'color' => '{{ data.color }}',
	);
	echo '<script type="text/html" id="tmpl-struct-topbar">';
		echo struct_get_content( struct_customizer_get_asset( 'color-topbar' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_topbar_css_template' );

/**
 * Outputs an Underscore template for generating CSS for the blog info.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_bloginfo_css_template() 
{
	$data = array(
		'corner' 	=> '{{ data.corner }}',
		'bg' 		=> '{{ data.bg }}',
	);
	echo '<script type="text/html" id="tmpl-struct-blog-info">';
		echo struct_get_content( struct_customizer_get_asset( 'blog-info' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_bloginfo_css_template' );

/**
 * Outputs an Underscore template for generating CSS for the blog format.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_blogformat_css_template() 
{
	$data = array(
		'corner' 		=> '{{ data.corner }}',
		'corner_color' 	=> '{{ data.corner_color }}',
		'bg' 			=> '{{ data.bg }}',
		'color' 		=> '{{ data.color }}',
	);
	echo '<script type="text/html" id="tmpl-struct-blog-format">';
		echo struct_get_content( struct_customizer_get_asset( 'blog-format' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_blogformat_css_template' );

/**
 * Outputs an Underscore template for generating CSS for the blog frame.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_blogframe_css_template() 
{
	$data = array(
		'corner' 		=> '{{ data.corner }}',
		'corner_width' 	=> '{{ data.corner_width }}',
		'corner_style' 	=> '{{ data.corner_style }}',
		'corner_color' 	=> '{{ data.corner_color }}',
		'padding' 		=> '{{ data.padding }}',
		'bg' 			=> '{{ data.bg }}',
		'shadow_color' 	=> '{{ data.shadow_color }}',
	);
	echo '<script type="text/html" id="tmpl-struct-blog-frame">';
		echo struct_get_content( struct_customizer_get_asset( 'blog-frame' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_blogframe_css_template' );

/**
 * Outputs an Underscore template for generating CSS for the blog overlay.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_blogoverlay_css_template() 
{
	$data = array(
		
	);
	echo '<script type="text/html" id="tmpl-struct-blog-overlay">';
		echo struct_get_content( struct_customizer_get_asset( 'blog-overlay' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_blogoverlay_css_template' );


/**
 * Outputs an Underscore template for generating CSS for the topbar.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
function struct_header_bg_css_template() 
{
	$data = array(
		'bg' => '{{ data.bg }}',
	);
	echo '<script type="text/html" id="tmpl-struct-header-bg">';
		echo struct_get_content( struct_customizer_get_asset( 'header-bg' ), $data );
	echo '</script>';
}
add_action( 'customize_controls_print_footer_scripts', 'struct_header_bg_css_template' );

if( !function_exists( 'struct_get_loader_css' ) )
{
	function struct_get_loader_css( $path = '', $data = array() )
	{
		$v 	= 'body:not(.pace-done) #boxed-layout { opacity: '.$data[ 'visibility' ] . '!important; }';
		$v .= struct_get_content( $path, $data );
			
		return $v;
	}
}
/**
 * Outputs an Underscore template for generating CSS for the loader color.
 *
 * The template generates the css dynamically for instant display in the
 * Customizer preview.
 *
 * @since Struct 1.0
 */
if( !function_exists( 'struct_loader_css_template' ) )
{
	function struct_loader_css_template()
	{
		$skins 	= struct_get_loader_skin();
		$data 	= array(
			'color' 		=> '{{ data.color }}',
			'visibility' 	=> '{{ data.visibility }}',
		);
		foreach( $skins as $k => $item )
		{
			$v = struct_get_loader_css( $item[ 'path' ], $data );
			echo "<script type='text/html' id='tmpl-struct-loader-skin-{$k}'>{$v}</script>";
		}
	}
}
add_action( 'customize_controls_print_footer_scripts', 'struct_loader_css_template' );












