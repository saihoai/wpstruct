<?php
/**
 * @package Struct
 * @version 1.0
 */
/*
Plugin Name: Struct
Plugin URI: http://wp.uimarketplace.net/plugins/struct/
Description: This is support for struct theme.
Author: saihoai
Version: 1.0
Author URI: https://themeforest.net/user/saihoai/portfolio
*/

require_once( __DIR__ . '/vc.php' );
require_once( __DIR__ . '/theme.php' );
require_once( __DIR__ . '/woocommerce.php' );
require_once( __DIR__ . '/customizer.php' );
require_once( __DIR__ . '/buddypress.php' );
require_once( __DIR__ . '/l/widgetFlickr.php' );
require_once( __DIR__ . '/l/widgetContact.php' );
require_once( __DIR__ . '/l/widgetAbout.php' );
require_once( __DIR__ . '/l/widgetPhone.php' );
require_once( __DIR__ . '/l/widgetSearch.php' );
require_once( __DIR__ . '/l/widgetRecentPosts2.php' );
require_once( __DIR__ . '/l/widgetFont.php' );










